/**
 * MarketContext.tsx — Fund DD vs. Category Index DD comparison panel
 *
 * Design: Dark analytical card, slate palette, no purple gradients.
 * Purpose: Answer "Is this a market correction or a fund-specific issue?"
 *
 * Logic:
 *  - fundDD   = current drawdown of the fund from its ATH (negative %)
 *  - indexDD  = current drawdown of the category benchmark from its ATH (negative %)
 *  - divergence = fundDD - indexDD  (negative = fund fell more than index)
 *
 * Verdict rules:
 *  MARKET_CORRECTION   : |fundDD| ≤ |indexDD| * 1.25  (fund is tracking the index, within 25%)
 *  FUND_UNDERPERFORMING: |fundDD| > |indexDD| * 1.25 AND |fundDD| ≤ |indexDD| * 1.75
 *  FUND_SPECIFIC_ISSUE : |fundDD| > |indexDD| * 1.75  (fund fell >75% more than the index)
 *  BOTH_RECOVERING     : both DDs are within -5% (near ATH, no meaningful correction)
 */

import { TrendingDown, TrendingUp, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { BenchmarkMetrics } from '@/lib/benchmark';
import type { FundMetrics } from '@/lib/metrics';

interface MarketContextProps {
  metrics: FundMetrics;
  benchmark: BenchmarkMetrics | null;
  benchmarkLoading: boolean;
  category: string;
}

type ContextVerdict =
  | 'MARKET_CORRECTION'
  | 'FUND_UNDERPERFORMING'
  | 'FUND_SPECIFIC_ISSUE'
  | 'BOTH_RECOVERING'
  | 'NO_DATA';

function computeIndexDD(bm: BenchmarkMetrics): number {
  // Find ATH of benchmark aligned values and compute current DD
  const values = bm.records.map(r => r.value);
  if (values.length === 0) return 0;
  const ath = Math.max(...values);
  const latest = values[values.length - 1];
  return ((latest - ath) / ath) * 100;
}

function getVerdict(fundDD: number, indexDD: number): ContextVerdict {
  const absFund = Math.abs(fundDD);
  const absIndex = Math.abs(indexDD);

  if (absFund < 5 && absIndex < 5) return 'BOTH_RECOVERING';
  if (absIndex < 3) {
    // Index is near ATH — fund is falling alone
    if (absFund > 8) return 'FUND_SPECIFIC_ISSUE';
    return 'BOTH_RECOVERING';
  }
  if (absFund <= absIndex * 1.25) return 'MARKET_CORRECTION';
  if (absFund <= absIndex * 1.75) return 'FUND_UNDERPERFORMING';
  return 'FUND_SPECIFIC_ISSUE';
}

const VERDICT_CONFIG: Record<ContextVerdict, {
  label: string;
  sub: string;
  action: string;
  color: string;
  bg: string;
  border: string;
  icon: React.ReactNode;
}> = {
  MARKET_CORRECTION: {
    label: 'Market-Wide Correction',
    sub: 'Fund is tracking the category index. This is a broad market pullback, not a fund-specific problem.',
    action: 'Mean-reversion thesis is strong. If quality gate (score ≥ 70) passes, lump sum in tranches is rational.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/25',
    icon: <CheckCircle2 size={18} className="text-emerald-400" />,
  },
  FUND_UNDERPERFORMING: {
    label: 'Fund Underperforming Index',
    sub: 'Fund has fallen meaningfully more than the category index. Partial fund-specific drag is likely.',
    action: 'Proceed with caution. Check for manager change, AUM bloat, or mandate drift before deploying lump sum.',
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/25',
    icon: <AlertTriangle size={18} className="text-amber-400" />,
  },
  FUND_SPECIFIC_ISSUE: {
    label: 'Fund-Specific Issue',
    sub: 'Fund has fallen significantly more than the category index. This is not a market correction — investigate the fund.',
    action: 'Do not deploy lump sum until you identify the cause. Check for manager exit, portfolio concentration, or style drift.',
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/25',
    icon: <AlertTriangle size={18} className="text-red-400" />,
  },
  BOTH_RECOVERING: {
    label: 'Near All-Time High',
    sub: 'Both fund and index are within 5% of ATH. No meaningful correction is in progress.',
    action: 'No buy-zone opportunity at current levels. Continue SIP. Set a watchlist alert for a deeper dip.',
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/25',
    icon: <TrendingUp size={18} className="text-blue-400" />,
  },
  NO_DATA: {
    label: 'Index Data Loading',
    sub: 'Benchmark data is being fetched automatically.',
    action: '',
    color: 'text-white/40',
    bg: 'bg-white/5',
    border: 'border-white/10',
    icon: <Loader2 size={18} className="text-white/30 animate-spin" />,
  },
};

export function MarketContext({ metrics, benchmark, benchmarkLoading, category }: MarketContextProps) {
  const fundDD = metrics.currentDrawdownFromATH ?? 0;

  let indexDD: number | null = null;
  if (benchmark) {
    indexDD = computeIndexDD(benchmark);
  }

  const verdict: ContextVerdict = benchmarkLoading
    ? 'NO_DATA'
    : indexDD === null
    ? 'NO_DATA'
    : getVerdict(fundDD, indexDD);

  const cfg = VERDICT_CONFIG[verdict];
  const divergence = indexDD !== null ? fundDD - indexDD : null;

  return (
    <div className={cn('rounded-xl border p-5 space-y-4', cfg.bg, cfg.border)}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingDown size={15} className="text-white/40" />
          <span className="text-xs font-semibold uppercase tracking-wider text-white/40">
            Market Context — Correction Check
          </span>
        </div>
        {benchmark && (
          <span className="text-xs text-white/30 font-mono">{benchmark.name}</span>
        )}
      </div>

      {/* Verdict */}
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex-shrink-0">{cfg.icon}</div>
        <div>
          <div className={cn('text-base font-bold', cfg.color)}>{cfg.label}</div>
          <div className="text-sm text-white/50 mt-0.5">{cfg.sub}</div>
        </div>
      </div>

      {/* DD Comparison bars */}
      {indexDD !== null && (
        <div className="grid grid-cols-2 gap-4">
          {/* Fund DD */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-white/40 uppercase tracking-wide">Fund DD from ATH</span>
              <span className={cn('font-mono font-bold', Math.abs(fundDD) > 15 ? 'text-red-400' : Math.abs(fundDD) > 8 ? 'text-amber-400' : 'text-emerald-400')}>
                {fundDD.toFixed(1)}%
              </span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all', Math.abs(fundDD) > 15 ? 'bg-red-500' : Math.abs(fundDD) > 8 ? 'bg-amber-500' : 'bg-emerald-500')}
                style={{ width: `${Math.min(Math.abs(fundDD) * 2, 100)}%` }}
              />
            </div>
          </div>

          {/* Index DD */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-white/40 uppercase tracking-wide">Index DD from ATH</span>
              <span className={cn('font-mono font-bold', Math.abs(indexDD) > 15 ? 'text-red-400' : Math.abs(indexDD) > 8 ? 'text-amber-400' : 'text-emerald-400')}>
                {indexDD.toFixed(1)}%
              </span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all', Math.abs(indexDD) > 15 ? 'bg-red-500' : Math.abs(indexDD) > 8 ? 'bg-amber-500' : 'bg-emerald-500')}
                style={{ width: `${Math.min(Math.abs(indexDD) * 2, 100)}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Divergence stat */}
      {divergence !== null && verdict !== 'BOTH_RECOVERING' && verdict !== 'NO_DATA' && (
        <div className="flex items-center gap-4 pt-1 border-t border-white/8">
          <div className="text-xs text-white/30">Divergence (Fund − Index)</div>
          <div className={cn('text-sm font-mono font-bold', divergence < -5 ? 'text-red-400' : divergence < 0 ? 'text-amber-400' : 'text-emerald-400')}>
            {divergence > 0 ? '+' : ''}{divergence.toFixed(1)}%
          </div>
          <div className="text-xs text-white/25 ml-auto">
            {divergence < -5 ? 'Fund fell more than index' : divergence > 2 ? 'Fund held up better than index' : 'Tracking closely'}
          </div>
        </div>
      )}

      {/* Action guidance */}
      {cfg.action && (
        <div className="text-xs text-white/45 bg-white/5 rounded-lg px-3 py-2 border border-white/8">
          <span className="font-semibold text-white/60">Action: </span>{cfg.action}
        </div>
      )}

      {/* Loading state */}
      {benchmarkLoading && (
        <div className="flex items-center gap-2 text-xs text-white/30">
          <Loader2 size={12} className="animate-spin" />
          Auto-loading {category} benchmark index…
        </div>
      )}
    </div>
  );
}
