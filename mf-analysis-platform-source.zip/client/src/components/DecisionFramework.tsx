/**
 * DecisionFramework.tsx
 * Visual decision reference card — live-highlighted verdict, Sharpe gauge,
 * practical decision rules, and category-aware buy-zone guide.
 * Design: dark glass card, amber/emerald/red accent system, no emoji spam.
 */

import { cn } from '@/lib/utils';
import type { FundMetrics } from '@/lib/metrics';
import type { ScoringResult } from '@/lib/metrics';

// ─── Sharpe Gauge ─────────────────────────────────────────────────────────────

function SharpeGauge({ value, category }: { value: number; category: string }) {
  const cat = category.toLowerCase();
  const isSmall = cat.includes('small');
  const isMid = cat.includes('mid');
  const isSectoral = cat.includes('sector') || cat.includes('thematic');

  // Category-calibrated "good" threshold
  const goodThreshold = isSmall ? 0.55 : isMid ? 0.65 : isSectoral ? 0.50 : 0.70;

  // Segments: Poor / Weak / Adequate / Strong / Exceptional
  const segments = [
    { label: 'Poor', range: '< 0.25', min: 0, max: 0.25, color: 'bg-red-500' },
    { label: 'Weak', range: '0.25–0.50', min: 0.25, max: 0.50, color: 'bg-orange-500' },
    { label: 'Adequate', range: '0.50–0.75', min: 0.50, max: 0.75, color: 'bg-amber-400' },
    { label: 'Strong', range: '0.75–1.0', min: 0.75, max: 1.0, color: 'bg-emerald-400' },
    { label: 'Exceptional', range: '> 1.0', min: 1.0, max: 1.5, color: 'bg-cyan-400' },
  ];

  // Clamp value for display
  const clamped = Math.min(Math.max(value, 0), 1.5);
  const pct = (clamped / 1.5) * 100;

  const activeSegment = segments.find(s => value >= s.min && value < s.max) ?? segments[0];
  const isGoodForCat = value >= goodThreshold;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-white/40">Sharpe Ratio</span>
        <div className="flex items-center gap-2">
          <span className={cn(
            'text-xl font-mono font-bold',
            value >= 1.0 ? 'text-cyan-400' : value >= 0.75 ? 'text-emerald-400' : value >= 0.5 ? 'text-amber-400' : value >= 0.25 ? 'text-orange-400' : 'text-red-400'
          )}>
            {value.toFixed(2)}
          </span>
          <span className={cn(
            'text-xs px-2 py-0.5 rounded-full border font-semibold',
            activeSegment.label === 'Exceptional' ? 'bg-cyan-500/15 border-cyan-500/30 text-cyan-400' :
            activeSegment.label === 'Strong' ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400' :
            activeSegment.label === 'Adequate' ? 'bg-amber-500/15 border-amber-500/30 text-amber-400' :
            activeSegment.label === 'Weak' ? 'bg-orange-500/15 border-orange-500/30 text-orange-400' :
            'bg-red-500/15 border-red-500/30 text-red-400'
          )}>
            {activeSegment.label}
          </span>
        </div>
      </div>

      {/* Track */}
      <div className="relative h-3 rounded-full bg-white/8 overflow-hidden">
        {/* Segment fills */}
        <div className="absolute inset-0 flex">
          <div className="flex-1 bg-red-500/30 border-r border-white/10" />
          <div className="flex-1 bg-orange-500/25 border-r border-white/10" />
          <div className="flex-1 bg-amber-400/25 border-r border-white/10" />
          <div className="flex-1 bg-emerald-400/25 border-r border-white/10" />
          <div className="flex-1 bg-cyan-400/20" />
        </div>
        {/* Value indicator */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_6px_rgba(255,255,255,0.8)] transition-all duration-500"
          style={{ left: `${pct}%` }}
        />
      </div>

      {/* Segment labels */}
      <div className="flex text-[9px] text-white/25">
        {segments.map(s => (
          <div key={s.label} className="flex-1 text-center">{s.range}</div>
        ))}
      </div>

      {/* Category calibration note */}
      <div className={cn(
        'text-[10px] px-2 py-1 rounded border',
        isGoodForCat
          ? 'bg-emerald-500/8 border-emerald-500/15 text-emerald-400/70'
          : 'bg-amber-500/8 border-amber-500/15 text-amber-400/70'
      )}>
        {isGoodForCat
          ? `✓ Above the ${goodThreshold.toFixed(2)} threshold considered strong for ${isSmall ? 'Small Cap' : isMid ? 'Mid Cap' : isSectoral ? 'Sectoral' : 'Large/Flexi Cap'} funds`
          : `Below the ${goodThreshold.toFixed(2)} threshold for ${isSmall ? 'Small Cap' : isMid ? 'Mid Cap' : isSectoral ? 'Sectoral' : 'Large/Flexi Cap'} funds — risk not fully compensated`}
      </div>
    </div>
  );
}

// ─── Verdict Score Bar ────────────────────────────────────────────────────────

function VerdictScoreBar({ score, verdict, color }: {
  score: number; verdict: string; color: 'green' | 'amber' | 'red';
}) {
  const zones = [
    { label: 'Avoid / Review', range: '0–44', color: 'bg-red-500/30', textColor: 'text-red-400', min: 0, max: 44 },
    { label: 'Continue SIP', range: '45–69', color: 'bg-amber-400/30', textColor: 'text-amber-400', min: 45, max: 69 },
    { label: 'Accumulate', range: '70–84', color: 'bg-emerald-400/30', textColor: 'text-emerald-400', min: 70, max: 84 },
    { label: 'Strong Buy', range: '85–100', color: 'bg-cyan-400/30', textColor: 'text-cyan-400', min: 85, max: 100 },
  ];

  const activeZone = zones.find(z => score >= z.min && score <= z.max) ?? zones[0];
  const pct = Math.min(Math.max(score, 0), 100);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-white/40">Composite Score</span>
        <div className="flex items-center gap-2">
          <span className={cn(
            'text-xl font-mono font-bold',
            color === 'green' ? 'text-emerald-400' : color === 'amber' ? 'text-amber-400' : 'text-red-400'
          )}>
            {score.toFixed(0)}<span className="text-sm text-white/30">/100</span>
          </span>
          <span className={cn(
            'text-xs px-2 py-0.5 rounded-full border font-semibold',
            color === 'green' ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400' :
            color === 'amber' ? 'bg-amber-500/15 border-amber-500/30 text-amber-400' :
            'bg-red-500/15 border-red-500/30 text-red-400'
          )}>
            {verdict}
          </span>
        </div>
      </div>

      {/* Track */}
      <div className="relative h-3 rounded-full bg-white/8 overflow-hidden">
        <div className="absolute inset-0 flex">
          <div style={{ width: '44%' }} className="bg-red-500/25 border-r border-white/10" />
          <div style={{ width: '25%' }} className="bg-amber-400/25 border-r border-white/10" />
          <div style={{ width: '15%' }} className="bg-emerald-400/25 border-r border-white/10" />
          <div style={{ width: '16%' }} className="bg-cyan-400/20" />
        </div>
        {/* Score fill */}
        <div
          className={cn(
            'absolute top-0 bottom-0 rounded-full transition-all duration-700',
            color === 'green' ? 'bg-emerald-400/60' : color === 'amber' ? 'bg-amber-400/60' : 'bg-red-400/60'
          )}
          style={{ width: `${pct}%` }}
        />
        {/* Needle */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_6px_rgba(255,255,255,0.9)] transition-all duration-700"
          style={{ left: `${pct}%` }}
        />
      </div>

      {/* Zone labels */}
      <div className="flex text-[9px]">
        {zones.map(z => (
          <div
            key={z.label}
            className={cn(
              'text-center transition-colors',
              z.label === activeZone.label ? z.textColor + ' font-semibold' : 'text-white/20'
            )}
            style={{ width: z.label === 'Avoid / Review' ? '44%' : z.label === 'Continue SIP' ? '25%' : z.label === 'Accumulate' ? '15%' : '16%' }}
          >
            {z.range}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Decision Rules Table ─────────────────────────────────────────────────────

function DecisionRulesTable({ verdict, sharpe, maxDD, rolling3YPositivePct, category }: {
  verdict: string; sharpe: number; maxDD: number; rolling3YPositivePct: number | null; category: string;
}) {
  const cat = category.toLowerCase();
  const isSmall = cat.includes('small');
  const isMid = cat.includes('mid');

  // Buy zone suggestion based on category
  const buyZoneSuggestion = isSmall ? '-22% to -30%' : isMid ? '-18% to -25%' : '-10% to -18%';
  const maxDDNorm = isSmall ? 65 : isMid ? 55 : 35;
  const ddOk = Math.abs(maxDD) <= maxDDNorm;
  const sharpeOk = sharpe >= (isSmall ? 0.5 : isMid ? 0.6 : 0.65);
  const consistencyOk = rolling3YPositivePct !== null ? rolling3YPositivePct >= 85 : null;

  const rules: {
    situation: string;
    condition: string;
    action: string;
    pass: boolean | null;
  }[] = [
    {
      situation: 'Already holding, SIP running',
      condition: 'Verdict = Continue SIP or better',
      action: 'Do nothing — let SIP continue',
      pass: verdict !== 'Avoid' && verdict !== 'Review',
    },
    {
      situation: 'Evaluating fresh lump sum',
      condition: 'Score ≥ 70 AND in buy zone',
      action: 'Deploy in 2–3 tranches over 4–6 weeks',
      pass: null, // context-dependent
    },
    {
      situation: 'Sharpe vs. category norm',
      condition: `Sharpe ≥ ${isSmall ? '0.55' : isMid ? '0.65' : '0.70'} for this category`,
      action: sharpeOk ? 'Risk-adjusted quality confirmed' : 'Check if high return came from excess volatility',
      pass: sharpeOk,
    },
    {
      situation: 'Max drawdown vs. category',
      condition: `Max DD ≤ ${maxDDNorm}% for ${isSmall ? 'Small Cap' : isMid ? 'Mid Cap' : 'Large/Flexi Cap'}`,
      action: ddOk ? 'Drawdown within category norms' : 'Fund took excess risk — investigate why',
      pass: ddOk,
    },
    {
      situation: '3Y rolling consistency',
      condition: '% Positive 3Y periods ≥ 85%',
      action: consistencyOk === null ? 'Check Rolling Returns section' :
        consistencyOk ? 'Strong consistency — SIP investors rarely lose over 3Y' :
        'Meaningful loss probability over 3Y windows — reduce conviction',
      pass: consistencyOk,
    },
    {
      situation: 'Watchlist buy zone',
      condition: `Suggested trigger: ${buyZoneSuggestion} from ATH`,
      action: 'Set in Watchlist tab — app alerts when threshold is crossed',
      pass: null,
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-white/10">
            <th className="text-left py-2 px-3 text-white/30 font-medium w-1/4">Situation</th>
            <th className="text-left py-2 px-3 text-white/30 font-medium w-1/3">Rule / Condition</th>
            <th className="text-left py-2 px-3 text-white/30 font-medium">Action / Interpretation</th>
            <th className="text-center py-2 px-3 text-white/30 font-medium w-12">Status</th>
          </tr>
        </thead>
        <tbody>
          {rules.map((r, i) => (
            <tr key={i} className={cn(
              'border-b border-white/5 transition-colors',
              r.pass === true ? 'bg-emerald-500/5' :
              r.pass === false ? 'bg-red-500/5' :
              'hover:bg-white/3'
            )}>
              <td className="py-3 px-3 text-white/80 font-semibold text-sm">{r.situation}</td>
              <td className="py-3 px-3 text-white/55 font-mono text-xs">{r.condition}</td>
              <td className={cn(
                'py-3 px-3 text-sm font-medium',
                r.pass === true ? 'text-emerald-400' :
                r.pass === false ? 'text-red-400' :
                'text-white/65'
              )}>
                {r.action}
              </td>
              <td className="py-2.5 px-3 text-center">
                {r.pass === true && <span className="text-emerald-400 text-base">✓</span>}
                {r.pass === false && <span className="text-red-400 text-base">✗</span>}
                {r.pass === null && <span className="text-white/20 text-base">—</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Verdict Action Card ──────────────────────────────────────────────────────

function VerdictActionCard({ verdict, score, color }: {
  verdict: string; score: number; color: 'green' | 'amber' | 'red';
}) {
  const actions: Record<string, { title: string; bullets: string[]; positionGuide: string }> = {
    'Strong Buy': {
      title: 'Strong conviction — act with a plan',
      bullets: [
        'Deploy 60–100% of intended allocation as lump sum',
        'Start or increase SIP immediately',
        'Set watchlist buy zone for future dips',
      ],
      positionGuide: 'Full position',
    },
    'Accumulate': {
      title: 'Good quality — accumulate systematically',
      bullets: [
        'Deploy 40–60% as lump sum if in buy zone',
        'Start SIP for the remainder',
        'Re-analyze after 6 months to confirm trend',
      ],
      positionGuide: 'Half to full position',
    },
    'Continue SIP': {
      title: 'SIP is safe; lump sum depends on price',
      bullets: [
        'Continue existing SIP without changes',
        'Lump sum eligibility is checked separately below (price gate)',
        'Watch for score improvement after correction',
      ],
      positionGuide: 'SIP only',
    },
    'Avoid': {
      title: 'Weak fundamentals — stay out',
      bullets: [
        'Do not initiate new position',
        'If holding, review exit strategy',
        'Re-analyze in 3–6 months for improvement',
      ],
      positionGuide: 'No new position',
    },
    'Review': {
      title: 'Insufficient data — verify manually',
      bullets: [
        'Fund history too short for reliable scoring',
        'Check AMC track record and fund manager tenure',
        'Wait for 3+ years of NAV history',
      ],
      positionGuide: 'Hold off',
    },
  };

  const key = Object.keys(actions).find(k => verdict.includes(k)) ?? 'Continue SIP';
  const info = actions[key];

  return (
    <div className={cn(
      'rounded-xl p-4 border',
      color === 'green' ? 'bg-emerald-500/8 border-emerald-500/20' :
      color === 'amber' ? 'bg-amber-500/8 border-amber-500/20' :
      'bg-red-500/8 border-red-500/20'
    )}>
      <div className="flex items-start justify-between gap-3 mb-3">
        <div>
          <div className={cn(
            'text-xs font-semibold uppercase tracking-wider mb-0.5',
            color === 'green' ? 'text-emerald-400' : color === 'amber' ? 'text-amber-400' : 'text-red-400'
          )}>
            {verdict}
          </div>
          <div className="text-sm font-semibold text-white/80">{info.title}</div>
        </div>
        <div className={cn(
          'text-xs px-3 py-1.5 rounded-lg border font-mono font-bold whitespace-nowrap',
          color === 'green' ? 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400' :
          color === 'amber' ? 'bg-amber-500/15 border-amber-500/25 text-amber-400' :
          'bg-red-500/15 border-red-500/25 text-red-400'
        )}>
          {info.positionGuide}
        </div>
      </div>
      <ul className="space-y-1">
        {info.bullets.map((b, i) => (
          <li key={i} className="flex items-start gap-2 text-sm text-white/70 font-medium">
            <span className={cn(
              'mt-0.5 w-1 h-1 rounded-full flex-shrink-0',
              color === 'green' ? 'bg-emerald-400' : color === 'amber' ? 'bg-amber-400' : 'bg-red-400'
            )} />
            {b}
          </li>
        ))}
      </ul>
    </div>
  );
}

// ─── Lump Sum Readiness ──────────────────────────────────────────────────────

function LumpSumReadiness({ metrics: m, scoring: s, category }: {
  metrics: FundMetrics;
  scoring: ScoringResult;
  category: string;
}) {
  const cat = category.toLowerCase();
  const isSmall = cat.includes('small');
  const isMid = cat.includes('mid');
  const isSectoral = cat.includes('sector') || cat.includes('thematic');

  // Category buy zone thresholds (DD from ATH needed for lump sum)
  const buyZoneThreshold = isSmall ? -22 : isMid ? -18 : isSectoral ? -25 : -12;
  const catLabel = isSmall ? 'Small Cap' : isMid ? 'Mid Cap' : isSectoral ? 'Sectoral' : 'Large/Flexi Cap';

  const currentDD = m.currentDrawdownFromATH; // negative number e.g. -14.2
  const score = s.totalScore;

  // Gate 1: Quality
  const qualityPass = score >= 70;
  const qualityPartial = score >= 45 && score < 70;

  // Gate 2: Price (how far into the buy zone)
  const pricePass = currentDD <= buyZoneThreshold; // e.g. -18 <= -18 ✓
  const pricePartial = currentDD <= buyZoneThreshold * 0.6; // 60% of the way there
  const pricePct = Math.min(100, Math.max(0, (currentDD / buyZoneThreshold) * 100)); // 0–100%

  // Overall signal
  const signal: 'GO' | 'PARTIAL' | 'WAIT' | 'AVOID' =
    qualityPass && pricePass ? 'GO' :
    qualityPass && pricePartial ? 'PARTIAL' :
    qualityPass ? 'WAIT' :
    qualityPartial ? 'WAIT' :
    'AVOID';

  const signalConfig = {
    GO: {
      label: 'GO — Lump Sum Ready',
      sub: 'Both quality and price gates are open. Deploy in 2–3 tranches.',
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10 border-emerald-500/25',
      barColor: 'bg-emerald-400',
      dot: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]',
    },
    PARTIAL: {
      label: 'PARTIAL — Start Small',
      sub: 'Quality is strong. Price is approaching the zone. Deploy 25–40% now, rest on deeper dip.',
      color: 'text-amber-400',
      bg: 'bg-amber-500/10 border-amber-500/25',
      barColor: 'bg-amber-400',
      dot: 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]',
    },
    WAIT: {
      label: 'WAIT — SIP Only',
      sub: score < 70
        ? 'Quality score below threshold. SIP only until score improves.'
        : `Price not yet in buy zone. Need ${buyZoneThreshold.toFixed(0)}% DD from ATH. Currently at ${currentDD.toFixed(1)}%.`,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10 border-blue-500/25',
      barColor: 'bg-blue-400',
      dot: 'bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.8)]',
    },
    AVOID: {
      label: 'AVOID — Do Not Deploy',
      sub: 'Quality score too low. Do not invest lump sum regardless of price.',
      color: 'text-red-400',
      bg: 'bg-red-500/10 border-red-500/25',
      barColor: 'bg-red-400',
      dot: 'bg-red-400 shadow-[0_0_8px_rgba(248,113,113,0.8)]',
    },
  };

  const cfg = signalConfig[signal];

  // Checklist items
  const checks = [
    {
      label: 'Quality Gate',
      detail: `Score ≥ 70 (Accumulate or Strong Buy)`,
      value: `${score.toFixed(0)}/100`,
      pass: qualityPass,
      partial: qualityPartial,
    },
    {
      label: 'Price Gate',
      detail: `DD from ATH ≤ ${buyZoneThreshold}% for ${catLabel}`,
      value: `${currentDD.toFixed(1)}% from ATH`,
      pass: pricePass,
      partial: pricePartial,
    },
    {
      label: 'Consistency',
      detail: '3Y rolling % positive ≥ 85%',
      value: m.rolling3YStats ? `${m.rolling3YStats.pctPositive.toFixed(0)}%` : 'N/A',
      pass: m.rolling3YStats ? m.rolling3YStats.pctPositive >= 85 : null,
      partial: m.rolling3YStats ? m.rolling3YStats.pctPositive >= 70 : null,
    },
    {
      label: 'Risk-Adjusted',
      detail: `Sharpe ≥ ${isSmall ? '0.55' : isMid ? '0.65' : '0.70'} for ${catLabel}`,
      value: m.sharpeRatio.toFixed(2),
      pass: m.sharpeRatio >= (isSmall ? 0.55 : isMid ? 0.65 : 0.70),
      partial: m.sharpeRatio >= (isSmall ? 0.40 : isMid ? 0.50 : 0.55),
    },
    {
      label: 'Drawdown Norm',
      detail: `Max DD ≤ ${isSmall ? 65 : isMid ? 55 : 35}% for ${catLabel}`,
      value: `${m.maxDrawdown.toFixed(1)}%`,
      pass: Math.abs(m.maxDrawdown) <= (isSmall ? 65 : isMid ? 55 : 35),
      partial: null,
    },
  ];

  return (
    <div className={cn('rounded-xl border p-4 space-y-4', cfg.bg)}>
      {/* Signal header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className={cn('w-2.5 h-2.5 rounded-full flex-shrink-0 animate-pulse', cfg.dot)} />
          <span className={cn('text-sm font-bold tracking-wide', cfg.color)}>{cfg.label}</span>
        </div>
        <span className="text-xs text-white/30 font-mono">
          {currentDD >= 0 ? 'At ATH' : `${currentDD.toFixed(1)}% from ATH`}
        </span>
      </div>

      <p className="text-xs text-white/55 leading-relaxed">{cfg.sub}</p>

      {/* Price proximity bar */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-[10px] text-white/35">
          <span>Price proximity to buy zone</span>
          <span>{pricePct.toFixed(0)}% of the way to {buyZoneThreshold}% DD trigger</span>
        </div>
        <div className="h-2 rounded-full bg-white/8 overflow-hidden">
          <div
            className={cn('h-full rounded-full transition-all duration-700', cfg.barColor)}
            style={{ width: `${pricePct}%`, opacity: 0.7 }}
          />
        </div>
      </div>

      {/* Checklist */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {checks.map((c, i) => {
          const isPass = c.pass === true;
          const isPartial = !isPass && c.partial === true;
          const isFail = c.pass === false && !isPartial;
          const isNA = c.pass === null;
          return (
            <div
              key={i}
              className={cn(
                'rounded-lg px-3 py-2 border text-xs',
                isPass ? 'bg-emerald-500/8 border-emerald-500/20' :
                isPartial ? 'bg-amber-500/8 border-amber-500/20' :
                isFail ? 'bg-red-500/8 border-red-500/20' :
                'bg-white/4 border-white/10'
              )}
            >
              <div className="flex items-center justify-between mb-0.5">
                <span className="text-white/50 font-medium">{c.label}</span>
                <span className={cn(
                  'text-base leading-none',
                  isPass ? 'text-emerald-400' : isPartial ? 'text-amber-400' : isFail ? 'text-red-400' : 'text-white/20'
                )}>
                  {isPass ? '✓' : isPartial ? '~' : isFail ? '✗' : '—'}
                </span>
              </div>
              <div className={cn(
                'font-mono font-semibold',
                isPass ? 'text-emerald-400' : isPartial ? 'text-amber-400' : isFail ? 'text-red-400' : 'text-white/40'
              )}>
                {c.value}
              </div>
              <div className="text-[9px] text-white/25 mt-0.5">{c.detail}</div>
            </div>
          );
        })}
      </div>

      {/* Position sizing guide */}
      <div className="flex flex-wrap gap-2 pt-1">
        {[
          { label: 'Full (60–100%)', active: signal === 'GO' },
          { label: 'Partial (25–40%)', active: signal === 'PARTIAL' },
          { label: 'SIP only', active: signal === 'WAIT' },
          { label: 'No position', active: signal === 'AVOID' },
        ].map(p => (
          <span
            key={p.label}
            className={cn(
              'text-[10px] px-2.5 py-1 rounded-full border font-medium transition-colors',
              p.active
                ? signal === 'GO' ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : signal === 'PARTIAL' ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : signal === 'WAIT' ? 'bg-blue-500/20 border-blue-500/40 text-blue-300'
                  : 'bg-red-500/20 border-red-500/40 text-red-300'
                : 'bg-white/4 border-white/10 text-white/20'
            )}
          >
            {p.label}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Main Export ──────────────────────────────────────────────────────────────

export function DecisionFramework({ metrics: m, scoring: s, category }: {
  metrics: FundMetrics;
  scoring: ScoringResult;
  category: string;
}) {
  return (
    <div className="glass-card overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-white/8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-sm font-semibold text-white/80">Decision Framework</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/25 text-blue-400">
            Live — updates with fund
          </span>
        </div>
        <span className="text-xs text-white/25">All rules applied to this fund's actual metrics</span>
      </div>

      <div className="p-5 space-y-6">

        {/* Row 1: Score bar + Verdict action card */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="space-y-4">
            <VerdictScoreBar score={s.totalScore} verdict={s.verdict} color={s.verdictColor} />
            <SharpeGauge value={m.sharpeRatio} category={category} />
          </div>
          <VerdictActionCard verdict={s.verdict} score={s.totalScore} color={s.verdictColor} />
        </div>

        {/* Divider */}
        <div className="border-t border-white/8" />

        {/* Lump Sum Readiness */}
        <div>
          <div className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">
            Lump Sum Readiness — Two-Gate Check
          </div>
          <LumpSumReadiness metrics={m} scoring={s} category={category} />
        </div>

        {/* Divider */}
        <div className="border-t border-white/8" />

        {/* Row 2: Decision rules table */}
        <div>
          <div className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">
            Practical Decision Rules — Applied to This Fund
          </div>
          <DecisionRulesTable
            verdict={s.verdict}
            sharpe={m.sharpeRatio}
            maxDD={m.maxDrawdown}
            rolling3YPositivePct={m.rolling3YStats?.pctPositive ?? null}
            category={category}
          />
        </div>

        {/* Footer note */}
        <div className="text-[10px] text-white/20 bg-white/3 rounded p-2 border border-white/6">
          Rules are applied to historical NAV data only. Past performance does not guarantee future returns.
          Score is a snapshot — re-analyze after market corrections as entry price changes the forward return expectation.
        </div>

      </div>
    </div>
  );
}
