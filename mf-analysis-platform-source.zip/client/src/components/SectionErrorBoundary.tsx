import { AlertTriangle, RefreshCw, Copy, Check } from "lucide-react";
import { Component, ReactNode } from "react";

interface Props {
  children: ReactNode;
  label?: string;
}
interface State {
  hasError: boolean;
  error: Error | null;
  copied: boolean;
}

/**
 * Wraps individual analysis sections so a crash in one section
 * (e.g. heatmap, rolling chart) doesn't take down the entire page.
 * Shows a compact error card with Retry and Copy Error Details buttons.
 */
class SectionErrorBoundary extends Component<Props, State> {
  private copyTimeout: ReturnType<typeof setTimeout> | null = null;

  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, copied: false };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentWillUnmount() {
    if (this.copyTimeout) clearTimeout(this.copyTimeout);
  }

  handleCopy = () => {
    const { error, copied } = this.state;
    if (copied || !error) return;
    const text = [
      `Section: ${this.props.label ?? 'Unknown'}`,
      `Error: ${error.message}`,
      `Stack: ${error.stack ?? 'N/A'}`,
      `URL: ${window.location.href}`,
      `Time: ${new Date().toISOString()}`,
    ].join('\n');
    navigator.clipboard.writeText(text).then(() => {
      this.setState({ copied: true });
      this.copyTimeout = setTimeout(() => this.setState({ copied: false }), 2500);
    }).catch(() => {
      // Fallback for browsers without clipboard API
      const el = document.createElement('textarea');
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      this.setState({ copied: true });
      this.copyTimeout = setTimeout(() => this.setState({ copied: false }), 2500);
    });
  };

  render() {
    if (this.state.hasError) {
      const { copied } = this.state;
      return (
        <div className="rounded-xl border border-red-500/20 bg-red-500/5 px-5 py-4 flex items-start gap-3">
          <AlertTriangle size={16} className="text-red-400 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-red-300">
              {this.props.label ?? 'Section'} failed to render
            </div>
            <div className="text-xs text-white/30 mt-0.5 font-mono truncate">
              {this.state.error?.message ?? 'Unknown error'}
            </div>
          </div>
          <div className="shrink-0 flex items-center gap-2">
            <button
              onClick={this.handleCopy}
              title="Copy error details to clipboard"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-white/5 border border-white/10 text-white/50 hover:text-white/80 hover:bg-white/10 transition-colors"
            >
              {copied ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
              {copied ? 'Copied' : 'Copy error'}
            </button>
            <button
              onClick={() => this.setState({ hasError: false, error: null, copied: false })}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-white/5 border border-white/10 text-white/50 hover:text-white/80 hover:bg-white/10 transition-colors"
            >
              <RefreshCw size={11} />
              Retry
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default SectionErrorBoundary;
