/**
 * useWatchlist.ts — Persistent watchlist with buy-zone DD alerts
 * Storage: localStorage (no backend required)
 * Alert logic: triggers when current drawdown from ATH crosses user-defined threshold
 *
 * Design notes:
 * - All mutating callbacks use setEntries(prev => ...) functional updater so they
 *   never capture stale `entries` in a closure.
 * - The returned object is memoized so its reference stays stable across renders,
 *   preventing useCallback deps from re-creating on every entries change.
 * - isInWatchlist reads from a ref (always current) so callers don't need to
 *   include `watchlist` in their useCallback dep arrays.
 */

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';

export interface WatchlistEntry {
  schemeCode: number;
  schemeName: string;
  fundHouse: string;
  category: string;
  addedAt: string;       // ISO date string
  buyZoneDD: number;     // negative number, e.g. -15 means alert when DD < -15%
  latestNav: number;
  athNav: number;
  currentDD: number;
  cagrInception: number;
  sharpeRatio: number;
  compositeScore?: number; // 0–100 composite score from scoring engine
  indexDD?: number;       // current DD of the category benchmark from ATH (negative %, populated on refresh)
  lastUpdated: string;   // ISO date string
}

const STORAGE_KEY = 'mf_watchlist_v1';

/**
 * Migrate a stale entry that was saved before the snake_case fix.
 * The MFAPI returns snake_case keys (scheme_code, scheme_name, fund_house,
 * scheme_category) but old entries were stored with those raw keys.
 * This function remaps them to camelCase so old entries render correctly.
 */
function migrateEntry(raw: Record<string, unknown>): WatchlistEntry {
  return {
    schemeCode:     (raw.schemeCode     ?? raw.scheme_code     ?? 0)   as number,
    schemeName:     (raw.schemeName     ?? raw.scheme_name     ?? '')  as string,
    fundHouse:      (raw.fundHouse      ?? raw.fund_house      ?? '')  as string,
    category:       (raw.category       ?? raw.scheme_category ?? raw.scheme_type ?? '') as string,
    addedAt:        (raw.addedAt        ?? new Date().toISOString()) as string,
    buyZoneDD:      (raw.buyZoneDD      ?? -15)  as number,
    latestNav:      (raw.latestNav      ?? 0)    as number,
    athNav:         (raw.athNav         ?? 0)    as number,
    currentDD:      (raw.currentDD      ?? 0)    as number,
    cagrInception:  (raw.cagrInception  ?? 0)    as number,
    sharpeRatio:    (raw.sharpeRatio    ?? 0)    as number,
    compositeScore: (raw.compositeScore ?? undefined) as number | undefined,
    indexDD:        (raw.indexDD        ?? undefined) as number | undefined,
    lastUpdated:    (raw.lastUpdated    ?? new Date().toISOString()) as string,
  };
}

function loadFromStorage(): WatchlistEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Record<string, unknown>[];
    return parsed.map(migrateEntry);
  } catch {
    return [];
  }
}

function saveToStorage(entries: WatchlistEntry[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch {
    // storage full — silently ignore
  }
}

export function useWatchlist() {
  const [entries, setEntries] = useState<WatchlistEntry[]>(() => loadFromStorage());

  // Keep a ref that always points to the latest entries array.
  // This lets isInWatchlist / updateMetrics work without needing `entries`
  // in any external useCallback dependency array.
  const entriesRef = useRef(entries);
  useEffect(() => {
    entriesRef.current = entries;
  }, [entries]);

  // One-time migration: immediately persist migrated entries so stale
  // snake_case keys are overwritten with camelCase on first load.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { saveToStorage(entries); }, []);

  // Persist on every subsequent change
  useEffect(() => {
    saveToStorage(entries);
  }, [entries]);

  // All mutators use functional updater — no stale closure risk
  const addEntry = useCallback((entry: Omit<WatchlistEntry, 'addedAt'>) => {
    setEntries(prev => {
      const exists = prev.find(e => e.schemeCode === entry.schemeCode);
      if (exists) {
        return prev.map(e =>
          e.schemeCode === entry.schemeCode
            ? { ...entry, addedAt: e.addedAt, lastUpdated: new Date().toISOString() }
            : e
        );
      }
      return [...prev, { ...entry, addedAt: new Date().toISOString(), lastUpdated: new Date().toISOString() }];
    });
  }, []);

  const removeEntry = useCallback((schemeCode: number) => {
    setEntries(prev => prev.filter(e => e.schemeCode !== schemeCode));
  }, []);

  const updateBuyZone = useCallback((schemeCode: number, buyZoneDD: number) => {
    setEntries(prev =>
      prev.map(e => e.schemeCode === schemeCode ? { ...e, buyZoneDD } : e)
    );
  }, []);

  const updateMetrics = useCallback((schemeCode: number, updates: Partial<WatchlistEntry>) => {
    setEntries(prev =>
      prev.map(e =>
        e.schemeCode === schemeCode
          ? { ...e, ...updates, lastUpdated: new Date().toISOString() }
          : e
      )
    );
  }, []);

  // Reads from ref — always current, never stale, stable function reference
  const isInWatchlist = useCallback((schemeCode: number) => {
    return entriesRef.current.some(e => e.schemeCode === schemeCode);
  }, []); // no deps needed — reads from ref

  // Alerts derived from current entries
  const alerts = useMemo(
    () => entries.filter(e => e.currentDD <= e.buyZoneDD),
    [entries]
  );

  // Stable return object — only re-creates when entries or alerts change
  return useMemo(
    () => ({ entries, alerts, addEntry, removeEntry, updateBuyZone, updateMetrics, isInWatchlist }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [entries, alerts]
  );
}
