/**
 * categoryAverages.ts — Category benchmark averages for peer-relative scoring
 *
 * Source: AMFI category-level aggregated data (publicly available).
 * These are approximate category medians based on AMFI/SEBI category definitions.
 * Values are updated periodically — labeled with source date.
 * Used ONLY for relative scoring context, not as primary metrics.
 *
 * All fund-specific metrics are still computed from raw NAV. These averages
 * are used only to add a "vs Category Avg" row to the scoring grid.
 *
 * Data source: AMFI category classification + Morningstar India category averages
 * Reference date: Mar 2026 (approximate trailing figures)
 * Confidence: APPROXIMATE — label clearly in UI
 */

export interface CategoryAverage {
  category: string;
  cagr1Y: number | null;       // % p.a. — trailing 1Y
  cagr2Y: number | null;       // % p.a. — trailing 2Y
  cagr3Y: number | null;       // % p.a.
  cagr5Y: number | null;       // % p.a.
  maxDD: number | null;        // % (negative)
  sharpe: number | null;       // ratio
  stdDev: number | null;       // % annualised
  ter: number | null;          // % (direct plan average)
  source: string;
}

/**
 * Derived short-period category averages for the trailing returns table.
 * 1W/1M/3M/6M are estimated from the 1Y figure using simple de-annualization.
 * These are rough proxies — market timing makes short-period averages inherently noisy.
 * Always labeled as "~approx" in the UI.
 */
export interface CategoryTrailingReturns {
  ret1W: number | null;   // absolute %, estimated
  ret1M: number | null;   // absolute %, estimated
  ret3M: number | null;   // absolute %, estimated
  ret6M: number | null;   // absolute %, estimated
  cagr1Y: number | null;  // % p.a.
  cagr2Y: number | null;  // % p.a.
  cagr3Y: number | null;  // % p.a.
  cagr5Y: number | null;  // % p.a.
  categoryName: string;
  isApproximate: true;
}

// Category averages — approximate, labeled as such in UI
// Grouped by SEBI/AMFI category names (partial match used)
// cagr1Y and cagr2Y added Mar 2026 based on AMFI/Morningstar India data
const CATEGORY_DATA: CategoryAverage[] = [
  // Equity — Large Cap
  { category: 'Large Cap', cagr1Y: 8.5, cagr2Y: 11.5, cagr3Y: 14.2, cagr5Y: 16.8, maxDD: -28.0, sharpe: 0.85, stdDev: 16.5, ter: 0.85, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — Mid Cap
  { category: 'Mid Cap', cagr1Y: 10.5, cagr2Y: 15.0, cagr3Y: 18.5, cagr5Y: 22.1, maxDD: -35.0, sharpe: 0.90, stdDev: 20.5, ter: 0.80, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — Small Cap
  { category: 'Small Cap', cagr1Y: 8.0, cagr2Y: 14.0, cagr3Y: 22.0, cagr5Y: 26.5, maxDD: -42.0, sharpe: 0.85, stdDev: 24.0, ter: 0.75, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — Flexi Cap
  { category: 'Flexi Cap', cagr1Y: 9.5, cagr2Y: 12.5, cagr3Y: 16.0, cagr5Y: 18.5, maxDD: -30.0, sharpe: 0.88, stdDev: 17.5, ter: 0.80, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — Multi Cap
  { category: 'Multi Cap', cagr1Y: 10.0, cagr2Y: 13.5, cagr3Y: 17.5, cagr5Y: 20.0, maxDD: -32.0, sharpe: 0.87, stdDev: 18.5, ter: 0.78, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — Large & Mid Cap
  { category: 'Large & Mid Cap', cagr1Y: 9.8, cagr2Y: 13.0, cagr3Y: 16.8, cagr5Y: 19.5, maxDD: -31.0, sharpe: 0.88, stdDev: 18.0, ter: 0.82, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — ELSS
  { category: 'ELSS', cagr1Y: 9.0, cagr2Y: 12.0, cagr3Y: 15.5, cagr5Y: 18.0, maxDD: -30.5, sharpe: 0.86, stdDev: 17.8, ter: 0.80, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — Thematic / Sectoral
  { category: 'Thematic', cagr1Y: 12.0, cagr2Y: 16.0, cagr3Y: 20.0, cagr5Y: 22.0, maxDD: -38.0, sharpe: 0.82, stdDev: 26.0, ter: 0.90, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Sectoral', cagr1Y: 12.0, cagr2Y: 16.0, cagr3Y: 20.0, cagr5Y: 22.0, maxDD: -38.0, sharpe: 0.82, stdDev: 26.0, ter: 0.90, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Equity — Value / Contra
  { category: 'Value', cagr1Y: 10.5, cagr2Y: 13.5, cagr3Y: 17.0, cagr5Y: 20.5, maxDD: -30.0, sharpe: 0.90, stdDev: 17.0, ter: 0.80, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Contra', cagr1Y: 10.5, cagr2Y: 13.5, cagr3Y: 17.0, cagr5Y: 20.5, maxDD: -30.0, sharpe: 0.90, stdDev: 17.0, ter: 0.80, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Hybrid
  { category: 'Aggressive Hybrid', cagr1Y: 8.0, cagr2Y: 10.5, cagr3Y: 13.0, cagr5Y: 15.5, maxDD: -24.0, sharpe: 0.88, stdDev: 14.5, ter: 0.85, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Balanced Advantage', cagr1Y: 7.5, cagr2Y: 9.5, cagr3Y: 11.5, cagr5Y: 13.0, maxDD: -18.0, sharpe: 0.90, stdDev: 11.5, ter: 0.80, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Conservative Hybrid', cagr1Y: 7.0, cagr2Y: 7.8, cagr3Y: 8.5, cagr5Y: 9.5, maxDD: -12.0, sharpe: 0.85, stdDev: 8.0, ter: 0.75, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Debt
  { category: 'Short Duration', cagr1Y: 7.5, cagr2Y: 7.3, cagr3Y: 7.2, cagr5Y: 7.5, maxDD: -3.0, sharpe: 1.20, stdDev: 2.5, ter: 0.35, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Medium Duration', cagr1Y: 7.8, cagr2Y: 7.6, cagr3Y: 7.5, cagr5Y: 7.8, maxDD: -5.0, sharpe: 1.10, stdDev: 3.5, ter: 0.40, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Long Duration', cagr1Y: 9.5, cagr2Y: 8.8, cagr3Y: 8.0, cagr5Y: 8.5, maxDD: -10.0, sharpe: 0.95, stdDev: 6.0, ter: 0.40, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Liquid', cagr1Y: 7.2, cagr2Y: 7.0, cagr3Y: 6.8, cagr5Y: 6.5, maxDD: -0.5, sharpe: 2.50, stdDev: 0.5, ter: 0.20, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'Overnight', cagr1Y: 6.8, cagr2Y: 6.7, cagr3Y: 6.5, cagr5Y: 6.2, maxDD: -0.1, sharpe: 3.00, stdDev: 0.2, ter: 0.10, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // Index / Passive
  { category: 'Index', cagr1Y: 8.3, cagr2Y: 11.2, cagr3Y: 14.0, cagr5Y: 16.5, maxDD: -28.5, sharpe: 0.83, stdDev: 16.8, ter: 0.20, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  { category: 'ETF', cagr1Y: 8.3, cagr2Y: 11.2, cagr3Y: 14.0, cagr5Y: 16.5, maxDD: -28.5, sharpe: 0.83, stdDev: 16.8, ter: 0.15, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // International
  { category: 'International', cagr1Y: 8.0, cagr2Y: 9.0, cagr3Y: 10.0, cagr5Y: 13.0, maxDD: -30.0, sharpe: 0.70, stdDev: 18.0, ter: 1.00, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
  // FOF
  { category: 'Fund of Funds', cagr1Y: 9.0, cagr2Y: 10.5, cagr3Y: 12.0, cagr5Y: 14.0, maxDD: -25.0, sharpe: 0.80, stdDev: 15.0, ter: 1.20, source: 'AMFI/Morningstar India, Mar 2026 approx.' },
];

/**
 * Match fund category string to a CategoryAverage entry.
 * Uses partial case-insensitive matching.
 */
export function getCategoryAverage(schemeCategory: string): CategoryAverage | null {
  if (!schemeCategory) return null;
  const cat = schemeCategory.toLowerCase();

  // Priority order: most specific first
  const matchers: [string, string][] = [
    ['large & mid cap', 'Large & Mid Cap'],
    ['large and mid cap', 'Large & Mid Cap'],
    ['aggressive hybrid', 'Aggressive Hybrid'],
    ['balanced advantage', 'Balanced Advantage'],
    ['conservative hybrid', 'Conservative Hybrid'],
    ['fund of funds', 'Fund of Funds'],
    ['international', 'International'],
    ['overnight', 'Overnight'],
    ['liquid', 'Liquid'],
    ['long duration', 'Long Duration'],
    ['medium duration', 'Medium Duration'],
    ['short duration', 'Short Duration'],
    ['small cap', 'Small Cap'],
    ['mid cap', 'Mid Cap'],
    ['large cap', 'Large Cap'],
    ['flexi cap', 'Flexi Cap'],
    ['multi cap', 'Multi Cap'],
    ['elss', 'ELSS'],
    ['thematic', 'Thematic'],
    ['sectoral', 'Sectoral'],
    ['value', 'Value'],
    ['contra', 'Contra'],
    ['index fund', 'Index'],
    ['index', 'Index'],
    ['etf', 'ETF'],
    ['hybrid', 'Aggressive Hybrid'],
  ];

  for (const [keyword, categoryName] of matchers) {
    if (cat.includes(keyword)) {
      return CATEGORY_DATA.find(d => d.category === categoryName) || null;
    }
  }
  return null;
}

/**
 * Derive short-period trailing returns from the category average 1Y figure.
 * Formula: simple de-annualization — (1 + r/100)^(days/365) - 1
 * These are rough proxies for the category average short-period returns.
 * Market timing means actual short-period averages vary significantly.
 */
export function getCategoryTrailingReturns(schemeCategory: string): CategoryTrailingReturns | null {
  const avg = getCategoryAverage(schemeCategory);
  if (!avg) return null;

  function deannualize(cagrPct: number | null, days: number): number | null {
    if (cagrPct === null) return null;
    const r = cagrPct / 100;
    const result = (Math.pow(1 + r, days / 365) - 1) * 100;
    return isFinite(result) ? parseFloat(result.toFixed(2)) : null;
  }

  return {
    ret1W: deannualize(avg.cagr1Y, 7),
    ret1M: deannualize(avg.cagr1Y, 30),
    ret3M: deannualize(avg.cagr1Y, 91),
    ret6M: deannualize(avg.cagr1Y, 182),
    cagr1Y: avg.cagr1Y,
    cagr2Y: avg.cagr2Y,
    cagr3Y: avg.cagr3Y,
    cagr5Y: avg.cagr5Y,
    categoryName: avg.category,
    isApproximate: true,
  };
}

/**
 * Generate a peer-relative scoring row for the scoring grid.
 * Returns a score from 0–10 based on how the fund compares to category average.
 * Score = 5 (at par) + adjustments for each available metric.
 */
export interface PeerRelativeScore {
  score: number;
  evidence: string;
  categoryName: string;
  isApproximate: boolean;
}

export function computePeerRelativeScore(
  cagrInception: number,
  cagr3Y: number | null,
  sharpe: number,
  maxDD: number,
  categoryAvg: CategoryAverage,
): PeerRelativeScore {
  const comparisons: string[] = [];
  let totalAdj = 0;
  let count = 0;

  // CAGR comparison (use 3Y if available, else inception)
  const fundCagr = cagr3Y !== null ? cagr3Y : cagrInception;
  const bmCagr = cagr3Y !== null ? categoryAvg.cagr3Y : null;
  if (bmCagr !== null) {
    const cagrDiff = fundCagr - bmCagr;
    const cagrAdj = cagrDiff > 5 ? 2.0 : cagrDiff > 2 ? 1.0 : cagrDiff > 0 ? 0.5 : cagrDiff > -2 ? -0.5 : cagrDiff > -5 ? -1.0 : -2.0;
    totalAdj += cagrAdj;
    count++;
    comparisons.push(`CAGR: fund ${fundCagr.toFixed(1)}% vs cat avg ${bmCagr.toFixed(1)}% (${cagrDiff > 0 ? '+' : ''}${cagrDiff.toFixed(1)}%)`);
  }

  // Sharpe comparison
  if (categoryAvg.sharpe !== null) {
    const sharpeDiff = sharpe - categoryAvg.sharpe;
    const sharpeAdj = sharpeDiff > 0.5 ? 1.5 : sharpeDiff > 0.2 ? 0.75 : sharpeDiff > 0 ? 0.25 : sharpeDiff > -0.2 ? -0.25 : sharpeDiff > -0.5 ? -0.75 : -1.5;
    totalAdj += sharpeAdj;
    count++;
    comparisons.push(`Sharpe: fund ${sharpe.toFixed(2)} vs cat avg ${categoryAvg.sharpe.toFixed(2)} (${sharpeDiff > 0 ? '+' : ''}${sharpeDiff.toFixed(2)})`);
  }

  // Max DD comparison (lower absolute value is better)
  if (categoryAvg.maxDD !== null) {
    const ddDiff = Math.abs(maxDD) - Math.abs(categoryAvg.maxDD); // positive = fund had worse DD
    const ddAdj = ddDiff < -5 ? 1.5 : ddDiff < -2 ? 0.75 : ddDiff < 0 ? 0.25 : ddDiff < 2 ? -0.25 : ddDiff < 5 ? -0.75 : -1.5;
    totalAdj += ddAdj;
    count++;
    comparisons.push(`Max DD: fund ${maxDD.toFixed(1)}% vs cat avg ${categoryAvg.maxDD.toFixed(1)}% (${ddDiff > 0 ? 'worse' : 'better'} by ${Math.abs(ddDiff).toFixed(1)}%)`);
  }

  const avgAdj = count > 0 ? totalAdj / count : 0;
  const score = Math.max(1, Math.min(10, 5 + avgAdj * 2));

  return {
    score: Math.round(score * 2) / 2,
    evidence: comparisons.join(' | ') + `. Category: ${categoryAvg.category}. ⚠ Approximate — ${categoryAvg.source}`,
    categoryName: categoryAvg.category,
    isApproximate: true,
  };
}

/**
 * Returns the category-appropriate buy zone trigger (drawdown from ATH, negative number).
 * Auto-applied when a fund is added to the watchlist or refreshed.
 *
 * Norms (midpoint of typical buy zone range per category):
 *   Small Cap          → −25% (range: −22% to −30%)
 *   Mid Cap            → −20% (range: −18% to −25%)
 *   Sectoral/Thematic  → −25% (higher volatility, wider range)
 *   Large & Mid Cap    → −18% (between large and mid norms)
 *   Large Cap / Flexi / Multi / ELSS / Default → −15% (range: −10% to −18%)
 */
export function getCategoryBuyZone(category: string): number {
  const cat = (category || '').toLowerCase();
  if (cat.includes('small')) return -25;
  if (cat.includes('sector') || cat.includes('thematic')) return -25;
  if (cat.includes('large & mid') || cat.includes('large and mid')) return -18;
  if (cat.includes('mid')) return -20;
  return -15; // Large Cap, Flexi Cap, Multi Cap, ELSS, default
}

/**
 * Returns the recommended benchmark TRI index name for a given fund category.
 * Used to pre-fill the benchmark name field in the UI.
 * Source: SEBI/AMFI category benchmark mapping (standard industry practice).
 */
export function getBenchmarkSuggestion(schemeCategory: string): string {
  if (!schemeCategory) return 'Nifty 500 TRI';
  const cat = schemeCategory.toLowerCase();

  // Sectoral / Thematic — most specific first (use exact bundled TRI names)
  if (cat.includes('defence')) return 'Nifty India Defence TRI';
  if (cat.includes('manufactur')) return 'Nifty India Manufacturing TRI';
  if (cat.includes('oil') || cat.includes('gas') || cat.includes('energy') || cat.includes('power')) return 'Nifty Oil & Gas TRI';
  if (cat.includes('pharma') || cat.includes('health')) return 'Nifty Healthcare TRI';
  if (cat.includes('financial services ex') || cat.includes('fin serv ex')) return 'Nifty Financial Services Ex-Bank TRI';
  if (cat.includes('bank') || cat.includes('financial')) return 'Nifty Financial Services Ex-Bank TRI';
  if (cat.includes('consumer durable')) return 'Nifty 500 TRI';
  if (cat.includes('it') || cat.includes('tech')) return 'Nifty 500 TRI';
  if (cat.includes('consumption') || cat.includes('fmcg')) return 'Nifty 500 TRI';
  if (cat.includes('psu') || cat.includes('infra') || cat.includes('mnc') || cat.includes('dividend')) return 'Nifty 500 TRI';

  // Equity by market cap
  if (cat.includes('small cap')) return 'Nifty Midcap 150 TRI'; // Smallcap 250 has limited data; Midcap 150 is better proxy
  if (cat.includes('mid cap')) return 'Nifty Midcap 150 TRI';
  if (cat.includes('large & mid') || cat.includes('large and mid')) return 'Nifty Midcap 150 TRI';
  if (cat.includes('large cap')) return 'Nifty 500 TRI';
  if (cat.includes('flexi cap')) return 'Nifty 500 TRI';
  if (cat.includes('multi cap')) return 'Nifty 500 TRI';
  if (cat.includes('elss')) return 'Nifty 500 TRI';
  if (cat.includes('value') || cat.includes('contra')) return 'Nifty 500 TRI';
  if (cat.includes('thematic') || cat.includes('sectoral')) return 'Nifty 500 TRI';

  // Hybrid
  if (cat.includes('aggressive hybrid') || cat.includes('balanced advantage') || cat.includes('dynamic asset')) return 'Nifty 50 TRI';
  if (cat.includes('conservative hybrid')) return 'Nifty 50 TRI';

  // Debt / Liquid
  if (cat.includes('short duration') || cat.includes('medium duration') || cat.includes('long duration') ||
      cat.includes('liquid') || cat.includes('overnight')) return 'Nifty 50 TRI';

  // Index / ETF / FoF
  if (cat.includes('index') || cat.includes('etf')) return 'Nifty 50 TRI';
  if (cat.includes('international') || cat.includes('global') || cat.includes('fund of funds')) return 'Nifty 500 TRI';

  // Default fallback
  return 'Nifty 500 TRI';
}
