/**
 * Benchmark Proxy — Auto-fetch benchmark data via mfapi.in index fund NAVs
 *
 * Strategy: Use index fund NAV as a proxy for TRI benchmark.
 * Index fund NAV ≈ TRI minus ~0.1% TER (negligible for analysis purposes).
 * Source: mfapi.in (AMFI data), same source as fund NAV.
 *
 * Note: This is a proxy, not the exact TRI. For exact TRI, download from NSE Indices.
 * Clearly labeled in UI as "Index Fund Proxy (≈ TRI)".
 */

export interface BenchmarkProxyEntry {
  label: string;           // Display name e.g. "Nifty 500 TRI (proxy)"
  schemeCode: number;      // mfapi scheme code for the index fund
  schemeName: string;      // Full scheme name for transparency
  note: string;            // Disclaimer note
}

/**
 * Maps benchmark TRI name → best available index fund proxy on mfapi.
 * Scheme codes verified against mfapi.in search results (Mar 2026).
 */
export const BENCHMARK_PROXY_MAP: Record<string, BenchmarkProxyEntry> = {
  'Nifty 500 TRI': {
    label: 'Nifty 500 TRI (proxy)',
    schemeCode: 147625,
    schemeName: 'Motilal Oswal Nifty 500 Index Fund - Direct Plan',
    note: 'NAV proxy via Motilal Oswal Nifty 500 Index Fund. Tracks TRI minus ~0.1% TER.',
  },
  'Nifty 50 TRI': {
    label: 'Nifty 50 TRI (proxy)',
    schemeCode: 120716,
    schemeName: 'UTI Nifty 50 Index Fund - Direct Plan - Growth',
    note: 'NAV proxy via UTI Nifty 50 Index Fund. Tracks TRI minus ~0.1% TER.',
  },
  'Nifty 100 TRI': {
    label: 'Nifty 100 TRI (proxy)',
    schemeCode: 147666,
    schemeName: 'Axis Nifty 100 Index Fund - Direct Plan - Growth',
    note: 'NAV proxy via Axis Nifty 100 Index Fund. Tracks TRI minus ~0.1% TER.',
  },
  'Nifty Midcap 150 TRI': {
    label: 'Nifty Midcap 150 TRI (proxy)',
    schemeCode: 147622,
    schemeName: 'Motilal Oswal Nifty Midcap 150 Index Fund - Direct Plan',
    note: 'NAV proxy via Motilal Oswal Nifty Midcap 150 Index Fund.',
  },
  'Nifty Smallcap 250 TRI': {
    label: 'Nifty Smallcap 250 TRI (proxy)',
    schemeCode: 147623,
    schemeName: 'Motilal Oswal Nifty Smallcap 250 Index Fund - Direct Plan',
    note: 'NAV proxy via Motilal Oswal Nifty Smallcap 250 Index Fund.',
  },
  'Nifty LargeMidcap 250 TRI': {
    label: 'Nifty LargeMidcap 250 TRI (proxy)',
    schemeCode: 149081,
    schemeName: 'Motilal Oswal Nifty LargeMidcap 250 Index Fund - Direct Plan',
    note: 'NAV proxy via Motilal Oswal Nifty LargeMidcap 250 Index Fund.',
  },
  'Nifty Next 50 TRI': {
    label: 'Nifty Next 50 TRI (proxy)',
    schemeCode: 120684,
    schemeName: 'UTI Nifty Next 50 Index Fund - Direct Plan - Growth',
    note: 'NAV proxy via UTI Nifty Next 50 Index Fund.',
  },
  'Nifty 500 Value 50 TRI': {
    label: 'Nifty 500 Value 50 TRI (proxy)',
    schemeCode: 151739,
    schemeName: 'UTI Nifty 500 Value 50 Index Fund - Direct Plan - Growth',
    note: 'NAV proxy via UTI Nifty 500 Value 50 Index Fund.',
  },
};

/**
 * Auto-detect benchmark name from uploaded CSV filename.
 * Handles common NSE/Stooq/user naming patterns.
 */
export function detectBenchmarkNameFromFilename(filename: string): string | null {
  const f = filename.toLowerCase().replace(/[-_\s.]/g, ' ');

  // Specific index patterns — most specific first
  if (f.includes('defence')) return 'Nifty India Defence TRI';
  if (f.includes('psu') || f.includes('pse')) return 'Nifty PSE TRI';
  if (f.includes('infra')) return 'Nifty Infrastructure TRI';
  if (f.includes('pharma') || f.includes('health')) return 'Nifty Pharma TRI';
  if (f.includes('bank') || f.includes('fin serv') || f.includes('financial')) return 'Nifty Financial Services TRI';
  if (f.includes('it index') || f.includes('nifty it')) return 'Nifty IT TRI';
  if (f.includes('consumption') || f.includes('fmcg')) return 'Nifty India Consumption TRI';
  if (f.includes('energy') || f.includes('power')) return 'Nifty Energy TRI';
  if (f.includes('mnc')) return 'Nifty MNC TRI';
  if (f.includes('smallcap 250') || f.includes('small cap 250') || f.includes('smallcap250')) return 'Nifty Smallcap 250 TRI';
  if (f.includes('smallcap 100') || f.includes('small cap 100')) return 'Nifty Smallcap 100 TRI';
  if (f.includes('smallcap') || f.includes('small cap')) return 'Nifty Smallcap 250 TRI';
  if (f.includes('midcap 150') || f.includes('mid cap 150') || f.includes('midcap150')) return 'Nifty Midcap 150 TRI';
  if (f.includes('midcap 100') || f.includes('mid cap 100')) return 'Nifty Midcap 100 TRI';
  if (f.includes('midcap') || f.includes('mid cap')) return 'Nifty Midcap 150 TRI';
  if (f.includes('largemidcap') || f.includes('large mid') || f.includes('large and mid') || f.includes('largmid')) return 'Nifty LargeMidcap 250 TRI';
  if (f.includes('next 50') || f.includes('next50')) return 'Nifty Next 50 TRI';
  if (f.includes('nifty 100') || f.includes('nifty100') || f.includes('large cap')) return 'Nifty 100 TRI';
  if (f.includes('nifty 500') || f.includes('nifty500') || f.includes('flexi') || f.includes('multi cap') || f.includes('elss')) return 'Nifty 500 TRI';
  if (f.includes('nifty 50') || f.includes('nifty50') || f.includes('sensex')) return 'Nifty 50 TRI';
  if (f.includes('value 50') || f.includes('value50')) return 'Nifty 500 Value 50 TRI';
  if (f.includes('bse 500') || f.includes('bse500')) return 'BSE 500 TRI';
  if (f.includes('bse 200') || f.includes('bse200')) return 'BSE 200 TRI';

  return null; // No match — keep existing name
}

/**
 * Fetch benchmark NAV data from mfapi using an index fund as proxy.
 * Returns array of { date: string (DD-MM-YYYY), nav: number }
 */
export async function fetchBenchmarkProxy(schemeCode: number): Promise<Array<{ date: string; nav: number }>> {
  const url = `https://api.mfapi.in/mf/${schemeCode}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'Accept': 'application/json' },
    });
    clearTimeout(timeout);

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();

    if (!json.data || !Array.isArray(json.data)) {
      throw new Error('Invalid response format from mfapi');
    }

    // mfapi returns newest first — reverse to oldest first
    return [...json.data]
      .reverse()
      .map((d: { date: string; nav: string }) => ({
        date: d.date,
        nav: parseFloat(d.nav),
      }))
      .filter(d => !isNaN(d.nav) && d.nav > 0);
  } catch (err) {
    clearTimeout(timeout);
    throw err;
  }
}
