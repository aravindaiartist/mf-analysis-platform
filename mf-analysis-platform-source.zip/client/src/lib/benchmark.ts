/**
 * benchmark.ts — Benchmark overlay utilities
 * Parses NSE TRI CSV, aligns with fund NAV dates, computes alpha and rolling beat %.
 * All computations are formula-traceable. No hardcoded values.
 */

import type { NavRecord } from './metrics';

export interface BenchmarkRecord {
  date: Date;
  value: number; // rebased to 100 at fund inception
}

export interface AlignedPoint {
  date: Date;
  fundValue: number;   // rebased to 100
  bmValue: number;     // rebased to 100
}

export interface BenchmarkMetrics {
  name: string;
  records: BenchmarkRecord[];
  aligned: AlignedPoint[];

  // Alpha
  cagrBm: number;
  cagrFund: number;
  alphaInception: number;  // fund CAGR - BM CAGR

  // Rolling beat
  rolling1YBeatPct: number | null;
  rolling3YBeatPct: number | null;
  rolling5YBeatPct: number | null;

  // Rolling alpha stats
  rolling1YAlphaMedian: number | null;
  rolling3YAlphaMedian: number | null;

  // Rolling CAGR series (for chart overlay)
  rolling1YSeries: { date: Date; returnPct: number }[];
  rolling3YSeries: { date: Date; returnPct: number }[];
  rolling5YSeries: { date: Date; returnPct: number }[];
  rolling10YSeries: { date: Date; returnPct: number }[];
  // Extended rolling alpha stats
  rolling5YAlphaMedian: number | null;
  rolling10YBeatPct: number | null;
  rolling10YAlphaMedian: number | null;

  // Correlation
  correlation: number;

  // Tracking error (annualised)
  trackingError: number;

  // Information ratio
  informationRatio: number | null;
}

// ─── CSV Parser ───────────────────────────────────────────────────────────────

/**
 * Parse NSE TRI CSV. Accepts multiple formats:
 * - NSE format: "Date,Open,High,Low,Close,SharesTraded,Turnover(Rs. Cr)"
 * - Simple format: "Date,Close" or "date,nav" or "Date,Value"
 * - Also handles Excel-exported CSVs with extra columns
 * Date formats: DD-MM-YYYY, DD/MM/YYYY, YYYY-MM-DD, MM/DD/YYYY
 */
export function parseBenchmarkCSV(csvText: string, bmName: string): BenchmarkRecord[] {
  const lines = csvText.trim().split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) throw new Error('CSV has fewer than 2 lines');

  const header = lines[0].toLowerCase().split(',').map(h => h.trim().replace(/"/g, ''));

  // Find date column
  const dateCol = header.findIndex(h => h.includes('date') || h === 'dt');
  if (dateCol === -1) throw new Error('No date column found in CSV. Expected a column named "Date".');

  // Find value column — prefer Close, then NAV, then Value, then last numeric column
  let valueCol = header.findIndex(h => h === 'close' || h === 'closing');
  if (valueCol === -1) valueCol = header.findIndex(h => h === 'nav' || h === 'value' || h === 'tri' || h === 'index value');
  if (valueCol === -1) valueCol = header.findIndex(h => h === 'open' ? false : /price|level|index/.test(h));
  if (valueCol === -1) {
    // Use last column that isn't date
    valueCol = header.length - 1;
    if (valueCol === dateCol) valueCol = header.length - 2;
  }
  if (valueCol < 0) throw new Error('No value column found. Expected Close, NAV, or Value column.');

  const records: BenchmarkRecord[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map(c => c.trim().replace(/"/g, ''));
    if (cols.length <= Math.max(dateCol, valueCol)) continue;

    const rawDate = cols[dateCol];
    const rawValue = cols[valueCol].replace(/,/g, ''); // remove thousands separator

    const date = parseDate(rawDate);
    const value = parseFloat(rawValue);

    if (!date || isNaN(date.getTime()) || isNaN(value) || value <= 0) continue;

    records.push({ date, value });
  }

  if (records.length < 10) throw new Error(`Only ${records.length} valid rows parsed. Check CSV format — need Date and Close/Value columns.`);

  // Sort ascending
  records.sort((a, b) => a.date.getTime() - b.date.getTime());

  return records;
}

function parseDate(raw: string): Date | null {
  if (!raw) return null;
  raw = raw.trim();

  // YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    const d = new Date(raw);
    return isNaN(d.getTime()) ? null : d;
  }
  // DD-MM-YYYY or DD/MM/YYYY
  if (/^\d{2}[-/]\d{2}[-/]\d{4}$/.test(raw)) {
    const sep = raw.includes('-') ? '-' : '/';
    const [dd, mm, yyyy] = raw.split(sep);
    const d = new Date(`${yyyy}-${mm}-${dd}`);
    return isNaN(d.getTime()) ? null : d;
  }
  // MM/DD/YYYY
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(raw)) {
    const d = new Date(raw);
    return isNaN(d.getTime()) ? null : d;
  }
  // DD-Mon-YYYY (e.g. 01-Jan-2024)
  if (/^\d{2}-[A-Za-z]{3}-\d{4}$/.test(raw)) {
    const d = new Date(raw);
    return isNaN(d.getTime()) ? null : d;
  }
  return null;
}

// ─── Alignment ────────────────────────────────────────────────────────────────

function navAtDate(records: { date: Date; value: number }[], target: Date): number | null {
  if (!records.length) return null;
  let lo = 0, hi = records.length - 1;
  while (lo < hi) {
    const mid = Math.floor((lo + hi) / 2);
    if (records[mid].date.getTime() < target.getTime()) lo = mid + 1;
    else hi = mid;
  }
  if (lo === 0) return records[0].value;
  const before = records[lo - 1];
  const after = records[lo];
  return Math.abs(before.date.getTime() - target.getTime()) <=
         Math.abs(after.date.getTime() - target.getTime())
    ? before.value : after.value;
}

function median(arr: number[]): number {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 === 0 ? (s[m - 1] + s[m]) / 2 : s[m];
}

// ─── Main computation ─────────────────────────────────────────────────────────

export function computeBenchmarkMetrics(
  bmRecords: BenchmarkRecord[],
  bmName: string,
  fundNavRecords: NavRecord[],
): BenchmarkMetrics {
  const fundSorted = [...fundNavRecords].sort((a, b) => a.date.getTime() - b.date.getTime());
  const bmSorted = [...bmRecords].sort((a, b) => a.date.getTime() - b.date.getTime());

  const inceptionDate = fundSorted[0].date;
  const latestDate = fundSorted[fundSorted.length - 1].date;

  // Rebase BM to 100 at fund inception
  const bmAtInception = navAtDate(bmSorted, inceptionDate);
  if (!bmAtInception) throw new Error('Benchmark has no data near fund inception date');

  const rebasedBm = bmSorted
    .filter(r => r.date >= inceptionDate && r.date <= latestDate)
    .map(r => ({ date: r.date, value: (r.value / bmAtInception) * 100 }));

  // Rebase fund to 100
  const fundAtInception = fundSorted[0].nav;
  const rebasedFund = fundSorted.map(r => ({ date: r.date, value: (r.nav / fundAtInception) * 100 }));

  // Align: for each fund date, find nearest BM value
  const aligned: AlignedPoint[] = rebasedFund.map(f => {
    const bm = navAtDate(rebasedBm, f.date);
    return bm !== null ? { date: f.date, fundValue: f.value, bmValue: bm } : null;
  }).filter((p): p is AlignedPoint => p !== null);

  // CAGR
  const ageYears = (latestDate.getTime() - inceptionDate.getTime()) / (365.25 * 86400000);
  const cagrFund = ageYears > 0 ? (Math.pow(fundSorted[fundSorted.length - 1].nav / fundAtInception, 1 / ageYears) - 1) * 100 : 0;
  const bmLatest = navAtDate(rebasedBm, latestDate);
  const cagrBm = bmLatest && ageYears > 0 ? (Math.pow(bmLatest / 100, 1 / ageYears) - 1) * 100 : 0;
  const alphaInception = cagrFund - cagrBm;

  // Rolling CAGR series (for chart overlay)
  function rollingCAGRSeries(windowYears: number): { date: Date; returnPct: number }[] {
    const windowDays = Math.round(windowYears * 252);
    if (aligned.length <= windowDays) return [];
    const result: { date: Date; returnPct: number }[] = [];
    for (let i = windowDays; i < aligned.length; i += 5) {
      const start = aligned[i - windowDays];
      const end = aligned[i];
      const actualYears = (end.date.getTime() - start.date.getTime()) / (365.25 * 86400000);
      if (actualYears < windowYears * 0.8) continue;
      const bmRet = (Math.pow(end.bmValue / start.bmValue, 1 / actualYears) - 1) * 100;
      if (isFinite(bmRet)) result.push({ date: end.date, returnPct: bmRet });
    }
    return result;
  }
  const bmRolling1Y = rollingCAGRSeries(1);
  const bmRolling3Y = rollingCAGRSeries(3);
  const bmRolling5Y = rollingCAGRSeries(5);
  const bmRolling10Y = rollingCAGRSeries(10);

  // Rolling beat %
  function rollingBeat(windowYears: number): { beatPct: number | null; alphaMedian: number | null } {
    const windowDays = Math.round(windowYears * 252);
    if (aligned.length <= windowDays) return { beatPct: null, alphaMedian: null };
    let beats = 0, total = 0;
    const alphas: number[] = [];
    for (let i = windowDays; i < aligned.length; i += 5) {
      const start = aligned[i - windowDays];
      const end = aligned[i];
      const actualYears = (end.date.getTime() - start.date.getTime()) / (365.25 * 86400000);
      if (actualYears < windowYears * 0.8) continue;
      const fundRet = (Math.pow(end.fundValue / start.fundValue, 1 / actualYears) - 1) * 100;
      const bmRet = (Math.pow(end.bmValue / start.bmValue, 1 / actualYears) - 1) * 100;
      if (fundRet > bmRet) beats++;
      alphas.push(fundRet - bmRet);
      total++;
    }
    return {
      beatPct: total > 0 ? (beats / total) * 100 : null,
      alphaMedian: alphas.length > 0 ? median(alphas) : null,
    };
  }

  const r1 = rollingBeat(1);
  const r3 = rollingBeat(3);
  const r5 = rollingBeat(5);
  const r10 = rollingBeat(10);

  // Correlation (fund vs BM daily returns)
  const fundReturns: number[] = [];
  const bmReturns: number[] = [];
  for (let i = 1; i < aligned.length; i++) {
    fundReturns.push(aligned[i].fundValue / aligned[i - 1].fundValue - 1);
    bmReturns.push(aligned[i].bmValue / aligned[i - 1].bmValue - 1);
  }
  const n = fundReturns.length;
  const meanF = fundReturns.reduce((s, v) => s + v, 0) / n;
  const meanB = bmReturns.reduce((s, v) => s + v, 0) / n;
  const cov = fundReturns.reduce((s, v, i) => s + (v - meanF) * (bmReturns[i] - meanB), 0) / n;
  const stdF = Math.sqrt(fundReturns.reduce((s, v) => s + Math.pow(v - meanF, 2), 0) / n);
  const stdB = Math.sqrt(bmReturns.reduce((s, v) => s + Math.pow(v - meanB, 2), 0) / n);
  const correlation = stdF > 0 && stdB > 0 ? cov / (stdF * stdB) : 0;

  // Tracking error (annualised std dev of daily return differences)
  const diffs = fundReturns.map((f, i) => f - bmReturns[i]);
  const meanDiff = diffs.reduce((s, v) => s + v, 0) / diffs.length;
  const teDaily = Math.sqrt(diffs.reduce((s, v) => s + Math.pow(v - meanDiff, 2), 0) / diffs.length);
  const trackingError = teDaily * Math.sqrt(252) * 100;

  // Information ratio
  const annualExcessReturn = alphaInception;
  const informationRatio = trackingError > 0 ? annualExcessReturn / trackingError : null;

  return {
    name: bmName,
    records: rebasedBm,
    aligned,
    cagrBm,
    cagrFund,
    alphaInception,
    rolling1YBeatPct: r1.beatPct,
    rolling3YBeatPct: r3.beatPct,
    rolling5YBeatPct: r5.beatPct,
    rolling1YAlphaMedian: r1.alphaMedian,
    rolling3YAlphaMedian: r3.alphaMedian,
    rolling1YSeries: bmRolling1Y,
    rolling3YSeries: bmRolling3Y,
    rolling5YSeries: bmRolling5Y,
    rolling10YSeries: bmRolling10Y,
    rolling5YAlphaMedian: r5.alphaMedian,
    rolling10YBeatPct: r10.beatPct,
    rolling10YAlphaMedian: r10.alphaMedian,
    correlation,
    trackingError,
    informationRatio,
  };
}
