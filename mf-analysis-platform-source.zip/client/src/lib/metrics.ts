/**
 * MF Analysis Engine — metrics.ts
 * All computations are derived purely from daily NAV data.
 * No hardcoded values. No speculation. Every number is formula-traceable.
 *
 * Edge-case hardening:
 * - All array accesses guarded against empty arrays
 * - Division by zero guarded at every ratio computation
 * - NaN propagation blocked with isFinite checks
 * - XIRR: NaN result returns null (not NaN) so UI can show N/A
 * - Rolling returns: window > data length returns empty array (not crash)
 * - Drawdown: handles flat NAV series (no peak movement)
 * - Annual returns: skips years with < 2 records
 * - SIP cohorts: skips cohorts where XIRR diverges (NaN)
 */

export interface NavRecord {
  date: Date;
  nav: number;
}

export interface AnnualReturn {
  year: number;
  label: string;
  startNav: number;
  endNav: number;
  returnPct: number;
  tradingDays: number;
}

export interface DrawdownEpisode {
  id: number;
  peakDate: Date;
  peakNav: number;
  troughDate: Date;
  troughNav: number;
  fallPct: number;
  recoveryDate: Date | null;
  recoveryDays: number | null;
  status: 'Recovered' | 'Ongoing';
}

export interface DrawdownPoint {
  date: Date;
  drawdownPct: number;
}

export interface RollingReturn {
  date: Date;
  returnPct: number;
}

export interface RollingStats {
  best: number;
  worst: number;
  median: number;
  count: number;
  pctPositive: number;
}

export interface SIPCohort {
  startDate: Date;
  endDate: Date;
  months: number;
  totalInvested: number;
  finalValue: number;
  xirr: number;
  experience: 'Excellent' | 'Good' | 'Moderate' | 'Poor';
}

export interface SIPStats {
  best: number;
  worst: number;
  median: number;
  pctAbove15: number;
  pctAbove12: number;
  pctPositive: number;
  cohortCount: number;
}

export interface FundMetrics {
  inceptionDate: Date;
  latestDate: Date;
  inceptionNav: number;
  latestNav: number;
  totalRecords: number;
  ageYears: number;

  cagrInception: number;
  cagr1Y: number | null;
  cagr2Y: number | null;
  cagr3Y: number | null;
  cagr5Y: number | null;
  // Short-period trailing returns (simple point-to-point, not annualized)
  ret1W: number | null;
  ret1M: number | null;
  ret3M: number | null;
  ret6M: number | null;
  annualReturns: AnnualReturn[];

  maxDrawdown: number;
  maxDrawdownPeakDate: Date;
  maxDrawdownTroughDate: Date;
  currentDrawdownFromATH: number;
  athNav: number;
  athDate: Date;
  stdDevAnnual: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;

  drawdownSeries: DrawdownPoint[];
  drawdownEpisodes: DrawdownEpisode[];

  rolling1Y: RollingReturn[];
  rolling3Y: RollingReturn[];
  rolling5Y: RollingReturn[];
  rolling10Y: RollingReturn[];
  rolling1YStats: RollingStats | null;
  rolling3YStats: RollingStats | null;
  rolling5YStats: RollingStats | null;
  rolling10YStats: RollingStats | null;

  growthSeries: { date: Date; value: number }[];

  sip3YStats: SIPStats | null;
  sip5YStats: SIPStats | null;
  sip3YCohorts: SIPCohort[];
  sip5YCohorts: SIPCohort[];

  monthlyReturns: { year: number; month: number; returnPct: number }[];
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function yearsBetween(a: Date, b: Date): number {
  return (b.getTime() - a.getTime()) / (365.25 * 86400000);
}

function cagrCalc(startNav: number, endNav: number, years: number): number {
  if (years <= 0 || startNav <= 0 || endNav <= 0) return 0;
  const result = (Math.pow(endNav / startNav, 1 / years) - 1) * 100;
  return isFinite(result) ? result : 0;
}

function median(arr: number[]): number {
  if (!arr.length) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

// Newton-Raphson XIRR — returns null if it doesn't converge
export function xirr(cashflows: number[], dates: Date[], guess = 0.1): number | null {
  if (cashflows.length < 2 || dates.length !== cashflows.length) return null;
  const maxIter = 200;
  const tol = 1e-7;
  let rate = guess;
  const t0 = dates[0].getTime();

  for (let i = 0; i < maxIter; i++) {
    let f = 0, df = 0;
    for (let j = 0; j < cashflows.length; j++) {
      const t = (dates[j].getTime() - t0) / (365.25 * 86400000);
      if (!isFinite(t)) return null;
      const base = 1 + rate;
      if (base <= 0) return null;
      const v = Math.pow(base, t);
      if (!isFinite(v) || v === 0) return null;
      f += cashflows[j] / v;
      df -= t * cashflows[j] / (v * base);
    }
    if (df === 0 || !isFinite(df)) return null;
    const newRate = rate - f / df;
    if (!isFinite(newRate) || newRate < -0.99) return null;
    if (Math.abs(newRate - rate) < tol) return newRate * 100;
    rate = newRate;
  }
  return null; // did not converge
}

// Binary search: find NAV closest to a target date
export function navAtDate(records: NavRecord[], targetDate: Date): number | null {
  if (!records.length) return null;
  let lo = 0, hi = records.length - 1;
  while (lo < hi) {
    const mid = Math.floor((lo + hi) / 2);
    if (records[mid].date.getTime() < targetDate.getTime()) lo = mid + 1;
    else hi = mid;
  }
  if (lo === 0) return records[0].nav;
  const before = records[lo - 1];
  const after = records[lo];
  const diffBefore = Math.abs(before.date.getTime() - targetDate.getTime());
  const diffAfter = Math.abs(after.date.getTime() - targetDate.getTime());
  return diffBefore <= diffAfter ? before.nav : after.nav;
}

// ─── Main computation ─────────────────────────────────────────────────────────

export function computeMetrics(records: NavRecord[]): FundMetrics {
  if (!records || records.length < 5) {
    throw new Error(`Insufficient NAV data: ${records?.length ?? 0} records. Need at least 5.`);
  }

  const data = [...records]
    .filter(r => r.nav > 0 && !isNaN(r.nav) && !isNaN(r.date.getTime()))
    .sort((a, b) => a.date.getTime() - b.date.getTime());

  if (data.length < 5) throw new Error('Insufficient valid NAV records after filtering.');

  const n = data.length;
  const inceptionDate = data[0].date;
  const latestDate = data[n - 1].date;
  const inceptionNav = data[0].nav;
  const latestNav = data[n - 1].nav;
  const ageYears = yearsBetween(inceptionDate, latestDate);

  if (ageYears <= 0) throw new Error('Fund inception date equals latest date — cannot compute returns.');

  // ── CAGR ──────────────────────────────────────────────────────────────────
  const cagrInception = cagrCalc(inceptionNav, latestNav, ageYears);

  function cagrForYears(years: number): number | null {
    if (ageYears < years * 0.9) return null;
    const startDate = new Date(latestDate.getTime() - years * 365.25 * 86400000);
    const startNav = navAtDate(data, startDate);
    if (!startNav || startNav <= 0) return null;
    const result = cagrCalc(startNav, latestNav, years);
    return isFinite(result) ? result : null;
  }

  const cagr1Y = cagrForYears(1);
  const cagr2Y = cagrForYears(2);
  const cagr3Y = cagrForYears(3);
  const cagr5Y = cagrForYears(5);

  // ── SHORT-PERIOD TRAILING RETURNS (simple, not annualized) ────────────────
  function retForDays(days: number): number | null {
    const startDate = new Date(latestDate.getTime() - days * 86400000);
    const startNav = navAtDate(data, startDate);
    if (!startNav || startNav <= 0) return null;
    const r = ((latestNav / startNav) - 1) * 100;
    return isFinite(r) ? r : null;
  }
  const ret1W = retForDays(7);
  const ret1M = retForDays(30);
  const ret3M = retForDays(91);
  const ret6M = retForDays(182);

  // ── ANNUAL RETURNS ────────────────────────────────────────────────────────
  const annualReturns: AnnualReturn[] = [];
  const uniqueYears = Array.from(new Set(data.map(d => d.date.getFullYear()))).sort((a, b) => a - b);

  for (const year of uniqueYears) {
    const yearData = data.filter(d => d.date.getFullYear() === year);
    if (yearData.length < 2) continue;
    const startNav = yearData[0].nav;
    const endNav = yearData[yearData.length - 1].nav;
    if (startNav <= 0) continue;
    const returnPct = ((endNav / startNav) - 1) * 100;
    if (!isFinite(returnPct)) continue;
    const isFirst = year === uniqueYears[0];
    const isLast = year === uniqueYears[uniqueYears.length - 1];
    const label = isFirst
      ? `${year} (partial, ${yearData[0].date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })} – ${yearData[yearData.length - 1].date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })})`
      : isLast
        ? `${year} (partial, to ${yearData[yearData.length - 1].date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })})`
        : `${year}`;
    annualReturns.push({ year, label, startNav, endNav, returnPct, tradingDays: yearData.length });
  }

  // ── DAILY RETURNS ─────────────────────────────────────────────────────────
  const dailyReturns: number[] = [];
  for (let i = 1; i < n; i++) {
    if (data[i - 1].nav > 0) {
      const r = (data[i].nav / data[i - 1].nav) - 1;
      if (isFinite(r)) dailyReturns.push(r);
    }
  }

  const meanDailyReturn = dailyReturns.length > 0
    ? dailyReturns.reduce((s, r) => s + r, 0) / dailyReturns.length
    : 0;
  const variance = dailyReturns.length > 0
    ? dailyReturns.reduce((s, r) => s + Math.pow(r - meanDailyReturn, 2), 0) / dailyReturns.length
    : 0;
  const stdDevDaily = Math.sqrt(variance);
  const stdDevAnnual = isFinite(stdDevDaily) ? stdDevDaily * Math.sqrt(252) * 100 : 0;

  const riskFreeDaily = 0.065 / 252;
  const excessReturns = dailyReturns.map(r => r - riskFreeDaily);
  const meanExcess = excessReturns.length > 0
    ? excessReturns.reduce((s, r) => s + r, 0) / excessReturns.length
    : 0;
  const sharpeRatio = stdDevDaily > 0 && isFinite(stdDevDaily)
    ? (meanExcess / stdDevDaily) * Math.sqrt(252)
    : 0;

  // Sortino
  const downsideReturns = dailyReturns.filter(r => r < riskFreeDaily);
  const downsideVariance = downsideReturns.length > 0 && dailyReturns.length > 0
    ? downsideReturns.reduce((s, r) => s + Math.pow(r - riskFreeDaily, 2), 0) / dailyReturns.length
    : 0;
  const downsideStd = Math.sqrt(downsideVariance) * Math.sqrt(252);
  const annualReturn = ageYears > 0 ? (Math.pow(latestNav / inceptionNav, 1 / ageYears) - 1) : 0;
  const sortinoRatio = downsideStd > 0 && isFinite(downsideStd) ? (annualReturn - 0.065) / downsideStd : 0;

  // ── DRAWDOWN SERIES ───────────────────────────────────────────────────────
  const drawdownSeries: DrawdownPoint[] = [];
  let peak = data[0].nav;
  let maxDD = 0;
  let maxDDPeakDate = data[0].date;
  let maxDDTroughDate = data[0].date;
  let currentPeakDate = data[0].date;

  for (const rec of data) {
    if (rec.nav > peak) {
      peak = rec.nav;
      currentPeakDate = rec.date;
    }
    const dd = peak > 0 ? ((rec.nav - peak) / peak) * 100 : 0;
    drawdownSeries.push({ date: rec.date, drawdownPct: isFinite(dd) ? dd : 0 });
    if (dd < maxDD) {
      maxDD = dd;
      maxDDTroughDate = rec.date;
      maxDDPeakDate = currentPeakDate;
    }
  }

  const athNav = data.reduce((m, d) => d.nav > m ? d.nav : m, data[0].nav);
  const athRecord = data.find(d => d.nav === athNav);
  const athDate = athRecord ? athRecord.date : latestDate;
  const currentDrawdownFromATH = athNav > 0 ? ((latestNav - athNav) / athNav) * 100 : 0;
  const calmarRatio = maxDD !== 0 && isFinite(maxDD)
    ? (cagrInception / 100) / Math.abs(maxDD / 100)
    : 0;

  // ── DRAWDOWN EPISODES (threshold: -5%) ────────────────────────────────────
  const drawdownEpisodes: DrawdownEpisode[] = [];
  let inEpisode = false;
  let epPeak = data[0].nav;
  let epPeakDate = data[0].date;
  let epTrough = data[0].nav;
  let epTroughDate = data[0].date;
  let epId = 1;
  const EPISODE_THRESHOLD = -5;

  for (let i = 0; i < n; i++) {
    const rec = data[i];
    if (!inEpisode) {
      if (rec.nav >= epPeak) {
        epPeak = rec.nav;
        epPeakDate = rec.date;
        epTrough = rec.nav;
        epTroughDate = rec.date;
      } else {
        const dd = epPeak > 0 ? ((rec.nav - epPeak) / epPeak) * 100 : 0;
        if (dd <= EPISODE_THRESHOLD) {
          inEpisode = true;
          epTrough = rec.nav;
          epTroughDate = rec.date;
        }
      }
    } else {
      if (rec.nav < epTrough) {
        epTrough = rec.nav;
        epTroughDate = rec.date;
      } else if (epPeak > 0 && rec.nav >= epPeak) {
        // Recovered
        const fallPct = epPeak > 0 ? ((epTrough - epPeak) / epPeak) * 100 : 0;
        const recoveryDays = Math.round(Math.abs((rec.date.getTime() - epPeakDate.getTime()) / 86400000));
        drawdownEpisodes.push({
          id: epId++,
          peakDate: epPeakDate,
          peakNav: epPeak,
          troughDate: epTroughDate,
          troughNav: epTrough,
          fallPct: isFinite(fallPct) ? fallPct : 0,
          recoveryDate: rec.date,
          recoveryDays,
          status: 'Recovered',
        });
        inEpisode = false;
        epPeak = rec.nav;
        epPeakDate = rec.date;
        epTrough = rec.nav;
        epTroughDate = rec.date;
      }
    }
  }
  // Close any ongoing episode
  if (inEpisode) {
    const fallPct = epPeak > 0 ? ((epTrough - epPeak) / epPeak) * 100 : 0;
    drawdownEpisodes.push({
      id: epId++,
      peakDate: epPeakDate,
      peakNav: epPeak,
      troughDate: epTroughDate,
      troughNav: epTrough,
      fallPct: isFinite(fallPct) ? fallPct : 0,
      recoveryDate: null,
      recoveryDays: null,
      status: 'Ongoing',
    });
  }

  // ── ROLLING RETURNS ───────────────────────────────────────────────────────
  function computeRolling(windowYears: number): RollingReturn[] {
    const windowDays = Math.round(windowYears * 252);
    if (n <= windowDays) return [];
    const result: RollingReturn[] = [];
    for (let i = windowDays; i < n; i += 5) {
      const startRec = data[i - windowDays];
      const endRec = data[i];
      if (!startRec || !endRec || startRec.nav <= 0) continue;
      const actualYears = yearsBetween(startRec.date, endRec.date);
      if (actualYears < windowYears * 0.8) continue;
      const r = cagrCalc(startRec.nav, endRec.nav, actualYears);
      if (isFinite(r)) result.push({ date: endRec.date, returnPct: r });
    }
    return result;
  }

  function rollingStats(arr: RollingReturn[]): RollingStats | null {
    if (!arr.length) return null;
    const vals = arr.map(r => r.returnPct);
    const positive = vals.filter(v => v > 0).length;
    return {
      best: Math.max(...vals),
      worst: Math.min(...vals),
      median: median(vals),
      count: vals.length,
      pctPositive: (positive / vals.length) * 100,
    };
  }

  const rolling1Y = computeRolling(1);
  const rolling3Y = computeRolling(3);
  const rolling5Y = computeRolling(5);
  const rolling10Y = computeRolling(10);

  // ── GROWTH OF ₹100 ────────────────────────────────────────────────────────
  const growthSeries = data
    .filter((_, i) => i % 3 === 0 || i === n - 1)
    .map(d => ({
      date: d.date,
      value: inceptionNav > 0 ? (d.nav / inceptionNav) * 100 : 100,
    }));

  // ── SIP COHORTS ───────────────────────────────────────────────────────────
  function computeSIPCohorts(months: number): SIPCohort[] {
    const cohorts: SIPCohort[] = [];
    const windowDays = months * 30;
    const SIP_AMOUNT = 10000;

    for (let startIdx = 0; startIdx < n - windowDays; startIdx += 21) {
      const startDate = data[startIdx].date;
      const endDate = new Date(startDate.getTime() + windowDays * 86400000);
      if (endDate > latestDate) break;

      const cashflows: number[] = [];
      const cfDates: Date[] = [];

      // Monthly SIP installments
      for (let m = 0; m < months; m++) {
        const sipDate = new Date(startDate.getTime() + m * 30 * 86400000);
        if (sipDate > latestDate) break;
        const nav = navAtDate(data, sipDate);
        if (!nav || nav <= 0) continue;
        cashflows.push(-SIP_AMOUNT);
        cfDates.push(sipDate);
      }

      if (cashflows.length < months * 0.8) continue;

      // Final redemption
      const finalNav = navAtDate(data, endDate);
      if (!finalNav || finalNav <= 0) continue;

      const totalUnits = cashflows.reduce((units, cf, i) => {
        const nav = navAtDate(data, cfDates[i]);
        return nav && nav > 0 ? units + Math.abs(cf) / nav : units;
      }, 0);

      const finalValue = totalUnits * finalNav;
      const totalInvested = Math.abs(cashflows.reduce((s, c) => s + c, 0));

      cashflows.push(finalValue);
      cfDates.push(endDate);

      const xirrResult = xirr(cashflows, cfDates);
      if (xirrResult === null || !isFinite(xirrResult) || xirrResult < -100 || xirrResult > 500) continue;

      const experience: SIPCohort['experience'] =
        xirrResult >= 15 ? 'Excellent' :
        xirrResult >= 10 ? 'Good' :
        xirrResult >= 0  ? 'Moderate' : 'Poor';

      cohorts.push({
        startDate,
        endDate,
        months,
        totalInvested,
        finalValue,
        xirr: xirrResult,
        experience,
      });
    }
    return cohorts;
  }

  function sipStats(cohorts: SIPCohort[]): SIPStats | null {
    if (!cohorts.length) return null;
    const vals = cohorts.map(c => c.xirr);
    return {
      best: Math.max(...vals),
      worst: Math.min(...vals),
      median: median(vals),
      pctAbove15: (vals.filter(v => v >= 15).length / vals.length) * 100,
      pctAbove12: (vals.filter(v => v >= 12).length / vals.length) * 100,
      pctPositive: (vals.filter(v => v > 0).length / vals.length) * 100,
      cohortCount: cohorts.length,
    };
  }

  const sip3YCohorts = ageYears >= 3 ? computeSIPCohorts(36) : [];
  const sip5YCohorts = ageYears >= 5 ? computeSIPCohorts(60) : [];

  // ── MONTHLY RETURNS ───────────────────────────────────────────────────────
  const monthlyReturns: { year: number; month: number; returnPct: number }[] = [];
  const monthGroups = new Map<string, NavRecord[]>();

  for (const rec of data) {
    // Use 1-based month (1=Jan … 12=Dec) to match heatmap lookup (mi+1)
    const key = `${rec.date.getFullYear()}-${rec.date.getMonth() + 1}`;
    if (!monthGroups.has(key)) monthGroups.set(key, []);
    monthGroups.get(key)!.push(rec);
  }

  for (const [key, recs] of Array.from(monthGroups.entries())) {
    if (recs.length < 2) continue;
    const [year, month] = key.split('-').map(Number);
    const startNav = recs[0].nav;
    const endNav = recs[recs.length - 1].nav;
    if (startNav <= 0) continue;
    const returnPct = ((endNav / startNav) - 1) * 100;
    if (isFinite(returnPct)) {
      monthlyReturns.push({ year, month, returnPct });
    }
  }
  monthlyReturns.sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);

  return {
    inceptionDate,
    latestDate,
    inceptionNav,
    latestNav,
    totalRecords: n,
    ageYears,
    cagrInception,
    cagr1Y,
    cagr2Y,
    cagr3Y,
    cagr5Y,
    ret1W,
    ret1M,
    ret3M,
    ret6M,
    annualReturns,
    maxDrawdown: maxDD,
    maxDrawdownPeakDate: maxDDPeakDate,
    maxDrawdownTroughDate: maxDDTroughDate,
    currentDrawdownFromATH,
    athNav,
    athDate,
    stdDevAnnual,
    sharpeRatio: isFinite(sharpeRatio) ? sharpeRatio : 0,
    sortinoRatio: isFinite(sortinoRatio) ? sortinoRatio : 0,
    calmarRatio: isFinite(calmarRatio) ? calmarRatio : 0,
    drawdownSeries,
    drawdownEpisodes,
    rolling1Y,
    rolling3Y,
    rolling5Y,
    rolling10Y,
    rolling1YStats: rollingStats(rolling1Y),
    rolling3YStats: rollingStats(rolling3Y),
    rolling5YStats: rollingStats(rolling5Y),
    rolling10YStats: rollingStats(rolling10Y),
    growthSeries,
    sip3YStats: sipStats(sip3YCohorts),
    sip5YStats: sipStats(sip5YCohorts),
    sip3YCohorts,
    sip5YCohorts,
    monthlyReturns,
  };
}

// ─── Scoring engine ───────────────────────────────────────────────────────────

export interface ScoringRow {
  parameter: string;
  weight: number;
  score: number;
  evidence: string;
}

export interface ScoringResult {
  rows: ScoringRow[];
  totalScore: number;
  verdict: string;
  verdictColor: 'green' | 'amber' | 'red';
  stage: string;
  lumpsumDecision: string;
}

export const EPISODE_THRESHOLD_DISPLAY = 5;

export function computeScoring(m: FundMetrics): ScoringResult {
  const rows: ScoringRow[] = [];

  // 1. Rolling Consistency (15%)
  const r1 = m.rolling1YStats;
  const r3 = m.rolling3YStats;
  const r5 = m.rolling5YStats;
  let rollScore = 5.0;
  let rollEvidence = '';
  if (r1) {
    rollEvidence += `1Y rolling: best=${r1.best.toFixed(1)}%, worst=${r1.worst.toFixed(1)}%, median=${r1.median.toFixed(1)}%, ${r1.pctPositive.toFixed(0)}% positive (${r1.count} windows). `;
    rollScore = r1.pctPositive >= 90 ? 8.5 : r1.pctPositive >= 75 ? 7.5 : r1.pctPositive >= 60 ? 6.5 : 5.0;
  }
  if (r3) {
    rollEvidence += `3Y rolling: best=${r3.best.toFixed(1)}%, worst=${r3.worst.toFixed(1)}%, median=${r3.median.toFixed(1)}% (${r3.count} windows). `;
    const r3Score = r3.pctPositive >= 95 ? 9.0 : r3.pctPositive >= 85 ? 8.0 : r3.pctPositive >= 70 ? 7.0 : 5.5;
    rollScore = (rollScore + r3Score) / 2;
  }
  if (r5) {
    rollEvidence += `5Y rolling: best=${r5.best.toFixed(1)}%, worst=${r5.worst.toFixed(1)}%, median=${r5.median.toFixed(1)}% (${r5.count} windows). `;
    const r5Score = r5.pctPositive >= 98 ? 9.5 : r5.pctPositive >= 90 ? 8.5 : r5.pctPositive >= 80 ? 7.5 : 6.0;
    rollScore = (rollScore * 2 + r5Score) / 3;
  }
  if (!r1 && !r3 && !r5) rollEvidence = 'Insufficient history for rolling return analysis (need >1 year of data).';
  rows.push({ parameter: 'Rolling Consistency', weight: 15, score: Math.round(rollScore * 2) / 2, evidence: rollEvidence.trim() });

  // 2. Risk Management (15%)
  const ddScore =
    m.maxDrawdown > -10 ? 9.5 :
    m.maxDrawdown > -20 ? 8.0 :
    m.maxDrawdown > -30 ? 6.5 :
    m.maxDrawdown > -40 ? 5.0 :
    m.maxDrawdown > -50 ? 3.5 : 2.0;
  const sharpeScore = m.sharpeRatio > 2 ? 9.5 : m.sharpeRatio > 1.5 ? 8.5 : m.sharpeRatio > 1 ? 7.5 : m.sharpeRatio > 0.5 ? 6.0 : 4.0;
  const riskScore = (ddScore + sharpeScore) / 2;
  rows.push({
    parameter: 'Risk Management',
    weight: 15,
    score: Math.round(riskScore * 2) / 2,
    evidence: `Max DD: ${m.maxDrawdown.toFixed(2)}% (${m.maxDrawdownPeakDate.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })} → ${m.maxDrawdownTroughDate.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}). Sharpe: ${m.sharpeRatio.toFixed(2)}. Sortino: ${m.sortinoRatio.toFixed(2)}. Calmar: ${m.calmarRatio.toFixed(2)}. Ann. Std Dev: ${m.stdDevAnnual.toFixed(1)}%.`,
  });

  // 3. Return Quality (15%)
  const retScore =
    m.cagrInception > 25 ? 9.0 :
    m.cagrInception > 18 ? 8.0 :
    m.cagrInception > 12 ? 7.0 :
    m.cagrInception > 8  ? 6.0 : 4.5;
  let retEvidence = `CAGR since inception: ${m.cagrInception.toFixed(2)}% (${m.ageYears.toFixed(1)} years). `;
  if (m.cagr1Y !== null) retEvidence += `1Y: ${m.cagr1Y.toFixed(2)}%. `;
  if (m.cagr2Y !== null) retEvidence += `2Y: ${m.cagr2Y.toFixed(2)}%. `;
  if (m.cagr3Y !== null) retEvidence += `3Y: ${m.cagr3Y.toFixed(2)}%. `;
  if (m.cagr5Y !== null) retEvidence += `5Y: ${m.cagr5Y.toFixed(2)}%. `;
  rows.push({ parameter: 'Return Quality (Absolute)', weight: 15, score: Math.round(retScore * 2) / 2, evidence: retEvidence.trim() });

  // 4. SIP Experience (15%)
  let sipScore = 5.0;
  let sipEvidence = '';
  const s3 = m.sip3YStats;
  const s5 = m.sip5YStats;
  if (s5) {
    sipScore = s5.pctAbove15 >= 80 ? 9.5 : s5.pctAbove15 >= 60 ? 8.5 : s5.pctAbove15 >= 40 ? 7.5 : s5.pctAbove15 >= 20 ? 6.0 : 4.5;
    sipEvidence += `5Y SIP: best=${s5.best.toFixed(1)}%, worst=${s5.worst.toFixed(1)}%, median=${s5.median.toFixed(1)}%, ${s5.pctAbove15.toFixed(0)}% cohorts >15% XIRR, ${s5.pctPositive.toFixed(0)}% positive (${s5.cohortCount} cohorts). `;
  } else if (s3) {
    sipScore = s3.pctAbove15 >= 70 ? 8.5 : s3.pctAbove15 >= 50 ? 7.5 : s3.pctAbove15 >= 30 ? 6.5 : 5.0;
    sipEvidence += `3Y SIP: best=${s3.best.toFixed(1)}%, worst=${s3.worst.toFixed(1)}%, median=${s3.median.toFixed(1)}%, ${s3.pctAbove15.toFixed(0)}% cohorts >15% XIRR, ${s3.pctPositive.toFixed(0)}% positive (${s3.cohortCount} cohorts). 5Y SIP: not available (fund < 5Y). `;
  } else {
    sipEvidence = 'No completed SIP cohorts available (fund < 3 years old). Score is provisional at 5.0.';
    sipScore = 5.0;
  }
  rows.push({ parameter: 'SIP Investor Experience', weight: 15, score: Math.round(sipScore * 2) / 2, evidence: sipEvidence.trim() });

  // 5. Drawdown Recovery (10%)
  const recoveredEpisodes = m.drawdownEpisodes.filter(e => e.status === 'Recovered');
  const ongoingEpisodes = m.drawdownEpisodes.filter(e => e.status === 'Ongoing');
  const avgRecoveryDays = recoveredEpisodes.length
    ? recoveredEpisodes.reduce((s, e) => s + (e.recoveryDays || 0), 0) / recoveredEpisodes.length
    : null;
  const ddRecovScore =
    ongoingEpisodes.length > 0 && ongoingEpisodes[0].fallPct < -20 ? 4.5 :
    avgRecoveryDays === null ? 5.0 :
    avgRecoveryDays < 90 ? 9.0 :
    avgRecoveryDays < 180 ? 7.5 :
    avgRecoveryDays < 365 ? 6.0 : 4.5;
  const ddRecovEvidence = `${m.drawdownEpisodes.length} episodes (>-${EPISODE_THRESHOLD_DISPLAY}% threshold). ${recoveredEpisodes.length} recovered${avgRecoveryDays !== null ? `, avg ${Math.round(avgRecoveryDays)} days` : ''}. ${ongoingEpisodes.length} ongoing${ongoingEpisodes.length > 0 ? ` (current: ${ongoingEpisodes[0].fallPct.toFixed(1)}%)` : ''}.`;
  rows.push({ parameter: 'Drawdown Recovery Speed', weight: 10, score: Math.round(ddRecovScore * 2) / 2, evidence: ddRecovEvidence });

  // 6. Annual Return Consistency (10%)
  const annualVals = m.annualReturns.map(a => a.returnPct);
  const positiveYears = annualVals.filter(v => v > 0).length;
  const pctPositiveYears = annualVals.length > 0 ? (positiveYears / annualVals.length) * 100 : 0;
  const annualConsistScore = pctPositiveYears >= 90 ? 9.0 : pctPositiveYears >= 75 ? 7.5 : pctPositiveYears >= 60 ? 6.0 : 4.5;
  const annualEvidence = m.annualReturns.map(a => `${a.year}: ${a.returnPct.toFixed(1)}%`).join(' | ') + `. ${positiveYears}/${annualVals.length} positive years.`;
  rows.push({ parameter: 'Annual Return Consistency', weight: 10, score: Math.round(annualConsistScore * 2) / 2, evidence: annualEvidence });

  // 7. Volatility-Adjusted Returns (10%)
  const volAdjScore =
    m.sharpeRatio > 2 ? 9.5 :
    m.sharpeRatio > 1.5 ? 8.5 :
    m.sharpeRatio > 1.0 ? 7.5 :
    m.sharpeRatio > 0.5 ? 6.0 : 4.0;
  rows.push({
    parameter: 'Volatility-Adjusted Returns',
    weight: 10,
    score: Math.round(volAdjScore * 2) / 2,
    evidence: `Sharpe: ${m.sharpeRatio.toFixed(2)} | Sortino: ${m.sortinoRatio.toFixed(2)} | Calmar: ${m.calmarRatio.toFixed(2)} | Ann. Std Dev: ${m.stdDevAnnual.toFixed(1)}%. Computed from ${m.totalRecords} daily NAV records. Risk-free rate: 6.5% p.a.`,
  });

  // 8. Data Completeness (10%)
  const expectedDays = m.ageYears * 252;
  const completeness = expectedDays > 0 ? (m.totalRecords / expectedDays) * 100 : 0;
  const dataScore = completeness >= 98 ? 10 : completeness >= 95 ? 9 : completeness >= 90 ? 7 : 5;
  rows.push({
    parameter: 'Data Completeness',
    weight: 10,
    score: dataScore,
    evidence: `${m.totalRecords} records over ${m.ageYears.toFixed(1)} years. Expected ~${Math.round(expectedDays)} trading days. Completeness: ${completeness.toFixed(1)}%. Source: AMFI via mfapi.in.`,
  });

  const totalScore = rows.reduce((s, r) => s + (r.weight / 100) * r.score, 0);

  // Stage diagnosis
  const currentDD = m.currentDrawdownFromATH;
  const stage =
    currentDD < -15 ? 'DEEP CORRECTION' :
    currentDD < -8  ? 'CORRECTION' :
    currentDD < -3  ? 'RECOVERY' :
    currentDD < 0   ? 'NEAR ATH' : 'AT/ABOVE ATH';

  // Verdict
  const verdict =
    totalScore >= 8.5 ? 'STRONG BUY' :
    totalScore >= 7.5 ? 'BUY' :
    totalScore >= 6.5 ? 'Continue SIP' :
    totalScore >= 5.5 ? 'CAUTION / SIP Only' : 'AVOID';

  const verdictColor: 'green' | 'amber' | 'red' =
    totalScore >= 7.5 ? 'green' :
    totalScore >= 5.5 ? 'amber' : 'red';

  // Lumpsum decision
  const lumpsumDecision =
    currentDD < -15 && m.sharpeRatio > 0.8
      ? 'LUMPSUM OPPORTUNITY — Fund down >15% from ATH with strong long-term Sharpe. Consider deploying in tranches over 2–4 weeks.' :
    currentDD < -8
      ? 'PARTIAL LUMPSUM — Fund in correction. Deploy 50% now, 50% on further dip or confirmed reversal.' :
    currentDD > -3
      ? 'AVOID LUMPSUM — Fund near ATH. Prefer SIP for new money. Wait for a 10–15% correction for lumpsum.' :
      'SIP PREFERRED — Continue existing SIP. No fresh lumpsum until confirmed recovery or deeper correction.';

  return { rows, totalScore, verdict, verdictColor, stage, lumpsumDecision };
}
