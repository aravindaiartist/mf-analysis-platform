/**
 * mfapi.ts — Live data fetcher from mfapi.in
 * All data is fetched directly from AMFI via mfapi.in.
 * No hardcoded NAV values. No mock data.
 *
 * Search strategy:
 *   1. On first search, fetch the full fund list from api.mfapi.in/mf (~2000 funds, ~300KB)
 *   2. Cache it in sessionStorage so subsequent searches are instant
 *   3. Run local fuzzy matching: normalise query (strip apostrophes, lowercase),
 *      score each fund name, return top 30 sorted by relevance
 *   4. Fall back to mfapi search?q= if the full list fetch fails
 *
 * Scheme code lookup: use api.mfapi.in/mf/search?q=FUNDNAME to find numeric scheme codes.
 * ISIN lookup has been removed — it depended on unreliable CORS proxies.
 */

import type { NavRecord } from './metrics';

const BASE = 'https://api.mfapi.in/mf';
const ALL_FUNDS_CACHE_KEY = 'mf_all_funds_v1';

export interface MFSearchResult {
  schemeCode: number;
  schemeName: string;
}

// ─── AMC Extraction ───────────────────────────────────────────────────────────

// Known AMC prefixes mapped to clean display names
const AMC_MAP: [RegExp, string][] = [
  [/^aditya\s*birla\s*sun\s*life/i, 'Aditya Birla Sun Life'],
  [/^axis/i, 'Axis'],
  [/^bandhan/i, 'Bandhan'],
  [/^baroda\s*bnp\s*paribas/i, 'Baroda BNP Paribas'],
  [/^bnp\s*paribas/i, 'BNP Paribas'],
  [/^canara\s*robeco/i, 'Canara Robeco'],
  [/^dsp/i, 'DSP'],
  [/^edelweiss/i, 'Edelweiss'],
  [/^franklin\s*india/i, 'Franklin India'],
  [/^hdfc/i, 'HDFC'],
  [/^hsbc/i, 'HSBC'],
  [/^icici\s*pru(dential)?/i, 'ICICI Prudential'],
  [/^idfc/i, 'IDFC'],
  [/^invesco/i, 'Invesco'],
  [/^iti/i, 'ITI'],
  [/^jm\s*financial/i, 'JM Financial'],
  [/^kotak/i, 'Kotak'],
  [/^l&t|^l and t/i, 'L&T'],
  [/^lic/i, 'LIC'],
  [/^mahindra\s*manulife/i, 'Mahindra Manulife'],
  [/^mirae\s*asset/i, 'Mirae Asset'],
  [/^motilal\s*oswal/i, 'Motilal Oswal'],
  [/^navi/i, 'Navi'],
  [/^nippon\s*india/i, 'Nippon India'],
  [/^parag\s*parikh/i, 'Parag Parikh'],
  [/^pgim\s*india/i, 'PGIM India'],
  [/^ppfas/i, 'PPFAS'],
  [/^quant/i, 'Quant'],
  [/^quantum/i, 'Quantum'],
  [/^sbi/i, 'SBI'],
  [/^shriram/i, 'Shriram'],
  [/^sundaram/i, 'Sundaram'],
  [/^tata/i, 'Tata'],
  [/^taurus/i, 'Taurus'],
  [/^trust/i, 'Trust'],
  [/^union/i, 'Union'],
  [/^utm/i, 'UTI'],
  [/^uti/i, 'UTI'],
  [/^whiteoak/i, 'WhiteOak'],
  [/^360\s*one/i, '360 ONE'],
  [/^groww/i, 'Groww'],
  [/^samco/i, 'SAMCO'],
  [/^zerodha/i, 'Zerodha'],
];

/**
 * Extract the AMC (fund house) short name from a scheme name.
 * e.g. "SBI Children's Fund - Direct Plan - Growth" → "SBI"
 * Returns empty string if not recognised.
 */
export function extractAMC(schemeName: string): string {
  for (const [pattern, label] of AMC_MAP) {
    if (pattern.test(schemeName.trim())) return label;
  }
  // Fallback: use first word if it looks like an acronym or short name
  const first = schemeName.trim().split(/\s+/)[0];
  if (first && first.length <= 8 && /^[A-Z]/.test(first)) return first;
  return '';
}

export interface MFMeta {
  schemeCode: number;
  schemeName: string;
  fundHouse: string;
  schemeType: string;
  schemeCategory: string;
  schemeNavName: string;
  schemeMinAmount: string;
  launchDate: string;
  closureDate: string;
  isin: string;
}

export interface MFApiResponse {
  meta: MFMeta;
  data: { date: string; nav: string }[];
  status: string;
}

// ─── Local Fund Index ─────────────────────────────────────────────────────────

let fundIndexCache: MFSearchResult[] | null = null;
let fundIndexLoading: Promise<MFSearchResult[]> | null = null;

/**
 * Load the full fund list from mfapi.in/mf, with sessionStorage caching.
 * Returns [] if the fetch fails (search falls back to mfapi search?q=).
 */
export async function loadFundIndex(): Promise<MFSearchResult[]> {
  // Return in-memory cache if available
  if (fundIndexCache) return fundIndexCache;

  // Return existing in-flight promise to avoid duplicate fetches
  if (fundIndexLoading) return fundIndexLoading;

  fundIndexLoading = (async (): Promise<MFSearchResult[]> => {
    // Try sessionStorage first
    try {
      const cached = sessionStorage.getItem(ALL_FUNDS_CACHE_KEY);
      if (cached) {
        const parsed: MFSearchResult[] = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 100) {
          fundIndexCache = parsed;
          return parsed;
        }
      }
    } catch { /* sessionStorage unavailable */ }

    // Fetch from mfapi.in
    try {
      const res = await fetch(`${BASE}`, { signal: AbortSignal.timeout(15000) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: MFSearchResult[] = await res.json();
      if (!Array.isArray(data) || data.length < 100) throw new Error('Invalid fund list');
      fundIndexCache = data;
      // Persist to sessionStorage (best-effort)
      try { sessionStorage.setItem(ALL_FUNDS_CACHE_KEY, JSON.stringify(data)); } catch { /* quota exceeded */ }
      return data;
    } catch {
      // Index load failed — caller will fall back to mfapi search?q=
      return [];
    }
  })();

  return fundIndexLoading;
}

// ─── Local Fuzzy Search ───────────────────────────────────────────────────────

/**
 * Normalise a string for matching:
 * - lowercase
 * - strip apostrophes/special chars (Children's → childrens)
 * - collapse whitespace
 */
function normalise(s: string): string {
  return s
    .toLowerCase()
    .replace(/[''`']/g, '')           // strip apostrophes
    .replace(/[^a-z0-9 ]/g, ' ')     // replace other special chars with space
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Score how well a fund name matches the query.
 * Higher = better match. Returns 0 if no match.
 */
function scoreMatch(normName: string, normQuery: string, queryWords: string[]): number {
  // Exact normalised match
  if (normName === normQuery) return 1000;

  // All query words present in name
  const allWords = queryWords.every(w => normName.includes(w));
  if (!allWords) return 0;

  let score = 100;

  // Bonus: name starts with query
  if (normName.startsWith(normQuery)) score += 200;

  // Bonus: query appears as a contiguous substring
  if (normName.includes(normQuery)) score += 150;

  // Bonus: first word matches first word of name
  const nameWords = normName.split(' ');
  if (nameWords[0] === queryWords[0]) score += 50;

  // Bonus: shorter names rank higher (more specific match)
  score -= normName.length * 0.1;

  return score;
}

/**
 * Search the local fund index. Returns top 30 results sorted by relevance.
 */
function localSearch(funds: MFSearchResult[], query: string): MFSearchResult[] {
  const normQuery = normalise(query);
  if (!normQuery) return [];
  const queryWords = normQuery.split(' ').filter(w => w.length >= 2);
  if (queryWords.length === 0) return [];

  const scored: { fund: MFSearchResult; score: number }[] = [];

  for (const fund of funds) {
    const normName = normalise(fund.schemeName);
    const score = scoreMatch(normName, normQuery, queryWords);
    if (score > 0) scored.push({ fund, score });
  }

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 30).map(s => s.fund);
}

// ─── Remote Search Fallback ───────────────────────────────────────────────────

function normalizeQuery(q: string): string {
  return q
    .replace(/[''`']/g, '')
    .replace(/[^a-zA-Z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function shortenQuery(q: string): string {
  const words = q.trim().split(/\s+/).filter(w => w.length > 1);
  return words.slice(0, 3).join(' ');
}

async function tryRemoteSearch(q: string): Promise<MFSearchResult[]> {
  if (!q.trim()) return [];
  try {
    const url = `${BASE}/search?q=${encodeURIComponent(q)}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return [];
    const data: MFSearchResult[] = await res.json();
    return Array.isArray(data) ? data.slice(0, 30) : [];
  } catch {
    return [];
  }
}

// ─── Public Search API ────────────────────────────────────────────────────────

/**
 * Search funds by name.
 *
 * Primary path: load full fund list locally, run fuzzy match — works for ALL funds
 * including those with apostrophes (SBI Children's Fund, Axis Children's Fund, etc.)
 *
 * Fallback: mfapi search?q= with normalisation strategies (if local index unavailable)
 */
export async function searchFunds(query: string): Promise<MFSearchResult[]> {
  if (!query.trim()) return [];

  // Kick off index load in background (non-blocking on first call)
  const indexPromise = loadFundIndex();

  // Wait for index (it's cached after first load, so instant on subsequent calls)
  const index = await indexPromise;

  if (index.length > 0) {
    // Local search — fast, accurate, handles apostrophes and special chars
    const localResults = localSearch(index, query);
    if (localResults.length > 0) return localResults;
    // If local search returns nothing (very unusual), fall through to remote
  }

  // Remote fallback: try original → normalised → shortened
  const r1 = await tryRemoteSearch(query);
  if (r1.length > 0) return r1;

  const normalized = normalizeQuery(query);
  if (normalized !== query.trim()) {
    const r2 = await tryRemoteSearch(normalized);
    if (r2.length > 0) return r2;
  }

  const shortened = shortenQuery(normalized || query);
  if (shortened !== normalized && shortened !== query.trim()) {
    const r3 = await tryRemoteSearch(shortened);
    if (r3.length > 0) return r3;
  }

  return [];
}

/**
 * Pre-warm the fund index in the background.
 * Call this on app mount so the first search is instant.
 */
export function prewarmFundIndex(): void {
  loadFundIndex().catch(() => { /* silent */ });
}

// ─── NAV Fetch ────────────────────────────────────────────────────────────────

export async function fetchFundData(schemeCode: number): Promise<{ meta: MFMeta; navRecords: NavRecord[] }> {
  const url = `${BASE}/${schemeCode}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Fetch failed for scheme ${schemeCode}: ${res.status}`);
  const json: MFApiResponse = await res.json();

  if (json.status !== 'SUCCESS') throw new Error(`API returned non-success status for scheme ${schemeCode}`);
  if (!json.data || json.data.length === 0) throw new Error(`No NAV data returned for scheme ${schemeCode}`);

  const navRecords: NavRecord[] = json.data
    .map(d => {
      if (!d || typeof d.date !== 'string' || !d.date) return { date: new Date(NaN), nav: NaN };
      const parts = d.date.split('-');
      let date: Date;
      if (parts.length === 3) {
        if (parts[0].length === 4) {
          date = new Date(`${parts[0]}-${parts[1]}-${parts[2]}`);
        } else {
          date = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
        }
      } else {
        date = new Date(d.date);
      }
      const nav = parseFloat(d.nav ?? '0');
      return { date, nav };
    })
    .filter(r => !isNaN(r.nav) && r.nav > 0 && !isNaN(r.date.getTime()))
    .sort((a, b) => a.date.getTime() - b.date.getTime());

  if (navRecords.length === 0) throw new Error('No valid NAV records after parsing');

  // MFAPI returns snake_case keys in the meta object (scheme_code, scheme_name,
  // fund_house, scheme_type, scheme_category, scheme_nav_name, etc.).
  // TypeScript types them as camelCase, so we must remap explicitly.
  const rawMeta = json.meta as unknown as Record<string, unknown>;
  const meta: MFMeta = {
    schemeCode:      (rawMeta.schemeCode      ?? rawMeta.scheme_code      ?? schemeCode) as number,
    schemeName:      (rawMeta.schemeName      ?? rawMeta.scheme_name      ?? '') as string,
    fundHouse:       (rawMeta.fundHouse       ?? rawMeta.fund_house       ?? '') as string,
    schemeType:      (rawMeta.schemeType      ?? rawMeta.scheme_type      ?? '') as string,
    schemeCategory:  (rawMeta.schemeCategory  ?? rawMeta.scheme_category  ?? '') as string,
    schemeNavName:   (rawMeta.schemeNavName   ?? rawMeta.scheme_nav_name  ?? '') as string,
    schemeMinAmount: (rawMeta.schemeMinAmount ?? rawMeta.scheme_min_amount ?? '') as string,
    launchDate:      (rawMeta.launchDate      ?? rawMeta.launch_date      ?? '') as string,
    closureDate:     (rawMeta.closureDate     ?? rawMeta.closure_date     ?? '') as string,
    isin:            (rawMeta.isin            ?? rawMeta.isin             ?? '') as string,
  };

  return { meta, navRecords };
}

// ─── Formatters ───────────────────────────────────────────────────────────────

export function fmtDate(d: Date): string {
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function fmtPct(v: number, decimals = 2): string {
  const sign = v > 0 ? '+' : '';
  return `${sign}${v.toFixed(decimals)}%`;
}

export function fmtNum(v: number, decimals = 2): string {
  return v.toFixed(decimals);
}

// ─── Popular Funds ────────────────────────────────────────────────────────────

export const POPULAR_FUNDS: { name: string; code: number; category: string }[] = [
  { name: 'HDFC Defence Fund — Direct Growth', code: 151750, category: 'Thematic' },
  { name: 'HDFC Flexi Cap Fund — Direct Growth', code: 120503, category: 'Flexi Cap' },
  { name: 'Parag Parikh Flexi Cap — Direct Growth', code: 122639, category: 'Flexi Cap' },
  { name: 'Mirae Asset Large Cap — Direct Growth', code: 118989, category: 'Large Cap' },
  { name: 'SBI Small Cap — Direct Growth', code: 125497, category: 'Small Cap' },
  { name: 'Axis Small Cap — Direct Growth', code: 125354, category: 'Small Cap' },
  { name: 'Nippon India Small Cap — Direct Growth', code: 118778, category: 'Small Cap' },
  { name: 'ICICI Pru Bluechip — Direct Growth', code: 120586, category: 'Large Cap' },
  { name: 'Quant Small Cap — Direct Growth', code: 120828, category: 'Small Cap' },
  { name: 'Motilal Oswal Midcap — Direct Growth', code: 135798, category: 'Mid Cap' },
  { name: 'SBI Contra Fund — Direct Growth', code: 125494, category: 'Contra' },
  { name: 'ICICI Pru Value Discovery — Direct Growth', code: 120505, category: 'Value' },
  { name: 'HDFC Mid-Cap Opportunities — Direct Growth', code: 120465, category: 'Mid Cap' },
  { name: 'Kotak Emerging Equity — Direct Growth', code: 120238, category: 'Mid Cap' },
  { name: 'DSP Small Cap — Direct Growth', code: 120594, category: 'Small Cap' },
];
