/**
 * bundledTRI.ts
 * 
 * Actual NSE TRI data uploaded from official NSE Indices historical data CSVs.
 * Data format: [[epoch_ms, close_value], ...] sorted oldest-first.
 * Source: niftyindices.com — Total Returns Index historical data.
 * 
 * For indices with insufficient uploaded data (< 100 rows), falls back to
 * the mfapi index-fund proxy (see benchmarkProxy.ts).
 */

import { computeBenchmarkMetrics, type BenchmarkMetrics } from './benchmark';
import { type NavRecord } from './metrics';

// ─── CDN URLs for bundled TRI data ────────────────────────────────────────────

export const BUNDLED_TRI_URLS: Record<string, string> = {
  'Nifty 50 TRI':                   'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/nifty50_42341195.json',
  'Nifty 500 TRI':                  'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/nifty500_60d5c174.json',
  'Nifty Next 50 TRI':              'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyNext50_80980dfa.json',
  'Nifty Midcap 150 TRI':           'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyMidcap150_6d81546e.json',
  'Nifty Midcap 100 TRI':           'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyMidcap100_e1b88f55.json',
  'Nifty Healthcare TRI':           'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyHealthcare_41d7f0aa.json',
  'Nifty India Defence TRI':        'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyDefence_4e61b985.json',
  'Nifty India Manufacturing TRI':  'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyManufacturing_dce4befd.json',
  'Nifty Oil & Gas TRI':            'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyOilGas_5d6b57e2.json',
  'Nifty Financial Services Ex-Bank TRI': 'https://d2xsxph8kpxj0f.cloudfront.net/310519663379097771/M4Fgjny59V48WrrJkMn8HD/niftyFinServicesExBank_71568960.json',
};

// ─── In-memory cache ──────────────────────────────────────────────────────────

const _cache: Map<string, Array<[number, number]>> = new Map();

// ─── Fetch bundled TRI data ───────────────────────────────────────────────────

export async function fetchBundledTRI(indexName: string): Promise<Array<{ date: Date; value: number }>> {
  const url = BUNDLED_TRI_URLS[indexName];
  if (!url) throw new Error(`No bundled TRI data for "${indexName}"`);

  if (_cache.has(indexName)) {
    return _cache.get(indexName)!.map(([ms, v]) => ({ date: new Date(ms), value: v }));
  }

  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status} fetching ${indexName} TRI`);
  const data: Array<[number, number]> = await res.json();
  _cache.set(indexName, data);
  return data.map(([ms, v]) => ({ date: new Date(ms), value: v }));
}

// ─── Load bundled TRI as BenchmarkMetrics ─────────────────────────────────────

export async function loadBundledTRIBenchmark(
  indexName: string,
  navRecords: NavRecord[]
): Promise<BenchmarkMetrics> {
  const records = await fetchBundledTRI(indexName);
  return computeBenchmarkMetrics(records, indexName, navRecords);
}

// ─── Check if bundled data is available ──────────────────────────────────────

export function hasBundledTRI(indexName: string): boolean {
  return indexName in BUNDLED_TRI_URLS;
}

// ─── All available bundled index names ───────────────────────────────────────

export const BUNDLED_TRI_NAMES = Object.keys(BUNDLED_TRI_URLS);
