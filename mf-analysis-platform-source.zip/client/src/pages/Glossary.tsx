/**
 * Glossary.tsx — Comprehensive MF Technical Terms Reference
 * Design: Glassmorphic Command Center — deep navy, frosted glass cards
 * Covers: All metrics computed by the platform + chart reading guides
 * Zero speculation. All formulas are mathematically exact.
 */

import { useState } from 'react';
import { Search, BookOpen, TrendingUp, Shield, BarChart2, Activity, Calculator, Info } from 'lucide-react';

function cn(...classes: (string | undefined | false | null)[]) {
  return classes.filter(Boolean).join(' ');
}

// ─── Data ─────────────────────────────────────────────────────────────────────

interface GlossaryTerm {
  id: string;
  term: string;
  category: string;
  shortDef: string;
  fullDef: string;
  formula?: string;
  formulaExplained?: string;
  example?: string;
  goodRange?: string;
  redFlag?: string;
  chartGuide?: string;
}

const TERMS: GlossaryTerm[] = [
  // ── Returns ──
  {
    id: 'nav',
    term: 'NAV (Net Asset Value)',
    category: 'Returns',
    shortDef: 'Price of one unit of a mutual fund on a given day.',
    fullDef: 'NAV is the per-unit market value of a mutual fund scheme. It is calculated by dividing the total net assets of the fund (market value of all securities minus liabilities) by the total number of units outstanding. SEBI mandates that all equity and hybrid funds declare NAV every business day by 11 PM.',
    formula: 'NAV = (Total Assets − Liabilities) ÷ Total Units Outstanding',
    formulaExplained: 'Total Assets = market value of all stocks/bonds held. Liabilities = accrued expenses, management fees payable. Units Outstanding = total units held by all investors.',
    example: 'If a fund holds ₹100 crore in stocks, owes ₹1 crore in fees, and has 10 crore units outstanding: NAV = (100 − 1) ÷ 10 = ₹9.90 per unit.',
    goodRange: 'NAV itself has no "good" range — a higher NAV just means the fund has been running longer or has performed better. It does NOT mean the fund is expensive.',
    redFlag: 'A fund with NAV of ₹10 is not "cheaper" than one with NAV of ₹500. This is a common misconception. Always compare returns, not absolute NAV.',
  },
  {
    id: 'cagr',
    term: 'CAGR (Compound Annual Growth Rate)',
    category: 'Returns',
    shortDef: 'The annualised rate at which an investment grew from start to end, assuming compounding.',
    fullDef: 'CAGR smooths out year-to-year volatility and expresses the steady rate at which an investment would have grown if it grew at the same rate every year. It is the most widely used metric for comparing mutual fund performance across different time periods.',
    formula: 'CAGR = (End NAV ÷ Start NAV)^(1 ÷ Years) − 1',
    formulaExplained: 'End NAV = NAV on the last day of the period. Start NAV = NAV on the first day. Years = exact number of years (e.g., 2.75 years). The exponent 1/Years is the annualisation factor.',
    example: 'NAV grew from ₹10 to ₹18.5 in 2.78 years: CAGR = (18.5/10)^(1/2.78) − 1 = 1.244 − 1 = 24.4% per year.',
    goodRange: 'Equity funds: >12% over 5Y is good. >18% is excellent. Debt funds: >7% is good.',
    redFlag: 'CAGR for periods < 1 year is misleading. Always check the time period alongside the CAGR number.',
    chartGuide: 'In the Growth of ₹100 chart: a steeper upward slope = higher CAGR. The final value minus 100 gives you the total return; CAGR is the annualised version of that.',
  },
  {
    id: 'absolute-return',
    term: 'Absolute Return',
    category: 'Returns',
    shortDef: 'Total percentage gain or loss over a period, without annualising.',
    fullDef: 'Absolute return is simply (End NAV − Start NAV) ÷ Start NAV × 100. Unlike CAGR, it does not account for the time taken. A 50% absolute return over 1 year is very different from 50% over 10 years. Always check the time period when comparing absolute returns.',
    formula: 'Absolute Return = (End NAV − Start NAV) ÷ Start NAV × 100',
    example: 'NAV went from ₹10 to ₹15: Absolute Return = (15−10)/10 × 100 = 50%.',
    goodRange: 'Context-dependent. Compare against the same period for the benchmark.',
    redFlag: 'Funds often advertise absolute returns for short periods to make numbers look large. Always ask: "Over how many years?"',
  },
  {
    id: 'rolling-returns',
    term: 'Rolling Returns',
    category: 'Returns',
    shortDef: 'Returns computed for every possible start date over a fixed window (e.g., all 1-year periods).',
    fullDef: 'Rolling returns eliminate the start-date bias of point-to-point returns. Instead of asking "what was the 1Y return as of today?", rolling returns ask "what was the 1Y return for every possible start date in the fund\'s history?" This gives a distribution of outcomes, showing how consistent the fund has been across different market cycles.',
    formula: 'For each date t: Rolling 1Y Return = CAGR(NAV[t−252], NAV[t])',
    formulaExplained: 'Computed every 5 trading days across the full history. 252 = approximate trading days in a year.',
    example: 'If 1Y rolling returns range from -4% to +151% with 78% of windows positive, it means: in 78% of all 1-year holding periods since inception, the fund gave a positive return.',
    goodRange: '1Y rolling: >80% positive windows is good. >90% is excellent. Median >12% is good.',
    redFlag: 'A fund with high CAGR but low % positive rolling windows is volatile and timing-dependent — bad for SIP investors.',
    chartGuide: 'In the Rolling Returns chart: the x-axis is the end date of each window. The y-axis is the annualised return for that window. A tight band = consistent fund. A wide band = volatile fund.',
  },
  {
    id: 'xirr',
    term: 'XIRR (Extended Internal Rate of Return)',
    category: 'Returns',
    shortDef: 'The annualised return for irregular cashflows like monthly SIPs.',
    fullDef: 'XIRR is the discount rate that makes the Net Present Value (NPV) of all cashflows equal to zero. It is the correct metric for SIP performance because SIPs involve multiple investments at different dates. Unlike CAGR (which works for a single lumpsum), XIRR accounts for the timing and amount of each installment.',
    formula: 'Solve for r: Σ [Cᵢ ÷ (1+r)^tᵢ] = 0, where Cᵢ = cashflow at time tᵢ',
    formulaExplained: 'Cashflows: each SIP installment is negative (money going out), final redemption is positive (money coming in). tᵢ = years from first investment to cashflow date. Solved using Newton-Raphson iteration.',
    example: '12 monthly SIPs of ₹10,000 (total ₹1.2L invested), final value ₹1.65L after 1 year: XIRR ≈ 42% (because early installments had more time to compound).',
    goodRange: 'Equity SIP: >15% XIRR over 3–5 years is excellent. >12% is good. >8% is acceptable.',
    redFlag: 'XIRR can be misleadingly high for very short SIP periods. Always check the number of months in the SIP cohort.',
  },
  // ── Risk ──
  {
    id: 'max-drawdown',
    term: 'Maximum Drawdown (Max DD)',
    category: 'Risk',
    shortDef: 'The largest peak-to-trough decline in NAV during the fund\'s history.',
    fullDef: 'Maximum drawdown measures the worst-case loss an investor would have experienced if they bought at the peak and sold at the trough. It is the most intuitive risk metric for equity investors because it directly answers: "How much could I have lost at the worst possible time?"',
    formula: 'Max DD = (Trough NAV − Peak NAV) ÷ Peak NAV × 100',
    formulaExplained: 'Peak NAV = highest NAV before the trough. Trough NAV = lowest NAV after the peak. The result is always negative (a loss).',
    example: 'Fund peaked at ₹26.56 in Jun 2024, fell to ₹17.38 by Feb 2025: Max DD = (17.38−26.56)/26.56 × 100 = −34.5%.',
    goodRange: 'Large cap funds: -20% to -35% is normal. Small/mid cap: -35% to -55% is normal. Thematic: can exceed -50%.',
    redFlag: 'Max DD > -50% means the fund lost half its value at some point. Requires very high conviction and long holding period to recover.',
    chartGuide: 'In the Drawdown chart: the y-axis shows how far below the all-time high the NAV is at each point. The deepest trough = Max DD. Flat sections near 0% = fund is at or near its ATH.',
  },
  {
    id: 'current-dd',
    term: 'Current Drawdown from ATH',
    category: 'Risk',
    shortDef: 'How far the current NAV is below the all-time high.',
    fullDef: 'Current drawdown from ATH (All-Time High) tells you the present opportunity cost of buying at the peak vs today. It is a real-time signal used to assess entry timing. A fund at -20% from ATH is in "correction" territory; at -30%+ it is in "deep correction" territory where lumpsum investments historically offer better risk-reward.',
    formula: 'Current DD = (Latest NAV − ATH NAV) ÷ ATH NAV × 100',
    example: 'ATH = ₹26.56, Latest NAV = ₹25.33: Current DD = (25.33−26.56)/26.56 × 100 = −4.6%.',
    goodRange: 'For entry timing: -15% to -25% is a reasonable buy zone for quality funds. Below -30% is a strong buy zone if fundamentals are intact.',
    redFlag: 'A fund at 0% drawdown (at ATH) is not a good time for fresh lumpsum. Prefer SIP.',
  },
  {
    id: 'sharpe',
    term: 'Sharpe Ratio',
    category: 'Risk',
    shortDef: 'Return earned per unit of total risk (volatility), above the risk-free rate.',
    fullDef: 'Developed by Nobel laureate William Sharpe, this ratio measures how much excess return (above the risk-free rate) the fund generates for each unit of volatility it takes. A higher Sharpe ratio means the fund is generating more return per unit of risk. It is the most widely used risk-adjusted return metric.',
    formula: 'Sharpe = (Mean Daily Excess Return ÷ Std Dev of Daily Returns) × √252',
    formulaExplained: 'Mean Daily Excess Return = average daily return minus daily risk-free rate (6.5%/252). Std Dev = standard deviation of daily returns. √252 = annualisation factor (252 trading days/year).',
    example: 'If a fund earns 0.08% per day on average, risk-free is 0.026%/day, and daily std dev is 0.9%: Sharpe = (0.08−0.026)/0.9 × √252 = 0.95.',
    goodRange: '>1.5 is excellent. 1.0–1.5 is good. 0.5–1.0 is acceptable. <0.5 is poor.',
    redFlag: 'Sharpe < 0 means the fund is not even beating the risk-free rate after adjusting for risk. Avoid.',
  },
  {
    id: 'sortino',
    term: 'Sortino Ratio',
    category: 'Risk',
    shortDef: 'Like Sharpe, but only penalises downside volatility (bad days), not upside volatility (good days).',
    fullDef: 'The Sortino ratio improves on Sharpe by recognising that investors only care about downside risk — they don\'t mind volatility when the fund is going up. It uses "downside deviation" (standard deviation of returns below the risk-free rate) instead of total standard deviation. A higher Sortino means the fund has better downside protection relative to its returns.',
    formula: 'Sortino = (Annual Return − Risk-Free Rate) ÷ Downside Deviation',
    formulaExplained: 'Downside Deviation = annualised std dev of daily returns that fall below the risk-free daily rate. Annual Return = CAGR since inception. Risk-Free Rate = 6.5% p.a.',
    goodRange: '>2.0 is excellent. 1.0–2.0 is good. <1.0 is acceptable for equity.',
    redFlag: 'A fund with high Sharpe but low Sortino has asymmetric volatility — it crashes hard but recovers slowly.',
  },
  {
    id: 'calmar',
    term: 'Calmar Ratio',
    category: 'Risk',
    shortDef: 'CAGR divided by maximum drawdown. Measures return per unit of worst-case loss.',
    fullDef: 'The Calmar ratio answers: "For every 1% of maximum drawdown risk I took, how much annual return did I get?" It is particularly useful for comparing funds that have experienced significant drawdowns. A fund with 25% CAGR and -50% max DD has a Calmar of 0.5 — the same as a fund with 15% CAGR and -30% max DD.',
    formula: 'Calmar = CAGR (as decimal) ÷ |Max Drawdown (as decimal)|',
    example: 'CAGR = 39.7%, Max DD = -34.5%: Calmar = 0.397 ÷ 0.345 = 1.15.',
    goodRange: '>1.0 is good. >2.0 is excellent. <0.5 is poor.',
    redFlag: 'A low Calmar with high CAGR means the fund is taking excessive drawdown risk to generate returns.',
  },
  {
    id: 'std-dev',
    term: 'Annualised Standard Deviation',
    category: 'Risk',
    shortDef: 'How much the fund\'s daily returns vary from the average, expressed as an annual percentage.',
    fullDef: 'Standard deviation measures the dispersion of daily returns around the mean. A higher std dev means the fund\'s NAV moves more erratically day-to-day. Annualised by multiplying daily std dev by √252. This is the "total risk" used in the Sharpe ratio denominator.',
    formula: 'Ann. Std Dev = Daily Std Dev × √252 × 100',
    formulaExplained: 'Daily Std Dev = √(Σ(rᵢ − r̄)² / n). rᵢ = daily return. r̄ = mean daily return. n = number of trading days. √252 converts daily to annual.',
    goodRange: 'Large cap: 12–18%. Mid/small cap: 18–28%. Thematic/sectoral: can exceed 30%.',
    redFlag: 'Std Dev > 35% means the fund can lose or gain 35% in a year just from normal volatility. Only suitable for investors with very high risk tolerance.',
  },
  // ── Drawdown ──
  {
    id: 'drawdown-episode',
    term: 'Drawdown Episode',
    category: 'Drawdown',
    shortDef: 'A continuous period where the fund falls more than 5% from a peak and eventually recovers (or is still recovering).',
    fullDef: 'A drawdown episode is identified when the NAV falls more than 5% from a local peak. The episode starts at the peak, reaches a trough (lowest point), and ends when the NAV recovers back to the original peak. Episodes still below the peak at the analysis date are marked "Ongoing". Recovery days = calendar days from peak to recovery.',
    example: 'Episode: Peak ₹26.56 (Jun 2024) → Trough ₹17.38 (Feb 2025) → Recovery ₹26.56 (Apr 2025). Fall: -34.5%. Recovery: ~60 days.',
    goodRange: 'Fewer episodes and faster recovery (< 180 days) indicates a resilient fund.',
    redFlag: 'An ongoing episode with >-25% fall and no recovery in sight is a red flag, especially if the broader market has recovered.',
    chartGuide: 'In the Drawdown Episodes table: Fall % = severity. Recovery Days = speed of bounce-back. Status = Recovered or Ongoing. The episode with the largest Fall % is the Max Drawdown.',
  },
  {
    id: 'ath',
    term: 'ATH (All-Time High)',
    category: 'Drawdown',
    shortDef: 'The highest NAV the fund has ever reached.',
    fullDef: 'The All-Time High is the peak NAV in the fund\'s entire history. It is used as the reference point for calculating current drawdown. When the fund is at ATH, current drawdown = 0%. The ATH date tells you when the fund last peaked.',
    example: 'ATH = ₹26.556 on 23-Jun-2024. Current NAV = ₹25.33. Current DD = -4.6%.',
    goodRange: 'A fund consistently making new ATHs is in a strong uptrend.',
    redFlag: 'A fund that set its ATH years ago and has not recovered is a serious concern.',
  },
  // ── Benchmark ──
  {
    id: 'alpha',
    term: 'Alpha',
    category: 'Benchmark',
    shortDef: 'Excess return of the fund over its benchmark index, after adjusting for risk.',
    fullDef: 'In this platform, alpha is computed as the simple difference between the fund\'s CAGR and the benchmark\'s CAGR over the same period (inception alpha). A positive alpha means the fund manager has added value over passive index investing. Alpha is the primary measure of active fund manager skill.',
    formula: 'Alpha = Fund CAGR − Benchmark CAGR (both over same period)',
    example: 'Fund CAGR = 39.7%, Nifty India Defence TRI CAGR = 32.1%: Alpha = +7.6% per year.',
    goodRange: 'Consistent alpha > 3% over 5+ years is excellent. > 1% is good. Negative alpha means the fund underperforms its index.',
    redFlag: 'A fund with negative alpha over 5+ years should be replaced with a direct index fund/ETF of the same category.',
  },
  {
    id: 'tracking-error',
    term: 'Tracking Error',
    category: 'Benchmark',
    shortDef: 'Annualised standard deviation of the daily return difference between fund and benchmark.',
    fullDef: 'Tracking error measures how closely the fund follows its benchmark. A low tracking error means the fund moves very similarly to the index (like an index fund). A high tracking error means the fund takes active bets that deviate significantly from the benchmark — which can be good (if alpha is positive) or bad (if alpha is negative).',
    formula: 'TE = Std Dev(Fund Daily Return − BM Daily Return) × √252 × 100',
    goodRange: 'Index funds: < 1%. Active funds: 4–10% is normal. > 15% means very high active risk.',
    redFlag: 'High tracking error with negative alpha = the fund manager is taking big bets but losing. Worst combination.',
  },
  {
    id: 'information-ratio',
    term: 'Information Ratio (IR)',
    category: 'Benchmark',
    shortDef: 'Alpha divided by tracking error. Measures consistency of outperformance.',
    fullDef: 'The information ratio is the "Sharpe ratio of active management." It measures how much alpha the fund generates per unit of active risk (tracking error). A high IR means the fund consistently beats the benchmark without taking excessive active bets. It is a better measure of fund manager skill than alpha alone.',
    formula: 'IR = Alpha ÷ Tracking Error',
    goodRange: '> 0.5 is good. > 1.0 is excellent. < 0 means the fund is underperforming on a risk-adjusted basis.',
    redFlag: 'IR < 0 with high tracking error = fund manager is consistently wrong in their active bets.',
  },
  {
    id: 'rolling-beat',
    term: 'Rolling Beat %',
    category: 'Benchmark',
    shortDef: 'Percentage of rolling 1Y/3Y/5Y windows where the fund outperformed the benchmark.',
    fullDef: 'Rolling beat % answers: "In what fraction of all 1-year (or 3-year, 5-year) holding periods did this fund beat its benchmark?" It is more meaningful than a single-period alpha because it shows consistency across different market cycles.',
    example: '1Y Rolling Beat = 68% means: in 68% of all 1-year periods since inception, the fund beat the benchmark.',
    goodRange: '> 70% for 1Y, > 80% for 3Y, > 85% for 5Y is considered excellent active management.',
    redFlag: '< 50% rolling beat means you would have been better off in an index fund more than half the time.',
  },
  {
    id: 'correlation',
    term: 'Correlation (Fund vs Benchmark)',
    category: 'Benchmark',
    shortDef: 'How closely the fund\'s daily returns move with the benchmark (0 = no relation, 1 = identical).',
    fullDef: 'Correlation ranges from -1 to +1. A correlation of 1.0 means the fund moves exactly with the benchmark (like an index fund). A correlation of 0.7 means the fund broadly follows the benchmark but with significant independent movement. A low correlation with positive alpha means the fund manager is genuinely adding value through stock selection.',
    formula: 'ρ = Cov(Fund Returns, BM Returns) ÷ (Std Dev Fund × Std Dev BM)',
    goodRange: 'Active funds: 0.7–0.9 is typical. < 0.7 means high active risk. > 0.95 means the fund is essentially an expensive index fund.',
    redFlag: 'Correlation > 0.95 with negative alpha = paying active management fees for index-like performance. Switch to ETF.',
  },
  // ── SIP ──
  {
    id: 'sip',
    term: 'SIP (Systematic Investment Plan)',
    category: 'SIP',
    shortDef: 'A method of investing a fixed amount at regular intervals (usually monthly) in a mutual fund.',
    fullDef: 'SIP allows investors to invest a fixed amount (e.g., ₹10,000/month) on a fixed date every month. Units are allotted at the prevailing NAV. SIP averages out the purchase cost over time (rupee cost averaging), reducing the impact of market timing. It is the recommended mode for most retail investors in equity funds.',
    example: '₹10,000/month SIP for 3 years = ₹3.6L invested. If final value = ₹5.2L, XIRR ≈ 28%.',
    goodRange: 'Any fund where median 3Y SIP XIRR > 12% and % positive cohorts > 85% is suitable for SIP.',
    redFlag: 'If even the best 3Y SIP cohort shows negative XIRR, the fund has serious structural problems.',
    chartGuide: 'In the SIP Study section: each cohort = one possible start date for a 3Y or 5Y SIP. The distribution of XIRR values shows the range of outcomes for different entry points.',
  },
  {
    id: 'sip-cohort',
    term: 'SIP Cohort',
    category: 'SIP',
    shortDef: 'A simulated SIP starting on a specific date, used to measure the range of possible SIP outcomes.',
    fullDef: 'The platform simulates thousands of SIP cohorts — each starting on a different date in the fund\'s history. For each cohort, it invests ₹10,000/month for 36 months (3Y) or 60 months (5Y), then calculates the XIRR. The distribution of these XIRRs shows the best-case, worst-case, and median SIP experience for an investor in this fund.',
    example: 'A 3Y SIP starting Jun 2021 might give 18% XIRR. The same SIP starting Jan 2022 might give 8% XIRR. The cohort analysis shows both outcomes.',
    goodRange: '% cohorts with XIRR > 15% should be > 50% for a good equity fund.',
    redFlag: 'If worst-case SIP XIRR is deeply negative (< -10%), the fund has had periods where even disciplined SIP investors lost money.',
  },
  // ── Fund Structure ──
  {
    id: 'direct-plan',
    term: 'Direct Plan',
    category: 'Fund Structure',
    shortDef: 'A fund variant where you invest directly with the AMC, with no distributor commission — lower expense ratio.',
    fullDef: 'SEBI mandated in 2013 that all mutual funds offer a "Direct" plan alongside the "Regular" plan. In the Direct plan, no commission is paid to distributors, so the expense ratio is lower (typically 0.5–1.5% lower). Over long periods, this difference compounds significantly. All analysis on this platform uses Direct Growth plans.',
    example: 'Regular plan expense ratio: 1.8%. Direct plan: 0.7%. Difference: 1.1%/year. Over 20 years on ₹10L, this difference = ~₹15L in extra corpus.',
    goodRange: 'Always prefer Direct plans for long-term investing. Use Regular only if you need ongoing advisory services.',
    redFlag: 'Investing in Regular plans without receiving any advisory service is a guaranteed loss of 0.5–1.5% per year.',
  },
  {
    id: 'growth-plan',
    term: 'Growth Plan',
    category: 'Fund Structure',
    shortDef: 'A fund variant where profits are reinvested and reflected in NAV growth (no dividends paid out).',
    fullDef: 'In the Growth plan, all profits (dividends, interest, capital gains) are reinvested into the fund. The NAV grows to reflect these reinvested profits. This is the most tax-efficient option for long-term investors because no tax is triggered until you redeem. The alternative is the IDCW (Income Distribution cum Capital Withdrawal) plan, which pays out dividends.',
    goodRange: 'Growth plan is almost always preferable for long-term wealth creation due to compounding and tax efficiency.',
    redFlag: 'IDCW plans are often marketed as "regular income" but dividends are paid from your own NAV — it is not free money.',
  },
  {
    id: 'expense-ratio',
    term: 'Expense Ratio (TER)',
    category: 'Fund Structure',
    shortDef: 'Annual cost of running the fund, charged as a % of AUM. Deducted daily from NAV.',
    fullDef: 'The Total Expense Ratio (TER) covers fund management fees, administrative costs, custodian fees, and other operational expenses. It is deducted daily from the fund\'s NAV (not charged separately). SEBI caps TER for equity funds at 2.25% for regular plans. Direct plans are 0.5–1.5% lower.',
    formula: 'Daily NAV deduction = TER ÷ 365',
    goodRange: 'Direct equity funds: < 1% is good. < 0.5% is excellent. Index funds: < 0.2%.',
    redFlag: 'TER > 2% for a direct plan is very high. Check if the fund\'s alpha justifies the cost.',
  },
  {
    id: 'aum',
    term: 'AUM (Assets Under Management)',
    category: 'Fund Structure',
    shortDef: 'Total market value of all assets managed by the fund.',
    fullDef: 'AUM is the total value of all investments held by the fund across all investors. A larger AUM means more money to deploy, which can be a disadvantage for small/mid cap funds (harder to take large positions without moving the market). For large cap and index funds, larger AUM is generally fine.',
    goodRange: 'Small cap funds: AUM > ₹20,000 crore can face liquidity constraints. Large cap: no upper limit concern.',
    redFlag: 'A small cap fund with AUM > ₹25,000 crore may be forced to invest in mid/large caps, diluting the strategy.',
  },
  {
    id: 'exit-load',
    term: 'Exit Load',
    category: 'Fund Structure',
    shortDef: 'A fee charged when you redeem units before a specified holding period.',
    fullDef: 'Exit load is charged to discourage short-term trading. Most equity funds charge 1% if redeemed within 1 year. After 1 year, exit load is typically nil. The exit load is deducted from the redemption amount before crediting to your account.',
    example: 'Invest ₹1,00,000. Redeem after 6 months at NAV giving ₹1,10,000. Exit load = 1% of ₹1,10,000 = ₹1,100. Net proceeds = ₹1,08,900.',
    goodRange: 'Standard: 1% within 1 year, nil after. Some funds have no exit load.',
    redFlag: 'Exit load > 2% or lock-in periods > 3 years (except ELSS) are unusual and should be checked carefully.',
  },
  // ── Scoring ──
  {
    id: 'scoring-grid',
    term: '8-Parameter Scoring Grid',
    category: 'Scoring',
    shortDef: 'A weighted composite score (out of 10) computed from 8 objective metrics derived from NAV data.',
    fullDef: 'The platform computes a weighted score using 8 parameters, each scored 0–10 and weighted by importance. All scores are derived from actual NAV data — no subjective inputs. The total score determines the verdict (STRONG BUY / BUY / Continue SIP / CAUTION / AVOID) and lumpsum decision.',
    formula: 'Total Score = Σ (Parameter Score × Weight%)',
    formulaExplained: 'Weights: Rolling Consistency 15%, Risk Management 15%, Return Quality 15%, SIP Experience 15%, Drawdown Recovery 10%, Annual Consistency 10%, Volatility-Adjusted Returns 10%, Data Completeness 10%.',
    goodRange: '> 8.5: STRONG BUY. 7.5–8.5: BUY. 6.5–7.5: Continue SIP. 5.5–6.5: CAUTION. < 5.5: AVOID.',
    redFlag: 'A high score on a fund with < 3 years of history should be treated with caution — insufficient data for 3Y/5Y metrics.',
    chartGuide: 'Each row in the scoring grid shows the parameter, weight, score, and the exact evidence from NAV data. The evidence column is the key — it shows the actual numbers behind each score.',
  },
  {
    id: 'verdict',
    term: 'Investment Verdict',
    category: 'Scoring',
    shortDef: 'Rule-based buy/hold/avoid recommendation derived from the scoring grid and current drawdown.',
    fullDef: 'The verdict is computed purely from the scoring grid total and current drawdown from ATH. It is not a financial advisory opinion — it is a systematic signal based on historical NAV data. The lumpsum decision adds the current drawdown context: a fund with a good score but at ATH gets "AVOID LUMPSUM / SIP PREFERRED".',
    redFlag: 'This platform does not have access to portfolio holdings, fund manager quality, sector outlook, or macro factors. The verdict is a quantitative signal, not a complete investment recommendation. Always combine with qualitative research.',
  },
  // ── Chart Reading ──
  {
    id: 'growth-chart',
    term: 'Growth of ₹100 Chart',
    category: 'Chart Reading',
    shortDef: 'Shows how ₹100 invested at inception would have grown over time.',
    fullDef: 'The growth chart rebases the fund\'s NAV to 100 at inception, so the y-axis directly shows the multiple of your initial investment. A value of 250 means ₹100 became ₹250 (2.5x return). This makes it easy to compare funds with different inception NAVs or different inception dates (when overlaid in the comparison view).',
    chartGuide: 'Reading the chart: (1) The slope of the line = rate of growth (steeper = higher CAGR). (2) Flat sections = periods of no growth or sideways movement. (3) Dips = drawdown episodes. (4) The final value minus 100 = total absolute return. (5) In comparison mode, the fund whose line is higher at any point is outperforming at that moment.',
  },
  {
    id: 'drawdown-chart',
    term: 'Drawdown Chart',
    category: 'Chart Reading',
    shortDef: 'Shows how far below the all-time high the NAV is at each point in time.',
    fullDef: 'The drawdown chart always starts at 0% (fund is at ATH) and dips below 0% when the NAV falls. The deepest point = maximum drawdown. Sections at 0% = fund is at or making new ATHs. The chart shows the full history of corrections and recoveries.',
    chartGuide: 'Reading the chart: (1) Depth of dip = severity of correction. (2) Width of dip = duration of correction. (3) Speed of return to 0% = recovery speed. (4) A dip that stays deep for a long time = slow recovery, concerning for lumpsum investors. (5) Multiple shallow dips that recover quickly = resilient fund.',
  },
  {
    id: 'monthly-heatmap',
    term: 'Monthly Returns Heatmap',
    category: 'Chart Reading',
    shortDef: 'A colour-coded grid showing the return for each month of each year.',
    fullDef: 'The heatmap shows each calendar month as a cell, coloured green (positive return) or red (negative return). Darker green = higher positive return. Darker red = larger loss. This allows quick visual identification of seasonal patterns, bad years, and the distribution of positive vs negative months.',
    chartGuide: 'Reading the heatmap: (1) Rows = years. (2) Columns = months (Jan–Dec). (3) Dark green = strong month. (4) Dark red = bad month. (5) A row that is mostly red = a bad year. (6) Look for patterns: some funds are consistently weak in certain months (e.g., election months, budget months).',
  },
  {
    id: 'rolling-chart',
    term: 'Rolling Returns Chart',
    category: 'Chart Reading',
    shortDef: 'Shows the 1Y/3Y/5Y return for every possible start date in the fund\'s history.',
    fullDef: 'Each point on the rolling returns chart represents the annualised return for a window ending on that date. The x-axis is the end date of the window; the y-axis is the CAGR for that window. Points above 0% = positive return for that window. The spread of points shows the range of outcomes.',
    chartGuide: 'Reading the chart: (1) Points above the 0% line = positive rolling return. (2) The % of points above 0% = rolling beat % shown in stats. (3) A tight cluster of points = consistent fund. (4) Wide scatter = volatile/inconsistent fund. (5) Points trending upward recently = improving performance.',
  },
];

const CATEGORIES = ['All', 'Returns', 'Risk', 'Drawdown', 'Benchmark', 'SIP', 'Fund Structure', 'Scoring', 'Chart Reading'];

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  'Returns': <TrendingUp size={14} />,
  'Risk': <Shield size={14} />,
  'Drawdown': <Activity size={14} />,
  'Benchmark': <BarChart2 size={14} />,
  'SIP': <Calculator size={14} />,
  'Fund Structure': <BookOpen size={14} />,
  'Scoring': <Info size={14} />,
  'Chart Reading': <BarChart2 size={14} />,
};

const CATEGORY_COLORS: Record<string, string> = {
  'Returns': 'from-blue-500 to-cyan-500',
  'Risk': 'from-orange-500 to-red-500',
  'Drawdown': 'from-red-500 to-pink-500',
  'Benchmark': 'from-violet-500 to-purple-500',
  'SIP': 'from-emerald-500 to-teal-500',
  'Fund Structure': 'from-amber-500 to-yellow-500',
  'Scoring': 'from-indigo-500 to-blue-500',
  'Chart Reading': 'from-cyan-500 to-blue-500',
};

// ─── SVG Infographics ─────────────────────────────────────────────────────────

function CAGRInfographic() {
  return (
    <svg viewBox="0 0 320 120" className="w-full max-w-xs" aria-label="CAGR growth curve illustration">
      <defs>
        <linearGradient id="cagrGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#8b5cf6" />
        </linearGradient>
        <linearGradient id="cagrFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* Grid lines */}
      {[20, 50, 80].map(y => (
        <line key={y} x1="40" y1={y} x2="300" y2={y} stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
      ))}
      {/* Actual growth curve */}
      <path d="M40,100 C80,95 120,80 160,60 C200,40 240,25 300,15" fill="none" stroke="url(#cagrGrad)" strokeWidth="2.5" />
      <path d="M40,100 C80,95 120,80 160,60 C200,40 240,25 300,15 L300,110 L40,110 Z" fill="url(#cagrFill)" />
      {/* Straight CAGR line */}
      <line x1="40" y1="100" x2="300" y2="15" stroke="rgba(255,255,255,0.25)" strokeWidth="1.5" strokeDasharray="5,4" />
      {/* Labels */}
      <text x="40" y="115" fontSize="9" fill="rgba(255,255,255,0.4)" textAnchor="middle">Start</text>
      <text x="300" y="115" fontSize="9" fill="rgba(255,255,255,0.4)" textAnchor="middle">End</text>
      <text x="170" y="38" fontSize="9" fill="rgba(255,255,255,0.4)">CAGR line</text>
      <text x="240" y="55" fontSize="9" fill="#60a5fa">Actual NAV</text>
      {/* Dots */}
      <circle cx="40" cy="100" r="4" fill="#3b82f6" />
      <circle cx="300" cy="15" r="4" fill="#8b5cf6" />
      {/* NAV labels */}
      <text x="25" y="103" fontSize="9" fill="rgba(255,255,255,0.6)" textAnchor="middle">₹10</text>
      <text x="310" y="18" fontSize="9" fill="rgba(255,255,255,0.6)" textAnchor="start">₹26</text>
    </svg>
  );
}

function DrawdownInfographic() {
  return (
    <svg viewBox="0 0 320 130" className="w-full max-w-xs" aria-label="Drawdown chart illustration">
      <defs>
        <linearGradient id="ddFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ef4444" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* Zero line */}
      <line x1="20" y1="25" x2="300" y2="25" stroke="rgba(255,255,255,0.2)" strokeWidth="1" strokeDasharray="4,3" />
      <text x="305" y="28" fontSize="9" fill="rgba(255,255,255,0.4)">0%</text>
      {/* Drawdown area */}
      <path d="M20,25 L60,25 L80,35 L110,70 L130,90 L150,80 L170,60 L200,30 L220,25 L260,25 L270,30 L280,40 L300,35" fill="none" stroke="#ef4444" strokeWidth="2" />
      <path d="M20,25 L60,25 L80,35 L110,70 L130,90 L150,80 L170,60 L200,30 L220,25 L260,25 L270,30 L280,40 L300,35 L300,25 L20,25 Z" fill="url(#ddFill)" />
      {/* Max DD annotation */}
      <line x1="130" y1="25" x2="130" y2="90" stroke="rgba(255,255,255,0.3)" strokeWidth="1" strokeDasharray="3,3" />
      <text x="135" y="60" fontSize="9" fill="#fbbf24">Max DD</text>
      <text x="135" y="72" fontSize="9" fill="#fbbf24">-34.5%</text>
      {/* ATH labels */}
      <text x="20" y="20" fontSize="9" fill="rgba(255,255,255,0.5)">ATH</text>
      {/* Recovery arrow */}
      <path d="M130,90 Q175,95 220,25" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="1" markerEnd="url(#arrow)" />
      <text x="165" y="110" fontSize="9" fill="rgba(255,255,255,0.4)">Recovery</text>
    </svg>
  );
}

function SharpeInfographic() {
  return (
    <svg viewBox="0 0 320 120" className="w-full max-w-xs" aria-label="Sharpe ratio illustration">
      <defs>
        <linearGradient id="sharpeGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#10b981" />
          <stop offset="100%" stopColor="#3b82f6" />
        </linearGradient>
      </defs>
      {/* Two fund curves */}
      {/* Fund A: high return, high volatility */}
      <path d="M20,90 C50,70 60,40 80,55 C100,70 110,30 130,45 C150,60 160,20 180,35 C200,50 210,15 240,25 C260,32 280,20 300,15"
        fill="none" stroke="#f59e0b" strokeWidth="2" />
      {/* Fund B: moderate return, low volatility */}
      <path d="M20,90 C60,80 100,65 140,55 C180,45 220,38 300,30"
        fill="none" stroke="url(#sharpeGrad)" strokeWidth="2.5" />
      {/* Risk-free line */}
      <line x1="20" y1="95" x2="300" y2="95" stroke="rgba(255,255,255,0.2)" strokeWidth="1" strokeDasharray="4,3" />
      <text x="305" y="98" fontSize="8" fill="rgba(255,255,255,0.35)">rf</text>
      {/* Labels */}
      <text x="245" y="20" fontSize="9" fill="#10b981">Fund B</text>
      <text x="245" y="32" fontSize="8" fill="rgba(255,255,255,0.4)">Sharpe: 1.8</text>
      <text x="245" y="48" fontSize="9" fill="#f59e0b">Fund A</text>
      <text x="245" y="60" fontSize="8" fill="rgba(255,255,255,0.4)">Sharpe: 0.9</text>
      <text x="20" y="112" fontSize="8" fill="rgba(255,255,255,0.35)">Fund B has better risk-adjusted return despite lower absolute return</text>
    </svg>
  );
}

function RollingInfographic() {
  const points = [
    [20, 80], [35, 60], [50, 45], [65, 70], [80, 30], [95, 50],
    [110, 20], [125, 40], [140, 55], [155, 25], [170, 35], [185, 15],
    [200, 45], [215, 30], [230, 50], [245, 20], [260, 35], [275, 25], [290, 15]
  ];
  const zeroY = 75;
  return (
    <svg viewBox="0 0 320 120" className="w-full max-w-xs" aria-label="Rolling returns scatter illustration">
      {/* Zero line */}
      <line x1="15" y1={zeroY} x2="300" y2={zeroY} stroke="rgba(255,255,255,0.2)" strokeWidth="1" strokeDasharray="4,3" />
      <text x="302" y={zeroY + 3} fontSize="8" fill="rgba(255,255,255,0.35)">0%</text>
      {/* Dots */}
      {points.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="3"
          fill={y < zeroY ? '#10b981' : '#ef4444'}
          opacity="0.8" />
      ))}
      {/* Labels */}
      <text x="15" y="115" fontSize="8" fill="rgba(255,255,255,0.35)">Each dot = one rolling 1Y window</text>
      <text x="15" y="12" fontSize="8" fill="#10b981">● Above line = positive return</text>
      <text x="160" y="12" fontSize="8" fill="#ef4444">● Below = negative</text>
    </svg>
  );
}

function HeatmapInfographic() {
  const months = ['J','F','M','A','M','J','J','A','S','O','N','D'];
  const data = [
    [3.2, -1.1, 5.4, 2.1, -3.2, 8.1, 4.3, -2.1, 6.2, 3.1, -1.2, 7.3],
    [-2.1, 4.3, 2.1, -5.2, 3.1, -1.2, 9.3, 2.4, -3.1, 5.2, 4.1, -2.3],
    [5.1, 2.3, -1.2, 4.3, 6.1, 3.2, -2.1, 7.3, 2.1, -1.3, 8.2, 3.1],
  ];
  const years = ['2023', '2024', '2025'];
  const cellW = 22, cellH = 18;
  const startX = 32, startY = 15;

  function getColor(v: number) {
    if (v > 5) return '#065f46';
    if (v > 2) return '#10b981';
    if (v > 0) return '#6ee7b7';
    if (v > -2) return '#fca5a5';
    if (v > -4) return '#ef4444';
    return '#991b1b';
  }

  return (
    <svg viewBox="0 0 310 90" className="w-full max-w-xs" aria-label="Monthly heatmap illustration">
      {/* Month labels */}
      {months.map((m, i) => (
        <text key={`month-${i}`} x={startX + i * cellW + cellW / 2} y={12} fontSize="7.5" fill="rgba(255,255,255,0.4)" textAnchor="middle">{m}</text>
      ))}
      {/* Cells */}
      {data.map((row, ri) => (
        <g key={ri}>
          <text x={startX - 4} y={startY + ri * cellH + cellH / 2 + 3} fontSize="7.5" fill="rgba(255,255,255,0.4)" textAnchor="end">{years[ri]}</text>
          {row.map((v, ci) => (
            <rect key={ci}
              x={startX + ci * cellW + 1}
              y={startY + ri * cellH + 1}
              width={cellW - 2}
              height={cellH - 2}
              rx="2"
              fill={getColor(v)}
              opacity="0.85"
            />
          ))}
        </g>
      ))}
    </svg>
  );
}

const INFOGRAPHICS: Record<string, React.ReactNode> = {
  'cagr': <CAGRInfographic />,
  'max-drawdown': <DrawdownInfographic />,
  'sharpe': <SharpeInfographic />,
  'rolling-returns': <RollingInfographic />,
  'monthly-heatmap': <HeatmapInfographic />,
};

// ─── Term Card ────────────────────────────────────────────────────────────────

function TermCard({ term }: { term: GlossaryTerm }) {
  const [expanded, setExpanded] = useState(false);
  const gradient = CATEGORY_COLORS[term.category] || 'from-blue-500 to-violet-500';
  const infographic = INFOGRAPHICS[term.id];

  return (
    <div className="glass-card overflow-hidden">
      <button
        className="w-full text-left p-4 flex items-start gap-3 hover:bg-white/5 transition-colors"
        onClick={() => setExpanded(e => !e)}
        aria-expanded={expanded}
      >
        <div className={cn('w-8 h-8 rounded-lg bg-gradient-to-br flex items-center justify-center text-white flex-shrink-0 mt-0.5', gradient)}>
          {CATEGORY_ICONS[term.category] || <BookOpen size={14} />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-white text-sm">{term.term}</span>
            <span className={cn('text-xs px-2 py-0.5 rounded-full bg-gradient-to-r text-white font-medium', gradient)}>{term.category}</span>
          </div>
          <p className="text-xs text-white/50 mt-0.5 leading-relaxed">{term.shortDef}</p>
        </div>
        <span className="text-white/30 flex-shrink-0 mt-1">{expanded ? '▲' : '▼'}</span>
      </button>

      {expanded && (
        <div className="px-4 pb-4 border-t border-white/5 pt-4 space-y-4">
          {/* Full definition */}
          <p className="text-sm text-white/70 leading-relaxed">{term.fullDef}</p>

          {/* Infographic */}
          {infographic && (
            <div className="flex justify-center py-2 bg-white/3 rounded-xl border border-white/5">
              {infographic}
            </div>
          )}

          {/* Formula */}
          {term.formula && (
            <div className="bg-[#0d1117] rounded-xl border border-white/10 p-3">
              <div className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-1.5">Formula</div>
              <code className="text-sm font-mono text-blue-300 break-all">{term.formula}</code>
              {term.formulaExplained && (
                <p className="text-xs text-white/40 mt-2 leading-relaxed">{term.formulaExplained}</p>
              )}
            </div>
          )}

          {/* Example */}
          {term.example && (
            <div className="bg-emerald-500/5 border border-emerald-500/15 rounded-xl p-3">
              <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1">Example</div>
              <p className="text-xs text-white/60 leading-relaxed">{term.example}</p>
            </div>
          )}

          {/* Good range + Red flag */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {term.goodRange && (
              <div className="bg-blue-500/5 border border-blue-500/15 rounded-xl p-3">
                <div className="text-xs font-semibold text-blue-400 uppercase tracking-wider mb-1">Good Range</div>
                <p className="text-xs text-white/60 leading-relaxed">{term.goodRange}</p>
              </div>
            )}
            {term.redFlag && (
              <div className="bg-red-500/5 border border-red-500/15 rounded-xl p-3">
                <div className="text-xs font-semibold text-red-400 uppercase tracking-wider mb-1">Red Flag</div>
                <p className="text-xs text-white/60 leading-relaxed">{term.redFlag}</p>
              </div>
            )}
          </div>

          {/* Chart guide */}
          {term.chartGuide && (
            <div className="bg-violet-500/5 border border-violet-500/15 rounded-xl p-3">
              <div className="text-xs font-semibold text-violet-400 uppercase tracking-wider mb-1">How to Read This in the Platform</div>
              <p className="text-xs text-white/60 leading-relaxed">{term.chartGuide}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function Glossary() {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  const filtered = TERMS.filter(t => {
    const matchCat = activeCategory === 'All' || t.category === activeCategory;
    const q = search.toLowerCase();
    const matchSearch = !q ||
      t.term.toLowerCase().includes(q) ||
      t.shortDef.toLowerCase().includes(q) ||
      t.fullDef.toLowerCase().includes(q) ||
      (t.formula || '').toLowerCase().includes(q);
    return matchCat && matchSearch;
  });

  const counts = CATEGORIES.reduce((acc, cat) => {
    acc[cat] = cat === 'All' ? TERMS.length : TERMS.filter(t => t.category === cat).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen bg-[#070b14]">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-[#070b14]/95 backdrop-blur-xl border-b border-white/5 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center">
              <BookOpen size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">MF Glossary & Chart Reading Guide</h1>
              <p className="text-xs text-white/40">{TERMS.length} terms · All formulas verified · Zero speculation</p>
            </div>
          </div>
          {/* Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search terms, formulas, or concepts..."
              className="w-full pl-9 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder-white/25 focus:outline-none focus:border-blue-500/50 focus:bg-white/8 transition-all"
            />
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Category filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={cn(
                'px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border',
                activeCategory === cat
                  ? 'bg-blue-500/20 border-blue-500/40 text-blue-300'
                  : 'bg-white/3 border-white/8 text-white/40 hover:bg-white/8 hover:text-white/60'
              )}
            >
              {cat} <span className="opacity-50">({counts[cat]})</span>
            </button>
          ))}
        </div>

        {/* Results count */}
        <div className="text-xs text-white/30 mb-4">
          {filtered.length} {filtered.length === 1 ? 'term' : 'terms'} found
          {search && ` for "${search}"`}
          {activeCategory !== 'All' && ` in ${activeCategory}`}
        </div>

        {/* Terms */}
        <div className="space-y-3">
          {filtered.length === 0 ? (
            <div className="glass-card p-8 text-center">
              <BookOpen size={32} className="mx-auto text-white/20 mb-3" />
              <p className="text-white/40 text-sm">No terms found. Try a different search.</p>
            </div>
          ) : (
            filtered.map(term => <TermCard key={term.id} term={term} />)
          )}
        </div>

        {/* Footer note */}
        <div className="mt-8 p-4 bg-white/3 border border-white/8 rounded-xl text-xs text-white/30 leading-relaxed">
          <strong className="text-white/50">Data integrity note:</strong> All formulas in this glossary are implemented exactly as described in the metrics computation engine (metrics.ts). Every metric shown in the platform is derived from actual AMFI daily NAV data via mfapi.in. No values are hardcoded, estimated, or sourced from third-party databases. Risk-free rate used: 6.5% p.a. (approximate 10Y G-Sec yield as of Mar 2026). Category averages are approximate benchmarks from AMFI/Morningstar data (Mar 2026) and are clearly labelled as such.
        </div>
      </div>
    </div>
  );
}
