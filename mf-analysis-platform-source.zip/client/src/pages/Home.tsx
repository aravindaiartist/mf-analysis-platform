/**
 * MF Analysis Platform — Home.tsx
 * Design: Glassmorphic Command Center — deep navy, frosted glass cards,
 * blue-to-violet gradient accents, Space Grotesk + JetBrains Mono
 *
 * Features:
 * - Live NAV fetch from AMFI via mfapi.in
 * - Full metrics engine (CAGR, drawdown, rolling, Sharpe, Sortino, Calmar, SIP XIRR)
 * - Benchmark overlay (NSE TRI CSV upload, alpha, rolling beat, TE, IR)
 * - Fund comparison mode (2 funds side-by-side)
 * - Watchlist with buy-zone DD alerts (localStorage)
 * - Category average benchmarking row in scoring grid
 * - SOP guide with config generator
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import { searchFunds, fetchFundData, fmtDate, POPULAR_FUNDS, prewarmFundIndex, extractAMC, type MFMeta, type MFSearchResult } from '@/lib/mfapi';
import { computeMetrics, computeScoring, type FundMetrics, type ScoringResult, type NavRecord } from '@/lib/metrics';
import { parseBenchmarkCSV, computeBenchmarkMetrics, type BenchmarkMetrics } from '@/lib/benchmark';
import { getCategoryAverage, getCategoryTrailingReturns, computePeerRelativeScore, getBenchmarkSuggestion, getCategoryBuyZone } from '@/lib/categoryAverages';
import { BENCHMARK_PROXY_MAP, detectBenchmarkNameFromFilename, fetchBenchmarkProxy } from '@/lib/benchmarkProxy';
import { hasBundledTRI, loadBundledTRIBenchmark } from '@/lib/bundledTRI';
import { useWatchlist, type WatchlistEntry } from '@/hooks/useWatchlist';
import SectionErrorBoundary from '@/components/SectionErrorBoundary';
import GlossaryInline from './Glossary';
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Legend
} from 'recharts';
import {
  Search, TrendingUp, AlertTriangle, CheckCircle, Info,
  ChevronDown, ChevronUp, Copy, Check, Loader2, BookOpen,
  Zap, BarChart2, Shield, RefreshCw, Upload, X,
  Bell, BellOff, GitCompare, Star, StarOff, Trash2, Edit3, Download,
  Hash, AlertCircle, BarChart as BarChartIcon,
} from 'lucide-react';
import { toast } from 'sonner';
import { DecisionFramework } from '@/components/DecisionFramework';
import { MarketContext } from '@/components/MarketContext';

// ─── Types ────────────────────────────────────────────────────────────────────

interface AnalysisState {
  meta: MFMeta;
  navRecords: NavRecord[];
  metrics: FundMetrics;
  scoring: ScoringResult;
  benchmark: BenchmarkMetrics | null;
}

type TabType = 'analyze' | 'compare' | 'watchlist' | 'sop' | 'glossary';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function cn(...classes: (string | undefined | false | null)[]) {
  return classes.filter(Boolean).join(' ');
}

function scoreColor(score: number) {
  if (score >= 8) return 'text-emerald-400';
  if (score >= 6) return 'text-amber-400';
  return 'text-red-400';
}

function scoreBg(score: number) {
  if (score >= 8) return 'bg-emerald-400/10 border-emerald-400/20';
  if (score >= 6) return 'bg-amber-400/10 border-amber-400/20';
  return 'bg-red-400/10 border-red-400/20';
}

function retColor(v: number) {
  if (v > 15) return 'text-emerald-400';
  if (v > 0) return 'text-green-400';
  return 'text-red-400';
}

function ddColor(v: number) {
  if (v > -5) return 'text-emerald-400';
  if (v > -15) return 'text-amber-400';
  if (v > -25) return 'text-orange-400';
  return 'text-red-400';
}

function fmt(v: number | null, dec = 2): string {
  if (v === null || v === undefined) return 'N/A';
  return `${v > 0 ? '+' : ''}${v.toFixed(dec)}%`;
}

// ─── Shared sub-components ────────────────────────────────────────────────────

function KPICard({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <div className="glass-card p-4 flex flex-col gap-1">
      <div className="text-xs font-semibold uppercase tracking-wider text-white/40">{label}</div>
      <div className={cn('text-2xl font-bold font-mono', color || 'text-white')}>{value}</div>
      {sub && <div className="text-xs text-white/40">{sub}</div>}
    </div>
  );
}

function SectionHeader({ icon, title, subtitle }: { icon: React.ReactNode; title: string; subtitle?: string }) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center text-white flex-shrink-0">
        {icon}
      </div>
      <div>
        <h2 className="text-lg font-bold text-white">{title}</h2>
        {subtitle && <p className="text-xs text-white/40">{subtitle}</p>}
      </div>
    </div>
  );
}

function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 transition-colors"
    >
      {copied ? <Check size={12} /> : <Copy size={12} />}
      {copied ? 'Copied!' : label}
    </button>
  );
}

function CollapsibleSection({ title, children, defaultOpen = true, badge }: { title: string; children: React.ReactNode; defaultOpen?: boolean; badge?: React.ReactNode }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="glass-card overflow-hidden mb-5">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-white/5 transition-colors">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-white">{title}</span>
          {badge}
        </div>
        {open ? <ChevronUp size={16} className="text-white/40" /> : <ChevronDown size={16} className="text-white/40" />}
      </button>
      {open && <div className="px-5 pb-5">{children}</div>}
    </div>
  );
}

// ─── Fund Search Box (reusable) ───────────────────────────────────────────────

function FundSearchBox({
  placeholder,
  onSelect,
  disabled = false,
}: {
  placeholder: string;
  onSelect: (code: number, name: string) => void;
  disabled?: boolean;
}) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<MFSearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [open, setOpen] = useState(false);
  const timeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // Pre-warm fund index so first keystroke is instant
  useEffect(() => { prewarmFundIndex(); }, []);

  const handleChange = (q: string) => {
    setQuery(q);
    if (timeout.current) clearTimeout(timeout.current);
    if (!q.trim()) { setResults([]); setOpen(false); return; }
    timeout.current = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await searchFunds(q);
        setResults(r);
        setOpen(r.length > 0);
      } catch { setResults([]); setOpen(false); }
      finally { setSearching(false); }
    }, 400);
  };

  const handleSelect = (code: number, name: string) => {
    onSelect(code, name);
    setQuery(name);
    setResults([]);
    setOpen(false);
  };

  return (
    <div className="relative" ref={containerRef}>
      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
        <input
          type="text"
          value={query}
          onChange={e => handleChange(e.target.value)}
          onFocus={() => results.length > 0 && setOpen(true)}
          placeholder={placeholder}
          disabled={disabled}
          className="w-full bg-[#0f1117] border border-white/20 rounded-lg pl-9 pr-4 py-2.5 text-sm text-white placeholder-white/40 outline-none focus:border-blue-500/60 focus:bg-[#141720] transition-all disabled:opacity-40"
        />
        {searching && <Loader2 size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 animate-spin" />}
      </div>
      {open && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1.5 bg-[#0f1117] border border-white/20 rounded-xl overflow-hidden z-[100] max-h-60 overflow-y-auto shadow-2xl shadow-black/60">
          {results.map(r => (
            <button
              key={r.schemeCode}
              onMouseDown={e => { e.preventDefault(); handleSelect(r.schemeCode, r.schemeName); }}
              className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-colors border-b border-white/8 last:border-0"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="text-sm text-white/80 font-medium leading-tight flex-1 min-w-0">{r.schemeName}</div>
                {extractAMC(r.schemeName) && (
                  <span className="shrink-0 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-300 border border-blue-500/20 uppercase tracking-wide mt-0.5">
                    {extractAMC(r.schemeName)}
                  </span>
                )}
              </div>
              <div className="text-xs text-white/25 mt-0.5 font-mono">Code: {r.schemeCode}</div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Charts ───────────────────────────────────────────────────────────────────

function GrowthChart({ data, bmData }: { data: { date: Date; value: number }[]; bmData?: { date: Date; value: number }[] }) {
  const sampled = data.filter((_, i) => i % 5 === 0);
  const chartData = sampled.map(d => {
    const bm = bmData ? bmData.find(b => Math.abs(b.date.getTime() - d.date.getTime()) < 5 * 86400000) : null;
    return {
      date: d.date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' }),
      fund: parseFloat(d.value.toFixed(2)),
      ...(bm ? { bm: parseFloat(bm.value.toFixed(2)) } : {}),
    };
  });
  return (
    <ResponsiveContainer width="100%" height={240}>
      <AreaChart data={chartData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
        <defs>
          <linearGradient id="growthGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#4f8ef7" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#4f8ef7" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="bmGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.2} />
            <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
        <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => `₹${v}`} />
        <Tooltip contentStyle={{ background: '#1a1d27', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
        {bmData && <Area type="monotone" dataKey="bm" stroke="#f59e0b" strokeWidth={1.5} fill="url(#bmGrad)" dot={false} name="Benchmark" strokeDasharray="4 2" />}
        <Area type="monotone" dataKey="fund" stroke="#4f8ef7" strokeWidth={2} fill="url(#growthGrad)" dot={false} name="Fund" />
        <ReferenceLine y={100} stroke="rgba(255,255,255,0.2)" strokeDasharray="4 4" />
        {bmData && <Legend wrapperStyle={{ fontSize: 11, color: 'rgba(255,255,255,0.5)' }} />}
      </AreaChart>
    </ResponsiveContainer>
  );
}

function DrawdownChart({ data }: { data: { date: Date; drawdownPct: number }[] }) {
  const sampled = data.filter((_, i) => i % 5 === 0);
  const chartData = sampled.map(d => ({ date: d.date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' }), dd: parseFloat(d.drawdownPct.toFixed(2)) }));
  return (
    <ResponsiveContainer width="100%" height={180}>
      <AreaChart data={chartData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
        <defs>
          <linearGradient id="ddGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#e05c5c" stopOpacity={0.4} />
            <stop offset="95%" stopColor="#e05c5c" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
        <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => `${v}%`} />
        <Tooltip contentStyle={{ background: '#1a1d27', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} formatter={(v: number) => [`${v.toFixed(2)}%`, 'Drawdown']} />
        <Area type="monotone" dataKey="dd" stroke="#e05c5c" strokeWidth={1.5} fill="url(#ddGrad)" dot={false} />
        <ReferenceLine y={0} stroke="rgba(255,255,255,0.2)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function RollingChart({
  data, label, bmData, bmName
}: {
  data: { date: Date; returnPct: number }[];
  label: string;
  bmData?: { date: Date; returnPct: number }[];
  bmName?: string;
}) {
  if (!data.length) return <div className="text-white/30 text-sm py-8 text-center">Not enough history for {label} rolling returns</div>;

  // Build a merged date-keyed dataset so both lines share the same x-axis
  const fundMap = new Map(data.map(d => [d.date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' }), parseFloat(d.returnPct.toFixed(2))]));
  const bmMap = bmData ? new Map(bmData.map(d => [d.date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' }), parseFloat(d.returnPct.toFixed(2))])) : null;

  // Use fund dates as primary axis
  const chartData = data.map(d => {
    const key = d.date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
    return {
      date: key,
      ret: fundMap.get(key) ?? null,
      bm: bmMap ? (bmMap.get(key) ?? null) : undefined,
    };
  });

  const hasBm = bmMap && bmMap.size > 0;

  return (
    <div>
      {hasBm && (
        <div className="flex items-center gap-4 mb-2 text-xs">
          <span className="flex items-center gap-1.5"><span className="inline-block w-3 h-0.5 bg-emerald-400" />Fund</span>
          <span className="flex items-center gap-1.5"><span className="inline-block w-3 h-0.5 bg-amber-400 border-dashed" style={{borderTop:'2px dashed #f59e0b',height:0}} />{bmName ?? 'Benchmark'}</span>
        </div>
      )}
      <ResponsiveContainer width="100%" height={180}>
        <LineChart data={chartData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
          <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
          <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => `${v}%`} />
          <Tooltip
            contentStyle={{ background: '#1a1d27', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }}
            formatter={(v: number, name: string) => [
              v !== null ? `${v.toFixed(2)}%` : 'N/A',
              name === 'bm' ? (bmName ?? 'Benchmark') : 'Fund'
            ]}
          />
          <ReferenceLine y={0} stroke="rgba(255,255,255,0.2)" strokeDasharray="4 4" />
          <Line type="monotone" dataKey="ret" stroke="#3ecf8e" strokeWidth={1.5} dot={false} name="fund" connectNulls />
          {hasBm && <Line type="monotone" dataKey="bm" stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="5 3" dot={false} name="bm" connectNulls />}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function MonthlyHeatmap({ data }: { data: { year: number; month: number; returnPct: number }[] }) {
  const years = Array.from(new Set(data.map(d => d.year))).sort((a, b) => a - b);
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const getReturn = (year: number, month: number) => data.find(d => d.year === year && d.month === month);
  const cellColor = (v: number) => {
    if (v > 10) return 'bg-emerald-500/80 text-white';
    if (v > 5) return 'bg-emerald-500/50 text-emerald-100';
    if (v > 0) return 'bg-emerald-500/25 text-emerald-200';
    if (v > -5) return 'bg-red-500/25 text-red-200';
    if (v > -10) return 'bg-red-500/50 text-red-100';
    return 'bg-red-500/80 text-white';
  };
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr>
            <th className="text-left py-1.5 pr-3 text-white/40 font-medium w-12">Year</th>
            {months.map((m, mi) => <th key={`hdr-${mi}`} className="text-center py-1.5 px-1 text-white/40 font-medium w-10">{m}</th>)}
            <th className="text-right py-1.5 pl-3 text-white/40 font-medium">Full Year</th>
          </tr>
        </thead>
        <tbody>
          {years.map(year => {
            const yearData = data.filter(d => d.year === year);
            const yearTotal = yearData.length >= 10 ? yearData.reduce((s, d) => s * (1 + d.returnPct / 100), 1) * 100 - 100 : null;
            return (
              <tr key={year}>
                <td className="py-1 pr-3 text-white/60 font-mono font-medium">{year}</td>
                {months.map((_, mi) => {
                  const rec = getReturn(year, mi + 1);
                  return (
                    <td key={mi} className="py-1 px-0.5">
                      {rec ? (
                        <div className={cn('rounded text-center py-1 px-0.5 font-mono font-medium', cellColor(rec.returnPct))}>
                          {rec.returnPct > 0 ? '+' : ''}{rec.returnPct.toFixed(1)}
                        </div>
                      ) : (
                        <div className="rounded text-center py-1 px-0.5 text-white/15">—</div>
                      )}
                    </td>
                  );
                })}
                <td className="py-1 pl-3 text-right">
                  {yearTotal !== null ? (
                    <span className={cn('font-mono font-bold text-sm', retColor(yearTotal))}>
                      {yearTotal > 0 ? '+' : ''}{yearTotal.toFixed(1)}%
                    </span>
                  ) : <span className="text-white/20">—</span>}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── Quick Benchmark Picker (inside Growth Chart) ──────────────────────────────

const QUICK_BENCHMARKS = [
  // Broad market — bundled NSE TRI data
  'Nifty 50 TRI',
  'Nifty 500 TRI',
  'Nifty Next 50 TRI',
  'Nifty Midcap 150 TRI',
  'Nifty Midcap 100 TRI',
  // Sectoral — bundled NSE TRI data
  'Nifty Healthcare TRI',
  'Nifty India Defence TRI',
  'Nifty India Manufacturing TRI',
  'Nifty Oil & Gas TRI',
  'Nifty Financial Services Ex-Bank TRI',
  // Proxy-based (no uploaded data)
  'Nifty LargeMidcap 250 TRI',
  'Nifty Smallcap 250 TRI',
] as const;

function QuickBenchmarkPicker({
  navRecords, activeBm, suggestedBmName, onBenchmarkLoaded, onBenchmarkCleared
}: {
  navRecords: NavRecord[];
  activeBm: BenchmarkMetrics | null;
  suggestedBmName: string;
  onBenchmarkLoaded: (bm: BenchmarkMetrics) => void;
  onBenchmarkCleared: () => void;
}) {
  const [loading, setLoading] = useState<string | null>(null);

  const handlePick = async (bmName: string) => {
    if (activeBm?.name === bmName) {
      onBenchmarkCleared();
      return;
    }
    setLoading(bmName);
    try {
      let metrics: BenchmarkMetrics;
      if (hasBundledTRI(bmName)) {
        // Use actual NSE TRI data
        metrics = await loadBundledTRIBenchmark(bmName, navRecords);
        toast.success(`${bmName} loaded (NSE actual data). Alpha = ${metrics.alphaInception > 0 ? '+' : ''}${metrics.alphaInception.toFixed(2)}%`);
      } else {
        // Fall back to index fund proxy
        const proxy = BENCHMARK_PROXY_MAP[bmName];
        if (!proxy) { toast.error(`No data available for ${bmName}`); setLoading(null); return; }
        toast.info(`Loading ${bmName} via index fund proxy...`);
        const rawData = await fetchBenchmarkProxy(proxy.schemeCode);
        if (rawData.length === 0) throw new Error('No data returned');
        const records = rawData.map(d => {
          if (!d || typeof d.date !== 'string' || !d.date) return { date: new Date(NaN), value: 0 };
          const parts = d.date.split('-');
          const iso = parts.length === 3 ? `${parts[2]}-${parts[1]}-${parts[0]}` : d.date;
          return { date: new Date(iso), value: d.nav };
        }).filter(r => !isNaN(r.date.getTime()));
        metrics = computeBenchmarkMetrics(records, proxy.label, navRecords);
        toast.success(`${proxy.label} loaded (proxy). Alpha = ${metrics.alphaInception > 0 ? '+' : ''}${metrics.alphaInception.toFixed(2)}%`);
      }
      onBenchmarkLoaded(metrics);
    } catch (e: unknown) {
      toast.error(`Failed to load ${bmName}: ${e instanceof Error ? e.message : 'unknown error'}`);
    } finally { setLoading(null); }
  };

  const activeLabel = activeBm?.name ?? null;

  return (
    <div className="mt-3 mb-1">
      <div className="text-xs text-white/30 uppercase tracking-wider font-semibold mb-2">Overlay Benchmark TRI</div>
      <div className="flex flex-wrap gap-1.5">
        {QUICK_BENCHMARKS.map(bm => {
          const isActive = !!activeLabel && (activeLabel === bm || activeLabel.startsWith(bm.replace(' TRI', '')));
          const isSuggested = suggestedBmName === bm;
          const isLoading = loading === bm;
          return (
            <button
              key={bm}
              onClick={() => handlePick(bm)}
              disabled={!!loading}
              className={cn(
                'flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold border transition-all',
                isActive
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : isSuggested
                    ? 'bg-blue-500/15 border-blue-500/30 text-blue-300 hover:bg-blue-500/25'
                    : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10 hover:text-white/70',
                loading && !isLoading ? 'opacity-40 cursor-not-allowed' : ''
              )}
            >
              {isLoading && <Loader2 size={10} className="animate-spin" />}
              {isActive && !isLoading && <X size={10} />}
              {bm.replace(' TRI', '')}
              {isSuggested && !isActive && <span className="ml-1 text-[9px] text-blue-400/70 font-normal">suggested</span>}
            </button>
          );
        })}
        {activeBm && !QUICK_BENCHMARKS.includes(activeBm.name as typeof QUICK_BENCHMARKS[number]) && (
          <button
            onClick={onBenchmarkCleared}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold border bg-amber-500/20 border-amber-500/40 text-amber-300"
          >
            <X size={10} /> {activeBm.name.replace(' (proxy)', '').replace(' TRI', '')}
          </button>
        )}
      </div>
      {activeLabel && (
        <div className="mt-1.5 text-xs text-amber-400/60">
          — Dashed amber line = {activeLabel}. Alpha = Fund CAGR − Benchmark CAGR since inception.
        </div>
      )}
    </div>
  );
}

// ─── Benchmark Overlay Section ────────────────────────────────────────────────

function BenchmarkSection({ navRecords, bm, meta, onBenchmarkLoaded, onBenchmarkCleared }: {
  navRecords: NavRecord[];
  bm: BenchmarkMetrics | null;
  meta: MFMeta;
  onBenchmarkLoaded: (bm: BenchmarkMetrics) => void;
  onBenchmarkCleared: () => void;
}) {
  const suggestedBmName = getBenchmarkSuggestion(meta.schemeCategory || meta.schemeType || '');
  const [bmName, setBmName] = useState(suggestedBmName);
  const [autoFetching, setAutoFetching] = useState(false);

  // Derive inception date and format for display
  const inceptionDate = navRecords.length > 0 ? navRecords[0].date : null;
  const inceptionDisplay = inceptionDate
    ? new Date(inceptionDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : null;

  // Update bmName suggestion when fund changes (but only if user hasn't typed a custom name)
  const prevSuggestionRef = useRef(suggestedBmName);
  useEffect(() => {
    if (prevSuggestionRef.current !== suggestedBmName) {
      setBmName(suggestedBmName);
      prevSuggestionRef.current = suggestedBmName;
    }
  }, [suggestedBmName]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    setLoading(true); setError(null);
    try {
      // Auto-detect benchmark name from filename
      const detected = detectBenchmarkNameFromFilename(file.name);
      const nameToUse = detected || bmName;
      if (detected && detected !== bmName) {
        setBmName(detected);
        toast.info(`Benchmark name auto-detected: ${detected}`);
      }
      const text = await file.text();
      const records = parseBenchmarkCSV(text, nameToUse);
      const metrics = computeBenchmarkMetrics(records, nameToUse, navRecords);
      onBenchmarkLoaded(metrics);
      toast.success(`Benchmark loaded: ${records.length} records, alpha = ${metrics.alphaInception > 0 ? '+' : ''}${metrics.alphaInception.toFixed(2)}%`);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      setError(msg);
      toast.error('Benchmark CSV parse failed');
    } finally { setLoading(false); }
  };

  // Auto-fetch benchmark via mfapi index fund proxy
  const handleAutoFetch = async () => {
    const proxy = BENCHMARK_PROXY_MAP[bmName];
    if (!proxy) {
      toast.error(`No auto-fetch available for "${bmName}". Please upload CSV manually.`);
      return;
    }
    setAutoFetching(true); setError(null);
    try {
      toast.info(`Fetching ${proxy.label} from AMFI via mfapi...`);
      const rawData = await fetchBenchmarkProxy(proxy.schemeCode);
      if (rawData.length === 0) throw new Error('No data returned from mfapi');
      // Convert to BenchmarkRecord format expected by computeBenchmarkMetrics
      // mfapi returns DD-MM-YYYY format
      const records = rawData.map(d => {
        if (!d || typeof d.date !== 'string' || !d.date) return { date: new Date(NaN), value: 0 };
        const parts = d.date.split('-');
        const iso = parts.length === 3 ? `${parts[2]}-${parts[1]}-${parts[0]}` : d.date;
        return { date: new Date(iso), value: d.nav };
      }).filter(r => !isNaN(r.date.getTime()));
      const metrics = computeBenchmarkMetrics(records, proxy.label, navRecords);
      onBenchmarkLoaded(metrics);
      toast.success(`${proxy.label} loaded: ${records.length} records. ${proxy.note}`);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Fetch failed';
      setError(`Auto-fetch failed: ${msg}. Please upload CSV manually.`);
      toast.error('Auto-fetch failed — try uploading CSV manually');
    } finally { setAutoFetching(false); }
  };

  if (bm) {
    return (
      <CollapsibleSection title="Benchmark Overlay" badge={<span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/15 text-emerald-400">{bm.name}</span>}>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          <KPICard label="Fund CAGR" value={`${bm.cagrFund > 0 ? '+' : ''}${bm.cagrFund.toFixed(2)}%`} sub="since inception" color={retColor(bm.cagrFund)} />
          <KPICard label="BM CAGR" value={`${bm.cagrBm > 0 ? '+' : ''}${bm.cagrBm.toFixed(2)}%`} sub={bm.name} color={retColor(bm.cagrBm)} />
          <KPICard label="Alpha" value={`${bm.alphaInception > 0 ? '+' : ''}${bm.alphaInception.toFixed(2)}%`} sub="Fund − Benchmark" color={bm.alphaInception > 0 ? 'text-emerald-400' : 'text-red-400'} />
          <KPICard label="1Y Rolling Beat" value={bm.rolling1YBeatPct !== null ? `${bm.rolling1YBeatPct.toFixed(1)}%` : 'N/A'} sub="% windows beat BM" color={bm.rolling1YBeatPct !== null && bm.rolling1YBeatPct > 60 ? 'text-emerald-400' : 'text-amber-400'} />
          <KPICard label="3Y Rolling Beat" value={bm.rolling3YBeatPct !== null ? `${bm.rolling3YBeatPct.toFixed(1)}%` : 'N/A'} sub="% windows beat BM" color={bm.rolling3YBeatPct !== null && bm.rolling3YBeatPct > 60 ? 'text-emerald-400' : 'text-amber-400'} />
          <KPICard label="1Y Alpha (median)" value={bm.rolling1YAlphaMedian !== null ? `${bm.rolling1YAlphaMedian > 0 ? '+' : ''}${bm.rolling1YAlphaMedian.toFixed(2)}%` : 'N/A'} sub="median excess return" color={bm.rolling1YAlphaMedian !== null && bm.rolling1YAlphaMedian > 0 ? 'text-emerald-400' : 'text-red-400'} />
          <KPICard label="Tracking Error" value={`${bm.trackingError.toFixed(2)}%`} sub="annualised" />
          <KPICard label="Info Ratio" value={bm.informationRatio !== null ? bm.informationRatio.toFixed(2) : 'N/A'} sub="Alpha / TE" color={bm.informationRatio !== null && bm.informationRatio > 0.5 ? 'text-emerald-400' : 'text-amber-400'} />
        </div>
        <button onClick={onBenchmarkCleared} className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-colors">
          <X size={12} /> Remove Benchmark
        </button>
      </CollapsibleSection>
    );
  }

  const hasProxy = !!BENCHMARK_PROXY_MAP[bmName];

  return (
    <CollapsibleSection title="Benchmark Overlay" defaultOpen={false} badge={<span className="px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/15 text-amber-400">Not loaded</span>}>

      {/* Inception date callout — key info for NSE download */}
      {inceptionDisplay && (
        <div className="mb-4 flex items-start gap-3 p-3 rounded-lg bg-blue-500/8 border border-blue-500/20">
          <div className="w-2 h-2 rounded-full bg-blue-400 mt-1.5 flex-shrink-0" />
          <div>
            <div className="text-xs font-semibold text-blue-300 mb-0.5">Fund Inception Date</div>
            <div className="text-sm font-mono font-bold text-white">{inceptionDisplay}</div>
            <div className="text-xs text-white/40 mt-0.5">Use this as the start date when downloading benchmark data from NSE Indices</div>
          </div>
        </div>
      )}

      {/* Benchmark name + auto-fetch */}
      <div className="mb-4">
        <label className="block text-xs font-semibold uppercase tracking-wider text-white/40 mb-1.5">Benchmark Index</label>
        <div className="flex gap-2 items-center flex-wrap">
          <input
            type="text"
            value={bmName}
            onChange={e => setBmName(e.target.value)}
            className="bg-[#0f1117] border border-white/20 rounded-lg px-3 py-2 text-sm text-white placeholder-white/40 outline-none focus:border-blue-500/60 focus:bg-[#141720] transition-colors flex-1 min-w-[200px] max-w-sm"
            placeholder="e.g. Nifty 500 TRI"
          />
          <button
            onClick={handleAutoFetch}
            disabled={autoFetching || !hasProxy}
            title={hasProxy ? `Auto-fetch ${bmName} via AMFI index fund proxy` : `No auto-fetch available for "${bmName}" — upload CSV manually`}
            className={cn(
              'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border transition-all',
              hasProxy
                ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400 hover:bg-emerald-500/20 cursor-pointer'
                : 'bg-white/5 border-white/10 text-white/25 cursor-not-allowed'
            )}
          >
            {autoFetching ? <Loader2 size={12} className="animate-spin" /> : <Download size={12} />}
            {autoFetching ? 'Fetching...' : 'Auto-Fetch'}
          </button>
        </div>
        {hasProxy && (
          <div className="mt-1.5 text-xs text-emerald-400/60">
            ✓ Auto-fetch available via {BENCHMARK_PROXY_MAP[bmName].schemeName}
          </div>
        )}
        {!hasProxy && (
          <div className="mt-1.5 text-xs text-white/30">
            Auto-fetch not available for this index — upload CSV from NSE Indices below
          </div>
        )}
      </div>

      {/* CSV upload drop zone */}
      <div onDrop={e => { e.preventDefault(); if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); }} onDragOver={e => e.preventDefault()}
        className="border-2 border-dashed border-white/15 rounded-xl p-6 text-center hover:border-blue-500/40 hover:bg-blue-500/5 transition-all cursor-pointer" onClick={() => fileRef.current?.click()}>
        <Upload size={22} className="text-white/25 mx-auto mb-2" />
        <div className="text-sm font-medium text-white/50 mb-1">Drop NSE TRI CSV here or click to upload</div>
        <div className="text-xs text-white/25">Filename auto-detected (e.g. "nifty500_tri.csv" → Nifty 500 TRI). Needs Date + Close columns.</div>
        <input ref={fileRef} type="file" accept=".csv,.txt" className="hidden" onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }} />
      </div>
      {(loading || autoFetching) && <div className="flex items-center gap-2 mt-3 text-sm text-white/50"><Loader2 size={14} className="animate-spin" /> {autoFetching ? 'Fetching from AMFI...' : 'Parsing CSV...'}</div>}
      {error && <div className="mt-3 text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-3">{error}</div>}

      {/* NSE download guide with inception date pre-filled */}
      <div className="mt-4 glass-card p-4 border border-blue-500/10">
        <div className="text-xs font-semibold text-white/50 mb-2 uppercase tracking-wider">How to download from NSE Indices (manual)</div>
        <ol className="space-y-1.5 text-xs text-white/40">
          <li className="flex gap-2"><span className="text-blue-400 font-bold flex-shrink-0">1.</span>
            Go to <span className="text-blue-400 font-mono">niftyindices.com/reports/historical-data</span>
          </li>
          <li className="flex gap-2"><span className="text-blue-400 font-bold flex-shrink-0">2.</span>
            Index Type → Equity → Sub-type → search for <strong className="text-white/60">{bmName.replace(' TRI','')}</strong>
          </li>
          <li className="flex gap-2"><span className="text-blue-400 font-bold flex-shrink-0">3.</span>
            Date range: <strong className="text-amber-300">{inceptionDisplay || 'fund inception date'}</strong> → today
            {' '}(max 1 year per download — download in batches if fund is older)
          </li>
          <li className="flex gap-2"><span className="text-blue-400 font-bold flex-shrink-0">4.</span>
            <strong className="text-amber-400">Always select TRI (Total Return Index)</strong>, not Price Return
          </li>
          <li className="flex gap-2"><span className="text-blue-400 font-bold flex-shrink-0">5.</span>
            Name the file to include the index name (e.g. <span className="font-mono text-white/50">nifty500_tri.csv</span>) — the platform will auto-detect it
          </li>
        </ol>
      </div>
    </CollapsibleSection>
  );
}

// ─── Category Average Row ─────────────────────────────────────────────────────

function CategoryAvgRow({ meta, metrics }: { meta: MFMeta; metrics: FundMetrics }) {
  const catAvg = getCategoryAverage(meta.schemeCategory || meta.schemeType);
  if (!catAvg) return null;

  const peer = computePeerRelativeScore(
    metrics.cagrInception,
    metrics.cagr3Y,
    metrics.sharpeRatio,
    metrics.maxDrawdown,
    catAvg,
  );

  return (
    <tr className="border-b border-amber-500/10 bg-amber-500/5">
      <td className="py-3 font-medium text-amber-300 flex items-center gap-1.5">
        <span>Peer-Relative Score</span>
        <span className="text-xs text-amber-400/60">(vs {peer.categoryName} avg)</span>
      </td>
      <td className="py-3 text-center text-amber-300/60">—</td>
      <td className="py-3 text-center">
        <span className={cn('px-2 py-1 rounded font-mono font-bold text-sm border bg-amber-400/10 border-amber-400/20 text-amber-400')}>
          {peer.score.toFixed(1)}
        </span>
      </td>
      <td className="py-3 text-center font-mono text-amber-300/60">—</td>
      <td className="py-3 text-xs text-amber-300/50 max-w-xs">{peer.evidence}</td>
    </tr>
  );
}

// ─── Analysis Dashboard ───────────────────────────────────────────────────────

function AnalysisDashboard({ state, onBenchmarkLoaded, onBenchmarkCleared, watchlist, onWatchlistToggle, benchmarkLoading }: {
  state: AnalysisState;
  onBenchmarkLoaded: (bm: BenchmarkMetrics) => void;
  onBenchmarkCleared: () => void;
  watchlist: ReturnType<typeof useWatchlist>;
  onWatchlistToggle: () => void;
  benchmarkLoading: boolean;
}) {
  const { meta, metrics: m, scoring: s, benchmark: bm } = state;
  const [ddSort, setDdSort] = useState<{ col: 'fall' | 'days'; dir: 'asc' | 'desc' } | null>(null);
  const inWatchlist = watchlist.isInWatchlist(meta.schemeCode);
  const isAlert = watchlist.alerts.some(a => a.schemeCode === meta.schemeCode);

  const verdictBg = s.verdictColor === 'green' ? 'from-emerald-500/20 to-emerald-500/5 border-emerald-500/30' :
    s.verdictColor === 'amber' ? 'from-amber-500/20 to-amber-500/5 border-amber-500/30' :
    'from-red-500/20 to-red-500/5 border-red-500/30';
  const verdictText = s.verdictColor === 'green' ? 'text-emerald-400' : s.verdictColor === 'amber' ? 'text-amber-400' : 'text-red-400';
  const bmGrowthSeries = bm ? bm.records.map(r => ({ date: r.date, value: r.value })) : undefined;

  return (
    <div className="space-y-5">
      {/* Fund Header */}
      <div className="glass-card p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-blue-400 mb-1">{meta.schemeCategory || meta.schemeType}</div>
            <h1 className="text-xl font-bold text-white leading-tight mb-1">{meta.schemeName}</h1>
            <div className="flex flex-wrap gap-3 text-xs text-white/40">
              <span>{meta.fundHouse}</span>
              {meta.isin && <span>ISIN: <span className="font-mono text-white/60">{meta.isin}</span></span>}
              <span>AMFI: <span className="font-mono text-white/60">{meta.schemeCode}</span></span>
              <span>Inception: <span className="text-white/60">{fmtDate(m.inceptionDate)}</span></span>
              <span>{m.totalRecords} trading days</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className={cn('px-5 py-3 rounded-xl border bg-gradient-to-br text-center', verdictBg)}>
              <div className="text-xs font-semibold uppercase tracking-wider text-white/50 mb-1">Verdict</div>
              <div className={cn('text-xl font-bold', verdictText)}>{s.verdict}</div>
              <div className="text-xs text-white/40 mt-1">{s.totalScore.toFixed(2)} / 10</div>
            </div>
            <div className="flex gap-2">
              <button onClick={onWatchlistToggle}
                className={cn('flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border transition-colors',
                  inWatchlist
                    ? isAlert ? 'bg-amber-500/20 border-amber-500/30 text-amber-400' : 'bg-emerald-500/15 border-emerald-500/25 text-emerald-400'
                    : 'bg-white/5 border-white/10 text-white/40 hover:text-white/70')}>
                {inWatchlist ? (isAlert ? <Bell size={12} /> : <Star size={12} />) : <StarOff size={12} />}
                {inWatchlist ? (isAlert ? 'BUY ZONE!' : 'Watching') : 'Add to Watchlist'}
              </button>

            </div>
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <KPICard label="CAGR (Inception)" value={`${m.cagrInception > 0 ? '+' : ''}${m.cagrInception.toFixed(2)}%`} sub={`${m.ageYears.toFixed(1)} years`} color={retColor(m.cagrInception)} />
        <KPICard label="1Y CAGR" value={m.cagr1Y !== null ? `${m.cagr1Y > 0 ? '+' : ''}${m.cagr1Y.toFixed(2)}%` : 'N/A'} sub="trailing 1 year" color={m.cagr1Y !== null ? retColor(m.cagr1Y) : 'text-white/40'} />
        <KPICard label="Max Drawdown" value={`${m.maxDrawdown.toFixed(2)}%`} sub={fmtDate(m.maxDrawdownTroughDate)} color={ddColor(m.maxDrawdown)} />
        <KPICard label="Sharpe Ratio" value={m.sharpeRatio.toFixed(2)} sub="rf = 6.5%" color={m.sharpeRatio > 1 ? 'text-emerald-400' : m.sharpeRatio > 0.5 ? 'text-amber-400' : 'text-red-400'} />
        <KPICard label="Current DD" value={`${m.currentDrawdownFromATH.toFixed(2)}%`} sub={`ATH: ₹${m.athNav.toFixed(3)}`} color={ddColor(m.currentDrawdownFromATH)} />
        <KPICard label="Stage" value={s.stage} sub={(s.lumpsumDecision ?? '').split('—')[0]?.trim() ?? ''} color={s.verdictColor === 'green' ? 'text-emerald-400' : s.verdictColor === 'amber' ? 'text-amber-400' : 'text-red-400'} />
      </div>

      {/* Lumpsum Decision */}
      <div className={cn('glass-card p-4 border', s.verdictColor === 'green' ? 'border-emerald-500/20' : s.verdictColor === 'amber' ? 'border-amber-500/20' : 'border-red-500/20')}>
        <div className="flex items-start gap-3">
          <div className="mt-0.5">{s.verdictColor === 'green' ? <CheckCircle size={16} className="text-emerald-400" /> : <AlertTriangle size={16} className={s.verdictColor === 'amber' ? 'text-amber-400' : 'text-red-400'} />}</div>
          <div>
            <div className="text-sm font-semibold text-white mb-1">Lumpsum Decision</div>
            <div className="text-sm text-white/60">{s.lumpsumDecision}</div>
          </div>
        </div>
      </div>

      {/* Trailing Returns Table with Peer Comparison */}
      {(() => {
        const peerReturns = getCategoryTrailingReturns(meta.schemeCategory || meta.schemeType);
        const periods = ['1W','1M','3M','6M','1Y','2Y','3Y','5Y','Since Inception'] as const;
        const fundVals = [
          { v: m.ret1W, note: 'abs' },
          { v: m.ret1M, note: 'abs' },
          { v: m.ret3M, note: 'abs' },
          { v: m.ret6M, note: 'abs' },
          { v: m.cagr1Y, note: 'cagr' },
          { v: m.cagr2Y, note: 'cagr' },
          { v: m.cagr3Y, note: 'cagr' },
          { v: m.cagr5Y, note: 'cagr' },
          { v: m.cagrInception, note: 'cagr' },
        ];
        const peerVals = peerReturns ? [
          peerReturns.ret1W,
          peerReturns.ret1M,
          peerReturns.ret3M,
          peerReturns.ret6M,
          peerReturns.cagr1Y,
          peerReturns.cagr2Y,
          peerReturns.cagr3Y,
          peerReturns.cagr5Y,
          null, // Since Inception has no category avg
        ] : null;
        return (
          <div className="glass-card overflow-hidden">
            <div className="px-5 py-3 border-b border-white/8 flex items-start justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold text-white/70 uppercase tracking-wider">Trailing Returns</h3>
                <p className="text-xs text-white/30 mt-0.5">Point-to-point from latest NAV. Short periods not annualized.</p>
              </div>
              {peerReturns && (
                <span className="flex-shrink-0 text-[10px] px-2 py-1 rounded bg-amber-500/10 border border-amber-500/20 text-amber-400/70">
                  vs {peerReturns.categoryName} avg
                </span>
              )}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/8">
                    <th className="py-2.5 px-4 text-left text-xs font-semibold uppercase tracking-wider text-white/30">Period</th>
                    {periods.map(p => (
                      <th key={p} className="py-2.5 px-4 text-right text-xs font-semibold uppercase tracking-wider text-white/30">{p}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {/* Fund row */}
                  <tr className="border-b border-white/5">
                    <td className="py-3 px-4 text-xs font-semibold text-white/50 whitespace-nowrap">This Fund</td>
                    {fundVals.map(({ v, note }, i) => (
                      <td key={i} className={cn(
                        'py-3 px-4 font-mono font-bold text-sm tabular-nums text-right',
                        v === null ? 'text-white/20' : retColor(v)
                      )}>
                        {v === null ? 'N/A' : `${v > 0 ? '+' : ''}${v.toFixed(2)}%`}
                        {v !== null && note === 'cagr' && i >= 4 && (
                          <span className="text-[9px] text-white/25 font-normal ml-0.5">p.a.</span>
                        )}
                      </td>
                    ))}
                  </tr>
                  {/* Category Avg row */}
                  {peerVals && (
                    <tr className="border-b border-amber-500/10 bg-amber-500/4">
                      <td className="py-3 px-4 text-xs font-semibold text-amber-400/70 whitespace-nowrap">
                        ~Cat Avg
                        <span className="ml-1 text-amber-400/40 font-normal">(approx)</span>
                      </td>
                      {peerVals.map((v, i) => (
                        <td key={i} className={cn(
                          'py-3 px-4 font-mono text-sm tabular-nums text-right',
                          v === null ? 'text-white/15' : 'text-amber-400/70'
                        )}>
                          {v === null ? '—' : `${v > 0 ? '+' : ''}${v.toFixed(2)}%`}
                          {v !== null && i >= 4 && (
                            <span className="text-[9px] text-amber-400/30 font-normal ml-0.5">p.a.</span>
                          )}
                        </td>
                      ))}
                    </tr>
                  )}
                  {/* Alpha row (fund - category avg) */}
                  {peerVals && (
                    <tr>
                      <td className="py-2.5 px-4 text-xs font-semibold text-white/30 whitespace-nowrap">Alpha</td>
                      {fundVals.map(({ v }, i) => {
                        const peer = peerVals[i];
                        const alpha = (v !== null && peer !== null) ? v - peer : null;
                        return (
                          <td key={i} className={cn(
                            'py-2.5 px-4 font-mono text-xs tabular-nums text-right font-semibold',
                            alpha === null ? 'text-white/15' : alpha > 0 ? 'text-emerald-400' : alpha < 0 ? 'text-red-400' : 'text-white/30'
                          )}>
                            {alpha === null ? '—' : `${alpha > 0 ? '+' : ''}${alpha.toFixed(2)}%`}
                          </td>
                        );
                      })}
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="px-5 py-2 border-t border-white/5 text-[10px] text-white/20">
              1W/1M/3M/6M = absolute return · 1Y+ = CAGR p.a. · Cat avg = approximate category median (AMFI/Morningstar, Mar 2026) · Short-period cat avg derived from 1Y figure · Latest NAV: ₹{m.latestNav.toFixed(3)} as of {m.latestDate.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
            </div>
          </div>
        );
      })()}
      {/* Growth Chart */}
      <CollapsibleSection title={bm ? `Growth of ₹100 — Fund vs ${bm.name}` : 'Growth of ₹100 Since Inception'}>
        <SectionErrorBoundary label="Growth Chart">
        <GrowthChart data={m.growthSeries} bmData={bmGrowthSeries} />

        {/* Quick-pick benchmark overlay buttons */}
        <QuickBenchmarkPicker
          navRecords={state.navRecords}
          activeBm={bm}
          suggestedBmName={getBenchmarkSuggestion(meta.schemeCategory || meta.schemeType || '')}
          onBenchmarkLoaded={onBenchmarkLoaded}
          onBenchmarkCleared={onBenchmarkCleared}
        />

        <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="text-white/40">Inception NAV: <span className="text-white font-mono">₹{m.inceptionNav.toFixed(3)}</span></div>
          <div className="text-white/40">Latest NAV: <span className="text-white font-mono">₹{m.latestNav.toFixed(3)}</span></div>
          <div className="text-white/40">ATH NAV: <span className="text-white font-mono">₹{m.athNav.toFixed(3)}</span></div>
          <div className="text-white/40">ATH Date: <span className="text-white">{fmtDate(m.athDate)}</span></div>
        </div>
        </SectionErrorBoundary>
      </CollapsibleSection>

      {/* Benchmark Overlay */}
      <SectionErrorBoundary label="Benchmark Overlay">
      <BenchmarkSection navRecords={state.navRecords} bm={bm} meta={meta} onBenchmarkLoaded={onBenchmarkLoaded} onBenchmarkCleared={onBenchmarkCleared} />
      </SectionErrorBoundary>

      {/* Annual Returns */}
      <CollapsibleSection title="Annual Returns — Calendar Year">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-white/10"><th className="text-left py-2 text-white/40 font-medium">Period</th><th className="text-right py-2 text-white/40 font-medium">Start NAV</th><th className="text-right py-2 text-white/40 font-medium">End NAV</th><th className="text-right py-2 text-white/40 font-medium">Return</th><th className="text-right py-2 text-white/40 font-medium">Trading Days</th></tr></thead>
            <tbody>
              {m.annualReturns.map(a => (
                <tr key={a.year} className="border-b border-white/5 hover:bg-white/3">
                  <td className="py-2.5 text-white/80">{a.label}</td>
                  <td className="py-2.5 text-right font-mono text-white/60">₹{a.startNav.toFixed(3)}</td>
                  <td className="py-2.5 text-right font-mono text-white/60">₹{a.endNav.toFixed(3)}</td>
                  <td className={cn('py-2.5 text-right font-mono font-bold', retColor(a.returnPct))}>{a.returnPct > 0 ? '+' : ''}{a.returnPct.toFixed(2)}%</td>
                  <td className="py-2.5 text-right text-white/40">{a.tradingDays}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CollapsibleSection>

      {/* Risk Metrics */}
      <CollapsibleSection title="Risk Metrics">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          <KPICard label="Ann. Std Dev" value={`${m.stdDevAnnual.toFixed(1)}%`} sub="annualised volatility" />
          <KPICard label="Sharpe Ratio" value={m.sharpeRatio.toFixed(2)} sub="rf=6.5%" color={m.sharpeRatio > 1 ? 'text-emerald-400' : 'text-amber-400'} />
          <KPICard label="Sortino Ratio" value={m.sortinoRatio.toFixed(2)} sub="downside deviation" color={m.sortinoRatio > 1 ? 'text-emerald-400' : 'text-amber-400'} />
          <KPICard label="Calmar Ratio" value={m.calmarRatio.toFixed(2)} sub="CAGR / Max DD" color={m.calmarRatio > 0.5 ? 'text-emerald-400' : 'text-amber-400'} />
        </div>
        <DrawdownChart data={m.drawdownSeries} />
      </CollapsibleSection>

      {/* Drawdown Episodes */}
      <CollapsibleSection title={`Drawdown Episodes (>5%) — ${m.drawdownEpisodes.length} found`}>
        {m.drawdownEpisodes.length === 0 ? (
          <div className="text-white/30 text-sm py-4 text-center">No drawdown episodes exceeding 5% found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-separate" style={{borderSpacing: 0}}>
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left py-2 pr-3 text-white/40 font-medium w-6">#</th>
                  <th className="text-left py-2 pr-2 text-white/40 font-medium">Peak Date</th>
                  <th className="text-right py-2 pl-4 pr-4 text-white/40 font-medium border-l border-white/10">Peak NAV</th>
                  <th className="text-left py-2 pl-4 pr-2 text-white/40 font-medium border-l border-white/10">Trough Date</th>
                  <th className="text-right py-2 pl-4 pr-4 text-white/40 font-medium border-l border-white/10">Trough NAV</th>
                  <th
                    className="text-right py-2 pl-4 pr-4 font-medium border-l border-white/10 cursor-pointer select-none group"
                    onClick={() => setDdSort(s => s?.col === 'fall' ? { col: 'fall', dir: s.dir === 'asc' ? 'desc' : 'asc' } : { col: 'fall', dir: 'asc' })}
                  >
                    <span className={cn('inline-flex items-center gap-1', ddSort?.col === 'fall' ? 'text-amber-400' : 'text-white/40 group-hover:text-white/60')}>
                      Fall %
                      <span className="text-[10px]">{ddSort?.col === 'fall' ? (ddSort.dir === 'asc' ? '↑' : '↓') : '↕'}</span>
                    </span>
                  </th>
                  <th className="text-left py-2 pl-4 pr-2 text-white/40 font-medium border-l border-white/10">Recovery Date</th>
                  <th
                    className="text-right py-2 pl-3 pr-4 font-medium cursor-pointer select-none group"
                    onClick={() => setDdSort(s => s?.col === 'days' ? { col: 'days', dir: s.dir === 'asc' ? 'desc' : 'asc' } : { col: 'days', dir: 'desc' })}
                  >
                    <span className={cn('inline-flex items-center gap-1', ddSort?.col === 'days' ? 'text-amber-400' : 'text-white/40 group-hover:text-white/60')}>
                      Days
                      <span className="text-[10px]">{ddSort?.col === 'days' ? (ddSort.dir === 'asc' ? '↑' : '↓') : '↕'}</span>
                    </span>
                  </th>
                  <th className="text-left py-2 pl-4 text-white/40 font-medium border-l border-white/10">Status</th>
                </tr>
              </thead>
              <tbody>
                {[...m.drawdownEpisodes].sort((a, b) => {
                  if (!ddSort) return 0;
                  const valA = ddSort.col === 'fall' ? a.fallPct : (a.recoveryDays ?? Infinity);
                  const valB = ddSort.col === 'fall' ? b.fallPct : (b.recoveryDays ?? Infinity);
                  return ddSort.dir === 'asc' ? valA - valB : valB - valA;
                }).map(e => {
                  const isOngoing = e.status === 'Ongoing';
                  return (
                    <tr key={e.id} className={cn(
                      'border-b',
                      isOngoing
                        ? 'border-amber-500/30 bg-amber-500/8 shadow-[inset_4px_0_0_rgba(251,191,36,0.8)]'
                        : 'border-white/5 hover:bg-white/3'
                    )}>
                      <td className={cn('py-3 pr-3 pl-4 text-sm font-bold', isOngoing ? 'text-amber-300' : 'text-white/50')}>{e.id}</td>
                      <td className={cn('py-3 pr-3 text-sm font-semibold', isOngoing ? 'text-amber-200' : 'text-white/75')}>{fmtDate(e.peakDate)}</td>
                      <td className={cn('py-3 pl-4 pr-4 text-right font-mono text-sm border-l', isOngoing ? 'text-amber-200/80 border-amber-500/25' : 'text-white/60 border-white/8')}>₹{e.peakNav.toFixed(3)}</td>
                      <td className={cn('py-3 pl-4 pr-3 border-l text-sm font-semibold', isOngoing ? 'text-amber-200 border-amber-500/25' : 'text-white/75 border-white/8')}>{fmtDate(e.troughDate)}</td>
                      <td className={cn('py-3 pl-4 pr-4 text-right font-mono text-sm border-l', isOngoing ? 'text-amber-200/80 border-amber-500/25' : 'text-white/60 border-white/8')}>₹{e.troughNav.toFixed(3)}</td>
                      <td className={cn('py-3 pl-4 pr-4 text-right font-mono font-bold text-base border-l', isOngoing ? 'border-amber-500/25' : 'border-white/8', ddColor(e.fallPct))}>{e.fallPct.toFixed(2)}%</td>
                      <td className={cn('py-3 pl-4 pr-3 border-l text-sm font-medium', isOngoing ? 'text-amber-300/80 border-amber-500/25' : 'text-white/55 border-white/8')}>{e.recoveryDate ? fmtDate(e.recoveryDate) : '—'}</td>
                      <td className={cn('py-3 pl-3 pr-4 text-right font-mono text-sm font-semibold', isOngoing ? 'text-amber-300' : 'text-white/45')}>{e.recoveryDays ? `${e.recoveryDays}d` : '—'}</td>
                      <td className={cn('py-3 pl-4 border-l', isOngoing ? 'border-amber-500/25' : 'border-white/8')}>
                        {isOngoing ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/25 text-amber-300 text-xs font-bold border border-amber-500/40">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-400" />
                            </span>
                            Ongoing
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 text-xs font-semibold">Recovered</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </CollapsibleSection>

      {/* Rolling Returns */}
      <CollapsibleSection title="Rolling Returns Analysis">
        {/* Stats grid — shows 10Y card only when data is available, with a highlight badge */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
          {[
            { label: '1-Year Rolling', stats: m.rolling1YStats, highlight: false },
            { label: '3-Year Rolling', stats: m.rolling3YStats, highlight: false },
            { label: '5-Year Rolling', stats: m.rolling5YStats, highlight: false },
            { label: '10-Year Rolling', stats: m.rolling10YStats, highlight: true },
          ].map(({ label, stats, highlight }) => (
            <div key={label} className={cn(
              'rounded-lg p-3 relative',
              highlight && stats ? 'bg-amber-500/8 border border-amber-500/20' : 'bg-white/3'
            )}>
              <div className="flex items-center gap-1.5 mb-2">
                <span className="text-xs font-semibold text-white/50 uppercase tracking-wider">{label}</span>
                {highlight && stats && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-semibold uppercase tracking-wider">10Y+</span>
                )}
              </div>
              {stats ? (
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between"><span className="text-white/40">Best</span><span className="font-mono text-emerald-400 font-bold">{stats.best > 0 ? '+' : ''}{stats.best.toFixed(2)}%</span></div>
                  <div className="flex justify-between"><span className="text-white/40">Worst</span><span className="font-mono text-red-400 font-bold">{stats.worst.toFixed(2)}%</span></div>
                  <div className="flex justify-between"><span className="text-white/40">Median</span><span className={cn('font-mono font-bold', retColor(stats.median))}>{stats.median > 0 ? '+' : ''}{stats.median.toFixed(2)}%</span></div>
                  <div className="flex justify-between"><span className="text-white/40">% Positive</span><span className="font-mono text-white/70">{stats.pctPositive.toFixed(1)}%</span></div>
                  <div className="flex justify-between"><span className="text-white/40">Periods</span><span className="font-mono text-white/40">{stats.count}</span></div>
                </div>
              ) : (
                <div className="text-white/25 text-xs py-2">
                  {highlight ? 'Needs 10+ years of history' : 'Fund history too short'}
                </div>
              )}
            </div>
          ))}
        </div>
        <SectionErrorBoundary label="Rolling Returns Charts">
        <div className="space-y-4">
          <div>
            <div className="text-xs text-white/40 mb-2">1-Year Rolling CAGR{bm ? <span className="text-amber-400/60 ml-2">vs {bm.name}</span> : null}</div>
            <RollingChart data={m.rolling1Y} label="1Y CAGR" bmData={bm?.rolling1YSeries} bmName={bm?.name} />
          </div>
          {m.rolling3Y.length > 0 && (
            <div>
              <div className="text-xs text-white/40 mb-2">3-Year Rolling CAGR{bm ? <span className="text-amber-400/60 ml-2">vs {bm.name}</span> : null}</div>
              <RollingChart data={m.rolling3Y} label="3Y CAGR" bmData={bm?.rolling3YSeries} bmName={bm?.name} />
            </div>
          )}
          {m.rolling5Y.length > 0 && (
            <div>
              <div className="text-xs text-white/40 mb-2">5-Year Rolling CAGR{bm ? <span className="text-amber-400/60 ml-2">vs {bm.name}</span> : null}</div>
              <RollingChart data={m.rolling5Y} label="5Y CAGR" bmData={bm?.rolling5YSeries} bmName={bm?.name} />
            </div>
          )}
          {m.rolling10Y.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs text-white/40">10-Year Rolling CAGR{bm ? <span className="text-amber-400/60 ml-2">vs {bm.name}</span> : null}</span>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-semibold uppercase tracking-wider">10Y+ Fund</span>
              </div>
              <RollingChart data={m.rolling10Y} label="10Y CAGR" bmData={bm?.rolling10YSeries} bmName={bm?.name} />
            </div>
          )}
        </div>
        </SectionErrorBoundary>
      </CollapsibleSection>

      {/* Monthly Heatmap */}
      <CollapsibleSection title="Monthly Returns Heatmap">
        <SectionErrorBoundary label="Monthly Heatmap">
        <MonthlyHeatmap data={m.monthlyReturns} />
        <div className="mt-3 flex gap-4 text-xs text-white/30">
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-emerald-500/80 inline-block" /> &gt;+10%</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-emerald-500/50 inline-block" /> 0–10%</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-red-500/50 inline-block" /> 0 to −10%</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-red-500/80 inline-block" /> &lt;−10%</span>
        </div>
        </SectionErrorBoundary>
      </CollapsibleSection>

      {/* Scoring Grid with Category Avg Row */}
      <CollapsibleSection title="Weighted Scoring Grid — 8 Parameters + Peer Relative">
        <SectionErrorBoundary label="Scoring Grid & Peer Comparison">
        <div className="overflow-x-auto mb-4">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-2 text-white/40 font-medium">Parameter</th>
                <th className="text-center py-2 text-white/40 font-medium w-16">Weight</th>
                <th className="text-center py-2 text-white/40 font-medium w-20">Score</th>
                <th className="text-center py-2 text-white/40 font-medium w-20">Weighted</th>
                <th className="text-left py-2 text-white/40 font-medium">Evidence (computed)</th>
              </tr>
            </thead>
            <tbody>
              {s.rows.map(row => (
                <tr key={row.parameter} className="border-b border-white/5 hover:bg-white/3">
                  <td className="py-3 font-medium text-white/80">{row.parameter}</td>
                  <td className="py-3 text-center text-white/40">{row.weight}%</td>
                  <td className="py-3 text-center"><span className={cn('px-2 py-1 rounded font-mono font-bold text-sm border', scoreBg(row.score), scoreColor(row.score))}>{row.score.toFixed(1)}</span></td>
                  <td className="py-3 text-center font-mono text-white/60">{((row.weight / 100) * row.score).toFixed(2)}</td>
                  <td className="py-3 text-xs text-white/40 max-w-xs">{row.evidence}</td>
                </tr>
              ))}
              <CategoryAvgRow meta={meta} metrics={m} />
            </tbody>
            <tfoot>
              <tr className="border-t border-white/20">
                <td colSpan={2} className="py-3 font-bold text-white">Total Weighted Score</td>
                <td className="py-3 text-center"><span className={cn('px-3 py-1.5 rounded font-mono font-bold text-base border', scoreBg(s.totalScore), scoreColor(s.totalScore))}>{s.totalScore.toFixed(2)}</span></td>
                <td className="py-3 text-center font-mono font-bold text-white">{s.totalScore.toFixed(2)} / 10</td>
                <td className="py-3 text-xs text-white/30">All scores computed from NAV data. No manual inputs.</td>
              </tr>
            </tfoot>
          </table>
        </div>
        <div className="text-xs text-amber-400/60 bg-amber-500/5 border border-amber-500/15 rounded-lg p-3">
          ⚠ Peer-Relative row uses approximate category averages (AMFI/Morningstar India, Mar 2026). Not included in total weighted score. For reference only.
        </div>
        </SectionErrorBoundary>
      </CollapsibleSection>

      {/* Market Context — Fund DD vs Index DD */}
      <MarketContext
        metrics={m}
        benchmark={bm}
        benchmarkLoading={benchmarkLoading}
        category={meta.schemeCategory || meta.schemeType || ''}
      />
      {/* Decision Framework */}
      <DecisionFramework metrics={m} scoring={s} category={meta.schemeCategory || meta.schemeType || ''} />

      {/* Data Provenance */}
      <div className="glass-card p-4">
        <div className="flex items-start gap-3">
          <Info size={16} className="text-blue-400 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-white/40 space-y-1">
            <div className="font-semibold text-white/60">Data Provenance — Zero Speculation</div>
            <div>All metrics computed from <strong className="text-white/60">{m.totalRecords} actual daily NAV records</strong> sourced from AMFI via mfapi.in. No hardcoded values, no copy-paste, no estimates.</div>
            {bm ? <div>Benchmark: <strong className="text-white/60">{bm.name}</strong> — {bm.records.length} records.</div> : <div>Benchmark not loaded. Click a TRI button in the Growth Chart to unlock alpha metrics.</div>}
            <div>Data range: {fmtDate(m.inceptionDate)} → {fmtDate(m.latestDate)} ({m.ageYears.toFixed(2)} years)</div>
          </div>
        </div>
      </div>


    </div>
  );
}

// ─── Fund Comparison Tab ──────────────────────────────────────────────────────

function CompareTab() {
  const [fundA, setFundA] = useState<AnalysisState | null>(null);
  const [fundB, setFundB] = useState<AnalysisState | null>(null);
  const [loadingA, setLoadingA] = useState(false);
  const [loadingB, setLoadingB] = useState(false);

  const loadFund = async (code: number, name: string, slot: 'A' | 'B') => {
    const setLoading = slot === 'A' ? setLoadingA : setLoadingB;
    const setFund = slot === 'A' ? setFundA : setFundB;
    setLoading(true);
    try {
      const { meta, navRecords } = await fetchFundData(code);
      const metrics = computeMetrics(navRecords);
      const scoring = computeScoring(metrics);
      setFund({ meta, navRecords, metrics, scoring, benchmark: null });
      toast.success(`Loaded ${(name ?? '').split?.('—')?.[0]?.trim() ?? name ?? 'fund'}`);
    } catch (e: unknown) {
      toast.error(`Failed to load fund: ${e instanceof Error ? e.message : 'Unknown error'}`);
    } finally { setLoading(false); }
  };

  const rows: { label: string; valA: (s: AnalysisState) => string; valB: (s: AnalysisState) => string; better?: 'higher' | 'lower' }[] = [
    { label: 'Fund House', valA: s => s.meta.fundHouse, valB: s => s.meta.fundHouse },
    { label: 'Category', valA: s => s.meta.schemeCategory || s.meta.schemeType, valB: s => s.meta.schemeCategory || s.meta.schemeType },
    { label: 'Inception Date', valA: s => fmtDate(s.metrics.inceptionDate), valB: s => fmtDate(s.metrics.inceptionDate) },
    { label: 'Fund Age', valA: s => `${s.metrics.ageYears.toFixed(1)} years`, valB: s => `${s.metrics.ageYears.toFixed(1)} years` },
    { label: 'NAV Records', valA: s => `${s.metrics.totalRecords}`, valB: s => `${s.metrics.totalRecords}` },
    { label: 'CAGR (Inception)', valA: s => fmt(s.metrics.cagrInception), valB: s => fmt(s.metrics.cagrInception), better: 'higher' },
    { label: '1Y CAGR', valA: s => s.metrics.cagr1Y !== null ? fmt(s.metrics.cagr1Y) : 'N/A', valB: s => s.metrics.cagr1Y !== null ? fmt(s.metrics.cagr1Y) : 'N/A', better: 'higher' },
    { label: '3Y CAGR', valA: s => s.metrics.cagr3Y !== null ? fmt(s.metrics.cagr3Y) : 'N/A', valB: s => s.metrics.cagr3Y !== null ? fmt(s.metrics.cagr3Y) : 'N/A', better: 'higher' },
    { label: '5Y CAGR', valA: s => s.metrics.cagr5Y !== null ? fmt(s.metrics.cagr5Y) : 'N/A', valB: s => s.metrics.cagr5Y !== null ? fmt(s.metrics.cagr5Y) : 'N/A', better: 'higher' },
    { label: 'Max Drawdown', valA: s => `${s.metrics.maxDrawdown.toFixed(2)}%`, valB: s => `${s.metrics.maxDrawdown.toFixed(2)}%`, better: 'higher' },
    { label: 'Current DD from ATH', valA: s => `${s.metrics.currentDrawdownFromATH.toFixed(2)}%`, valB: s => `${s.metrics.currentDrawdownFromATH.toFixed(2)}%`, better: 'higher' },
    { label: 'Ann. Std Dev', valA: s => `${s.metrics.stdDevAnnual.toFixed(1)}%`, valB: s => `${s.metrics.stdDevAnnual.toFixed(1)}%`, better: 'lower' },
    { label: 'Sharpe Ratio', valA: s => s.metrics.sharpeRatio.toFixed(2), valB: s => s.metrics.sharpeRatio.toFixed(2), better: 'higher' },
    { label: 'Sortino Ratio', valA: s => s.metrics.sortinoRatio.toFixed(2), valB: s => s.metrics.sortinoRatio.toFixed(2), better: 'higher' },
    { label: 'Calmar Ratio', valA: s => s.metrics.calmarRatio.toFixed(2), valB: s => s.metrics.calmarRatio.toFixed(2), better: 'higher' },
    { label: '1Y Rolling Median', valA: s => s.metrics.rolling1YStats ? fmt(s.metrics.rolling1YStats.median) : 'N/A', valB: s => s.metrics.rolling1YStats ? fmt(s.metrics.rolling1YStats.median) : 'N/A', better: 'higher' },
    { label: '1Y Rolling Best', valA: s => s.metrics.rolling1YStats ? fmt(s.metrics.rolling1YStats.best) : 'N/A', valB: s => s.metrics.rolling1YStats ? fmt(s.metrics.rolling1YStats.best) : 'N/A', better: 'higher' },
    { label: '1Y Rolling Worst', valA: s => s.metrics.rolling1YStats ? fmt(s.metrics.rolling1YStats.worst) : 'N/A', valB: s => s.metrics.rolling1YStats ? fmt(s.metrics.rolling1YStats.worst) : 'N/A', better: 'higher' },
    { label: '1Y Rolling % Positive', valA: s => s.metrics.rolling1YStats ? `${s.metrics.rolling1YStats.pctPositive.toFixed(1)}%` : 'N/A', valB: s => s.metrics.rolling1YStats ? `${s.metrics.rolling1YStats.pctPositive.toFixed(1)}%` : 'N/A', better: 'higher' },
    { label: '3Y SIP Median XIRR', valA: s => s.metrics.sip3YStats ? fmt(s.metrics.sip3YStats.median) : 'N/A', valB: s => s.metrics.sip3YStats ? fmt(s.metrics.sip3YStats.median) : 'N/A', better: 'higher' },
    { label: '5Y SIP Median XIRR', valA: s => s.metrics.sip5YStats ? fmt(s.metrics.sip5YStats.median) : 'N/A', valB: s => s.metrics.sip5YStats ? fmt(s.metrics.sip5YStats.median) : 'N/A', better: 'higher' },
    { label: 'Weighted Score', valA: s => `${s.scoring.totalScore.toFixed(2)} / 10`, valB: s => `${s.scoring.totalScore.toFixed(2)} / 10`, better: 'higher' },
    { label: 'Verdict', valA: s => s.scoring.verdict, valB: s => s.scoring.verdict },
    { label: 'Stage', valA: s => s.scoring.stage, valB: s => s.scoring.stage },
    { label: 'Lumpsum Decision', valA: s => (s.scoring.lumpsumDecision ?? '').split('—')[0]?.trim() ?? 'N/A', valB: s => (s.scoring.lumpsumDecision ?? '').split('—')[0]?.trim() ?? 'N/A' },
  ];

  const parseNumeric = (v: string): number | null => {
    const n = parseFloat(v.replace(/[+%]/g, ''));
    return isNaN(n) ? null : n;
  };

  const getWinner = (row: typeof rows[0], a: AnalysisState, b: AnalysisState): 'A' | 'B' | 'tie' | null => {
    if (!row.better) return null;
    const vA = parseNumeric(row.valA(a));
    const vB = parseNumeric(row.valB(b));
    if (vA === null || vB === null) return null;
    if (Math.abs(vA - vB) < 0.01) return 'tie';
    if (row.better === 'higher') return vA > vB ? 'A' : 'B';
    return vA < vB ? 'A' : 'B';
  };

  // Comparison growth chart
  const growthChartData = (() => {
    if (!fundA || !fundB) return [];
    const allDatesSet = new Set<number>();
    fundA.metrics.growthSeries.filter((_, i) => i % 5 === 0).forEach(d => allDatesSet.add(d.date.getTime()));
    fundB.metrics.growthSeries.filter((_, i) => i % 5 === 0).forEach(d => allDatesSet.add(d.date.getTime()));
    const allDates = Array.from(allDatesSet).sort((a, b) => a - b);

    const findNearest = (series: { date: Date; value: number }[], t: number) => {
      const closest = series.reduce((prev, curr) =>
        Math.abs(curr.date.getTime() - t) < Math.abs(prev.date.getTime() - t) ? curr : prev
      );
      return Math.abs(closest.date.getTime() - t) < 10 * 86400000 ? closest.value : null;
    };

    return allDates.map(t => ({
      date: new Date(t).toLocaleDateString('en-IN', { month: 'short', year: '2-digit' }),
      fundA: findNearest(fundA.metrics.growthSeries, t),
      fundB: findNearest(fundB.metrics.growthSeries, t),
    })).filter(d => d.fundA !== null || d.fundB !== null);
  })();

  return (
    <div className="space-y-5">
      <div className="glass-card p-5">
        <SectionHeader icon={<GitCompare size={16} />} title="Fund Comparison" subtitle="Load two funds to compare all metrics side by side" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-blue-400 mb-2">Fund A</div>
            <FundSearchBox placeholder="Search Fund A..." onSelect={(code, name) => loadFund(code, name, 'A')} />
            {loadingA && <div className="flex items-center gap-2 mt-2 text-xs text-white/40"><Loader2 size={12} className="animate-spin" /> Loading...</div>}
            {fundA && !loadingA && <div className="mt-2 text-xs text-emerald-400 font-medium truncate">{fundA.meta.schemeName}</div>}
          </div>
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-violet-400 mb-2">Fund B</div>
            <FundSearchBox placeholder="Search Fund B..." onSelect={(code, name) => loadFund(code, name, 'B')} />
            {loadingB && <div className="flex items-center gap-2 mt-2 text-xs text-white/40"><Loader2 size={12} className="animate-spin" /> Loading...</div>}
            {fundB && !loadingB && <div className="mt-2 text-xs text-violet-400 font-medium truncate">{fundB.meta.schemeName}</div>}
          </div>
        </div>
      </div>

      {fundA && fundB && (
        <>
          {/* Growth comparison chart */}
          <div className="glass-card p-5">
            <div className="font-semibold text-white mb-4">Growth of ₹100 — Side by Side</div>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={growthChartData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => `₹${v}`} />
                <Tooltip contentStyle={{ background: '#1a1d27', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
                <ReferenceLine y={100} stroke="rgba(255,255,255,0.2)" strokeDasharray="4 4" />
                <Line type="monotone" dataKey="fundA" stroke="#4f8ef7" strokeWidth={2} dot={false} name={(fundA.meta.schemeName ?? '').split('—')[0]?.trim() ?? 'Fund A'} connectNulls />
                <Line type="monotone" dataKey="fundB" stroke="#a78bfa" strokeWidth={2} dot={false} name={(fundB.meta.schemeName ?? '').split('—')[0]?.trim() ?? 'Fund B'} connectNulls />
                <Legend wrapperStyle={{ fontSize: 11, color: 'rgba(255,255,255,0.5)' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Comparison table */}
          <div className="glass-card overflow-hidden">
            <div className="px-5 py-4 border-b border-white/8">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-xs font-semibold uppercase tracking-wider text-white/40">Metric</div>
                <div className="text-xs font-semibold uppercase tracking-wider text-blue-400">Fund A — {(fundA.meta.schemeName ?? '').split('—')[0]?.trim() ?? 'Fund A'}</div>
                <div className="text-xs font-semibold uppercase tracking-wider text-violet-400">Fund B — {(fundB.meta.schemeName ?? '').split('—')[0]?.trim() ?? 'Fund B'}</div>
              </div>
            </div>
            <div className="divide-y divide-white/5">
              {rows.map(row => {
                const vA = row.valA(fundA);
                const vB = row.valB(fundB);
                const winner = getWinner(row, fundA, fundB);
                return (
                  <div key={row.label} className="px-5 py-2.5 grid grid-cols-3 gap-4 hover:bg-white/3 transition-colors">
                    <div className="text-xs text-white/40 font-medium self-center">{row.label}</div>
                    <div className={cn('text-sm font-mono font-medium self-center', winner === 'A' ? 'text-emerald-400' : winner === 'B' ? 'text-red-400' : 'text-white/70')}>
                      {vA} {winner === 'A' && <span className="text-xs text-emerald-400/60 ml-1">✓ better</span>}
                    </div>
                    <div className={cn('text-sm font-mono font-medium self-center', winner === 'B' ? 'text-emerald-400' : winner === 'A' ? 'text-red-400' : 'text-white/70')}>
                      {vB} {winner === 'B' && <span className="text-xs text-emerald-400/60 ml-1">✓ better</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="text-xs text-white/30 text-center">All metrics computed from actual AMFI daily NAV data. Green = better value for that metric.</div>
        </>
      )}

      {(!fundA || !fundB) && (
        <div className="glass-card p-8 text-center">
          <GitCompare size={32} className="text-white/15 mx-auto mb-3" />
          <div className="text-white/30 text-sm">Search and select both Fund A and Fund B to see the full comparison table and growth chart.</div>
        </div>
      )}
    </div>
  );
}

// ─── Watchlist Tab ────────────────────────────────────────────────────────────

// ─── 5-day NAV strip types ────────────────────────────────────────────────────
interface NavDay {
  date: string;
  nav: number;
  changePct: number | null; // vs previous day; null for oldest
}

// Fetch last N raw NAV records for a scheme code (no full metrics compute)
async function fetchRecentNavs(schemeCode: number, n = 5): Promise<NavDay[]> {
  const res = await fetch(`https://api.mfapi.in/mf/${schemeCode}`);
  if (!res.ok) throw new Error('Fetch failed');
  const json = await res.json();
  if (json.status !== 'SUCCESS' || !json.data?.length) throw new Error('No data');
  // data is newest-first from API
  const raw: { date: string; nav: string }[] = json.data.slice(0, n + 1);
  const parsed = raw
    .map(d => ({ dateStr: d.date, nav: parseFloat(d.nav) }))
    .filter(d => isFinite(d.nav) && d.nav > 0);
  // Build days newest-first with changePct vs next entry (which is older)
  const days: NavDay[] = [];
  for (let i = 0; i < Math.min(n, parsed.length); i++) {
    const older = parsed[i + 1];
    const changePct = older && older.nav > 0
      ? ((parsed[i].nav - older.nav) / older.nav) * 100
      : null;
    days.push({ date: parsed[i].dateStr, nav: parsed[i].nav, changePct });
  }
  return days; // newest first
}

// ─── Compact Market Context Badge for Watchlist Cards ───────────────────────
function WatchlistMarketBadge({ fundDD, indexDD }: { fundDD: number; indexDD?: number }) {
  if (indexDD === undefined) {
    // No benchmark data yet — show a neutral placeholder only if fund has meaningful DD
    if (Math.abs(fundDD) < 3) return null;
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-white/5 text-white/25 border border-white/10">
        <span>↻</span> Index loading
      </span>
    );
  }

  const absFund = Math.abs(fundDD);
  const absIndex = Math.abs(indexDD);

  // Both near ATH — no badge needed
  if (absFund < 5 && absIndex < 5) return null;

  let label: string;
  let colorClass: string;
  let dotClass: string;

  if (absIndex < 3) {
    // Index near ATH but fund is down — fund-specific
    if (absFund > 8) {
      label = 'Fund-Specific';
      colorClass = 'bg-red-500/15 text-red-400 border-red-500/25';
      dotClass = 'bg-red-400';
    } else {
      return null;
    }
  } else if (absFund <= absIndex * 1.25) {
    label = 'Market Correction';
    colorClass = 'bg-emerald-500/15 text-emerald-400 border-emerald-500/25';
    dotClass = 'bg-emerald-400';
  } else if (absFund <= absIndex * 1.75) {
    label = 'Underperforming';
    colorClass = 'bg-amber-500/15 text-amber-400 border-amber-500/25';
    dotClass = 'bg-amber-400';
  } else {
    label = 'Fund-Specific';
    colorClass = 'bg-red-500/15 text-red-400 border-red-500/25';
    dotClass = 'bg-red-400';
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${colorClass}`}
      title={`Fund DD: ${fundDD.toFixed(1)}% | Index DD: ${indexDD.toFixed(1)}%`}
    >
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${dotClass}`} />
      {label}
    </span>
  );
}

function WatchlistTab({ watchlist, onReanalyze }: {
  watchlist: ReturnType<typeof useWatchlist>;
  onReanalyze: (code: number, name: string) => void;
}) {
  const [editingCode, setEditingCode] = useState<number | null>(null);
  const [editDD, setEditDD] = useState('');
  // Per-fund recent NAV state
  const [navData, setNavData] = useState<Record<number, NavDay[]>>({});
  const [navLoading, setNavLoading] = useState<Record<number, boolean>>({});
  const [navError, setNavError] = useState<Record<number, string>>({});
  const [refreshingAll, setRefreshingAll] = useState(false);
  // Sort state
  type SortKey = 'score' | 'cagr' | 'dd' | 'proximity' | 'added';
  const [sortBy, setSortBy] = useState<SortKey>('added');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const handleSort = useCallback((key: SortKey) => {
    setSortBy(prev => {
      if (prev === key) { setSortDir(d => d === 'desc' ? 'asc' : 'desc'); return key; }
      setSortDir('desc');
      return key;
    });
  }, []);

  // refreshNavs — fetches last 5 NAVs AND re-computes full score via fetchFundData
  const refreshNavs = useCallback(async (schemeCode: number) => {
    if (!schemeCode || schemeCode <= 0) return;
    setNavLoading(prev => ({ ...prev, [schemeCode]: true }));
    setNavError(prev => ({ ...prev, [schemeCode]: '' }));
    try {
      // Full NAV fetch for score recompute
      const { meta, navRecords } = await fetchFundData(schemeCode);
      const metrics = computeMetrics(navRecords);
      const scoring = computeScoring(metrics);
      // Update watchlist entry with fresh metrics + score
      // Auto-correct buyZoneDD to category norm if the entry still has the old -15 default
      // and the category norm is different (e.g. Small Cap should be -25, not -15)
      const catNorm = getCategoryBuyZone(meta.schemeCategory || meta.schemeType || '');
      const existingEntry = watchlist.entries.find(e => e.schemeCode === schemeCode);
      const shouldUpdateTrigger = existingEntry && existingEntry.buyZoneDD === -15 && catNorm !== -15;
      if (shouldUpdateTrigger) {
        watchlist.updateBuyZone(schemeCode, catNorm);
      }
      watchlist.updateMetrics(schemeCode, {
        latestNav: metrics.latestNav,
        athNav: metrics.athNav,
        currentDD: metrics.currentDrawdownFromATH,
        cagrInception: metrics.cagrInception,
        sharpeRatio: metrics.sharpeRatio,
        compositeScore: scoring.totalScore,
        schemeName: meta.schemeName || undefined,
        fundHouse: meta.fundHouse || undefined,
        category: meta.schemeCategory || meta.schemeType || undefined,
      } as Partial<WatchlistEntry>);
      // Silently fetch benchmark DD for Market Context badge
      (async () => {
        try {
          const bmName = getBenchmarkSuggestion(meta.schemeCategory || meta.schemeType || '');
          let bmRecords: { date: Date; value: number }[] | null = null;
          if (hasBundledTRI(bmName)) {
            const bm = await loadBundledTRIBenchmark(bmName, navRecords);
            bmRecords = bm.records;
          } else {
            const proxy = BENCHMARK_PROXY_MAP[bmName];
            if (proxy) {
              const rawData = await fetchBenchmarkProxy(proxy.schemeCode);
              bmRecords = rawData.map(d => {
                const parts = d.date.split('-');
                const iso = parts.length === 3 ? `${parts[2]}-${parts[1]}-${parts[0]}` : d.date;
                return { date: new Date(iso), value: d.nav };
              }).filter(r => !isNaN(r.date.getTime()));
            }
          }
          if (bmRecords && bmRecords.length > 0) {
            const bmValues = bmRecords.map(r => r.value);
            const bmATH = Math.max(...bmValues);
            const bmLatest = bmValues[bmValues.length - 1];
            const idxDD = bmATH > 0 ? ((bmLatest - bmATH) / bmATH) * 100 : 0;
            watchlist.updateMetrics(schemeCode, { indexDD: idxDD } as Partial<WatchlistEntry>);
          }
        } catch { /* silent — badge just shows N/A */ }
      })();
      // Build 5-day strip from the fresh navRecords (newest-first)
      const recent = [...navRecords].reverse().slice(0, 5);
      const days: NavDay[] = recent.map((r, i) => {
        const older = recent[i + 1];
        const changePct = older && older.nav > 0
          ? ((r.nav - older.nav) / older.nav) * 100
          : null;
        return {
          date: r.date.toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '-'),
          nav: r.nav,
          changePct,
        };
      });
      setNavData(prev => ({ ...prev, [schemeCode]: days }));
    } catch {
      setNavError(prev => ({ ...prev, [schemeCode]: 'Failed to load' }));
    } finally {
      setNavLoading(prev => ({ ...prev, [schemeCode]: false }));
    }
  }, [watchlist]);

  // Refresh All — sequential with 300ms delay to avoid rate-limiting
  const refreshAll = useCallback(async () => {
    if (refreshingAll) return;
    setRefreshingAll(true);
    for (const e of watchlist.entries) {
      await refreshNavs(e.schemeCode);
      await new Promise(r => setTimeout(r, 300));
    }
    setRefreshingAll(false);
    toast.success('All NAVs refreshed');
  }, [watchlist.entries, refreshNavs, refreshingAll]);

  // Auto-load NAVs for all watchlist entries on mount
  useEffect(() => {
    watchlist.entries.forEach(e => {
      if (!navData[e.schemeCode] && !navLoading[e.schemeCode]) {
        refreshNavs(e.schemeCode);
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [watchlist.entries.length]);

  const saveEdit = (code: number) => {
    const val = parseFloat(editDD);
    if (!isNaN(val)) {
      watchlist.updateBuyZone(code, val > 0 ? -val : val);
      toast.success('Buy zone updated');
    }
    setEditingCode(null);
  };

  if (watchlist.entries.length === 0) {
    return (
      <div className="space-y-5">
        <div className="glass-card p-5">
          <SectionHeader icon={<Bell size={16} />} title="Watchlist & Buy-Zone Alerts" subtitle="Add funds from the Analyze tab to track them here" />
        </div>
        <div className="glass-card p-12 text-center">
          <Star size={32} className="text-white/15 mx-auto mb-3" />
          <div className="text-white/30 text-sm mb-2">No funds in watchlist yet.</div>
          <div className="text-white/20 text-xs">Load any fund in the Analyze tab and click "Add to Watchlist". Set a buy-zone drawdown threshold to get alerted when the fund enters your target entry zone.</div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="glass-card p-5">
        <div className="flex items-start justify-between gap-3">
          <SectionHeader icon={<Bell size={16} />} title="Watchlist & Buy-Zone Alerts" subtitle={`${watchlist.entries.length} fund${watchlist.entries.length !== 1 ? 's' : ''} tracked · ${watchlist.alerts.length} alert${watchlist.alerts.length !== 1 ? 's' : ''} active`} />
          <button
            onClick={refreshAll}
            disabled={refreshingAll}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white/90 transition-colors text-xs font-medium flex-shrink-0 disabled:opacity-40"
          >
            <RefreshCw size={12} className={refreshingAll ? 'animate-spin' : ''} />
            {refreshingAll ? 'Refreshing…' : 'Refresh All'}
          </button>
        </div>
        {watchlist.alerts.length > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/25 rounded-xl p-4 mt-3">
            <div className="flex items-center gap-2 mb-2">
              <Bell size={14} className="text-amber-400" />
              <span className="text-sm font-semibold text-amber-400">Buy Zone Alerts Active</span>
            </div>
            <div className="space-y-1">
              {watchlist.alerts.map(a => (
                <div key={a.schemeCode} className="text-xs text-amber-300/70">
                  {(a.schemeName || a.schemeCode.toString())} — Current DD: <span className="font-mono font-bold text-amber-400">{a.currentDD.toFixed(2)}%</span> (threshold: {a.buyZoneDD.toFixed(0)}%)
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Sort Toolbar */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-[10px] uppercase tracking-wider text-white/30 mr-1">Sort by</span>
        {(['score', 'cagr', 'dd', 'proximity', 'added'] as const).map(key => {
          const labels: Record<string, string> = { score: 'Score', cagr: 'CAGR', dd: 'Curr DD', proximity: 'Buy Zone %', added: 'Date Added' };
          const active = sortBy === key;
          return (
            <button
              key={key}
              onClick={() => handleSort(key)}
              className={cn(
                'flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors',
                active
                  ? 'bg-blue-500/20 border-blue-500/30 text-blue-300'
                  : 'bg-white/5 border-white/10 text-white/40 hover:text-white/70 hover:bg-white/10'
              )}
            >
              {labels[key]}
              {active && <span className="text-[10px]">{sortDir === 'desc' ? '↓' : '↑'}</span>}
            </button>
          );
        })}
      </div>

      {/* Fund Cards */}
      <div className="space-y-4">
        {[...watchlist.entries].sort((a, b) => {
          let av = 0, bv = 0;
          if (sortBy === 'score')     { av = a.compositeScore ?? -1; bv = b.compositeScore ?? -1; }
          if (sortBy === 'cagr')      { av = a.cagrInception; bv = b.cagrInception; }
          if (sortBy === 'dd')        { av = a.currentDD; bv = b.currentDD; }
          if (sortBy === 'proximity') {
            av = a.buyZoneDD < 0 ? Math.min(1, Math.max(0, a.currentDD / a.buyZoneDD)) : 0;
            bv = b.buyZoneDD < 0 ? Math.min(1, Math.max(0, b.currentDD / b.buyZoneDD)) : 0;
          }
          if (sortBy === 'added')     { av = new Date(a.addedAt).getTime(); bv = new Date(b.addedAt).getTime(); }
          return sortDir === 'desc' ? bv - av : av - bv;
        }).map(entry => {
          const isAlert = entry.currentDD <= entry.buyZoneDD;
          const proximityPct = entry.buyZoneDD < 0
            ? Math.min(1, Math.max(0, entry.currentDD / entry.buyZoneDD))
            : 0;
          const proximityColor = isAlert ? 'bg-amber-400' : proximityPct > 0.75 ? 'bg-orange-400' : proximityPct > 0.4 ? 'bg-yellow-500' : 'bg-emerald-500';
          const days = navData[entry.schemeCode] ?? [];
          const isLoading = navLoading[entry.schemeCode] ?? false;
          const errMsg = navError[entry.schemeCode] ?? '';
          // Fund display name — fallback chain for old entries that may have undefined
          // schemeCode could be 0 or falsy for very old stale entries
          const safeCode = entry.schemeCode || 0;
          const displayName = (entry.schemeName && entry.schemeName.trim())
            ? entry.schemeName
            : safeCode > 0
              ? `Scheme ${safeCode}` // at least show the code
              : 'Unknown Fund';

          return (
            <div key={entry.schemeCode} className={cn(
              'glass-card overflow-hidden transition-colors',
              isAlert && 'ring-1 ring-amber-500/30 bg-amber-500/3'
            )}>
              {/* ── Card Header ─────────────────────────────────────────── */}
              <div className="px-5 pt-4 pb-3 border-b border-white/8">
                <div className="flex items-start justify-between gap-3">
                  {/* Fund name + meta */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-base font-semibold text-white leading-snug">{displayName}</span>
                      {isAlert && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                          <Bell size={10} /> BUY ZONE
                        </span>
                      )}
                      <WatchlistMarketBadge fundDD={entry.currentDD} indexDD={entry.indexDD} />
                    </div>
                    <div className="text-xs text-white/35 mt-0.5">
                      {entry.fundHouse && <span>{entry.fundHouse}</span>}
                      {entry.fundHouse && entry.category && <span className="mx-1.5 text-white/20">·</span>}
                      {entry.category && <span>{entry.category}</span>}
                      <span className="mx-1.5 text-white/20">·</span>
                      <span className="text-white/25">Added {new Date(entry.addedAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                    </div>
                  </div>
                  {/* Action buttons */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => refreshNavs(entry.schemeCode)}
                      title="Refresh last 5-day NAV"
                      disabled={isLoading}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white/50 hover:text-white/80 transition-colors text-xs disabled:opacity-40"
                    >
                      <RefreshCw size={11} className={isLoading ? 'animate-spin' : ''} />
                      <span>Refresh</span>
                    </button>
                    <button
                      onClick={() => onReanalyze(entry.schemeCode, displayName)}
                      title="Full analysis"
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 text-blue-400 hover:text-blue-300 transition-colors text-xs"
                    >
                      <BarChartIcon size={11} />
                      <span>Analyze</span>
                    </button>
                    <button
                      onClick={() => { watchlist.removeEntry(entry.schemeCode); toast.info('Removed from watchlist'); }}
                      title="Remove"
                      className="p-1.5 rounded-lg text-white/20 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>

              {/* ── Metrics Row ─────────────────────────────────────────── */}
              <div className="px-5 py-3 grid grid-cols-2 sm:grid-cols-5 gap-4 border-b border-white/8">
                {/* Composite Score */}
                <div className={cn(
                  'rounded-lg px-3 py-2 border',
                  entry.compositeScore !== undefined
                    ? entry.compositeScore >= 75
                      ? 'bg-emerald-500/10 border-emerald-500/20'
                      : entry.compositeScore >= 55
                        ? 'bg-amber-500/10 border-amber-500/20'
                        : 'bg-red-500/10 border-red-500/20'
                    : 'bg-white/5 border-white/10'
                )}>
                  <div className="text-[10px] uppercase tracking-wider text-white/30 mb-0.5">Score</div>
                  <div className={cn(
                    'text-lg font-mono font-bold',
                    entry.compositeScore !== undefined
                      ? entry.compositeScore >= 75
                        ? 'text-emerald-400'
                        : entry.compositeScore >= 55
                          ? 'text-amber-400'
                          : 'text-red-400'
                      : 'text-white/25'
                  )}>
                    {entry.compositeScore !== undefined ? `${entry.compositeScore.toFixed(1)}` : 'N/A'}
                  </div>
                  {entry.compositeScore !== undefined && (
                    <div className="text-[9px] text-white/25 mt-0.5">/100</div>
                  )}
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/30 mb-0.5">CAGR (Inception)</div>
                  <div className={cn('text-lg font-mono font-bold', retColor(entry.cagrInception))}>
                    {entry.cagrInception > 0 ? '+' : ''}{entry.cagrInception.toFixed(1)}%
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/30 mb-0.5">Sharpe</div>
                  <div className={cn('text-lg font-mono font-bold', entry.sharpeRatio > 1 ? 'text-emerald-400' : entry.sharpeRatio > 0.5 ? 'text-amber-400' : 'text-red-400')}>
                    {entry.sharpeRatio.toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/30 mb-0.5">Curr DD from ATH</div>
                  <div className={cn('text-lg font-mono font-bold', ddColor(entry.currentDD))}>
                    {entry.currentDD.toFixed(1)}%
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/30 mb-0.5">ATH NAV</div>
                  <div className="text-lg font-mono font-bold text-white/60">₹{entry.athNav.toFixed(2)}</div>
                </div>
              </div>

              {/* ── Buy Zone Bar ────────────────────────────────────────── */}
              <div className="px-5 py-3 border-b border-white/8">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] uppercase tracking-wider text-white/30">Buy Zone Proximity</span>
                  <div className="flex items-center gap-2">
                    {editingCode === entry.schemeCode ? (
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-white/40">Trigger at</span>
                        <input
                          type="number"
                          value={editDD}
                          onChange={e => setEditDD(e.target.value)}
                          placeholder="15"
                          className="w-14 bg-white/10 border border-white/20 rounded px-2 py-0.5 text-xs font-mono text-white outline-none focus:border-blue-500/50"
                          onKeyDown={e => { if (e.key === 'Enter') saveEdit(entry.schemeCode); if (e.key === 'Escape') setEditingCode(null); }}
                          autoFocus
                        />
                        <span className="text-[10px] text-white/40">% DD</span>
                        <button onClick={() => saveEdit(entry.schemeCode)} className="text-emerald-400 hover:text-emerald-300"><Check size={11} /></button>
                        <button onClick={() => setEditingCode(null)} className="text-white/30 hover:text-white/60"><X size={11} /></button>
                      </div>
                    ) : (
                      <button
                        onClick={() => { setEditingCode(entry.schemeCode); setEditDD(String(Math.abs(entry.buyZoneDD))); }}
                        className="flex items-center gap-1 text-xs font-mono text-white/40 hover:text-white/70 transition-colors"
                      >
                        <Edit3 size={10} />
                        Trigger: {entry.buyZoneDD.toFixed(0)}% DD
                      </button>
                    )}
                    <span className={cn(
                      'text-xs font-mono font-bold',
                      isAlert ? 'text-amber-400' : proximityPct > 0.75 ? 'text-orange-400' : 'text-white/40'
                    )}>
                      {isAlert ? 'IN ZONE' : `${Math.round(proximityPct * 100)}% of the way`}
                    </span>
                  </div>
                </div>
                <div className="h-2 bg-white/8 rounded-full overflow-hidden">
                  <div
                    className={cn('h-full rounded-full transition-all duration-700', proximityColor)}
                    style={{ width: `${proximityPct * 100}%` }}
                  />
                </div>
              </div>

              {/* ── Last 5-Day NAV Strip ─────────────────────────────────── */}
              <div className="px-5 py-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase tracking-wider text-white/30">Last 5 Trading Days — NAV</span>
                  {errMsg && <span className="text-[10px] text-red-400">{errMsg}</span>}
                </div>
                {isLoading ? (
                  <div className="flex items-center gap-2 text-xs text-white/30 py-2">
                    <Loader2 size={12} className="animate-spin" /> Loading NAV data…
                  </div>
                ) : days.length === 0 ? (
                  <div className="text-xs text-white/20 py-1">Click Refresh to load recent NAVs.</div>
                ) : (
                  <div className="grid grid-cols-5 gap-2">
                    {days.map((day, i) => {
                      const isDown = day.changePct !== null && day.changePct < 0;
                      const isUp = day.changePct !== null && day.changePct > 0;
                      const isToday = i === 0;
                      return (
                        <div
                          key={day.date}
                          className={cn(
                            'rounded-lg p-2.5 border text-center',
                            isToday
                              ? 'bg-white/8 border-white/15'
                              : 'bg-white/3 border-white/8'
                          )}
                        >
                          <div className="text-[9px] text-white/35 mb-1 font-mono">{day.date}</div>
                          <div className={cn(
                            'text-sm font-mono font-bold',
                            isToday ? 'text-white' : 'text-white/70'
                          )}>
                            ₹{day.nav.toFixed(2)}
                          </div>
                          {day.changePct !== null ? (
                            <div className={cn(
                              'flex items-center justify-center gap-0.5 mt-1 text-[10px] font-mono font-semibold',
                              isDown ? 'text-red-400' : isUp ? 'text-emerald-400' : 'text-white/30'
                            )}>
                              {isDown && <ChevronDown size={10} />}
                              {isUp && <ChevronUp size={10} />}
                              {isDown || isUp
                                ? `${Math.abs(day.changePct).toFixed(2)}%`
                                : '0.00%'
                              }
                            </div>
                          ) : (
                            <div className="text-[9px] text-white/20 mt-1">—</div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-xs text-white/25 text-center">
        Watchlist saved in browser (localStorage). NAV data fetched live from AMFI via mfapi.in. Click Refresh on any fund to update its 5-day NAV strip.
      </div>
    </div>
  );
}

// ─── SOP Guide ────────────────────────────────────────────────────────────────

function SOPGuide() {
  const [openStep, setOpenStep] = useState<number | null>(1);
  const [cfgName, setCfgName] = useState('');
  const [cfgAmfi, setCfgAmfi] = useState('');
  const [cfgBm, setCfgBm] = useState('');
  const [cfgAum, setCfgAum] = useState('');
  const [cfgTer, setCfgTer] = useState('');
  const [cfgCsv, setCfgCsv] = useState('');
  const [generatedConfig, setGeneratedConfig] = useState('');

  const generateConfig = () => {
    const today = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
    const slug = (cfgName || 'My_Fund').replace(/[^a-zA-Z0-9]+/g, '_');
    const config = `# ── CONFIG ──────────────────────────────────────────────
FUND_NAME    = "${cfgName || 'My Fund'}"
AMFI_CODE    = "${cfgAmfi || '000000'}"
BENCHMARK    = "${cfgBm || 'NIFTY 500 TRI'}"
REVIEW_DATE  = "${today}"
NAV_CSV      = "${cfgCsv || 'nav_fund.csv'}"
OUTPUT_FILE  = "${slug}_Research_v4.xlsx"

FUND_STATS = {
    "aum_cr":          ${cfgAum || '0'},
    "ter":             ${cfgTer || '0.00'},
    "category_ter":    1.10,     # update with category average
    "cagr_inception":  0,        # 0 = auto-computed from NAV
    "max_dd":          0,        # 0 = auto-computed from NAV
    "sharpe_inception": 0,       # 0 = auto-computed from NAV
    "alpha_inception": 0,        # fill only if BM data available
}`;
    setGeneratedConfig(config);
  };

  const steps = [
    { id: 1, title: 'Find the AMFI Scheme Code', subtitle: 'Every fund has a unique numeric code on mfapi.in', content: (
      <div className="space-y-4">
        <div className="code-block"><div className="flex items-center justify-between px-4 py-2 border-b border-white/8 bg-white/3"><span className="text-xs font-semibold uppercase tracking-wider text-white/30">URL</span><CopyButton text="https://api.mfapi.in/mf/search?q=HDFC+Flexi+Cap" /></div><pre className="px-4 py-3 text-sm font-mono text-blue-300 overflow-x-auto">https://api.mfapi.in/mf/search?q=HDFC+Flexi+Cap</pre></div>
        <div className="bg-emerald-500/8 border border-emerald-500/20 rounded-lg p-3 text-sm text-emerald-300">Always pick the <strong>Direct Growth</strong> scheme. Never use Regular — it has a higher TER.</div>
        <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b border-white/10"><th className="text-left py-2 text-white/40">Fund</th><th className="text-left py-2 text-white/40">Code</th><th className="text-left py-2 text-white/40">Category</th></tr></thead><tbody>{POPULAR_FUNDS.map(f => (<tr key={f.code} className="border-b border-white/5"><td className="py-2 text-white/70 text-xs">{f.name}</td><td className="py-2 font-mono text-blue-400 text-xs">{f.code}</td><td className="py-2 text-white/40 text-xs">{f.category}</td></tr>))}</tbody></table></div>
      </div>
    )},
    { id: 2, title: 'Download the Daily NAV CSV', subtitle: 'One Python script — run once, saves all historical daily NAV', content: (
      <div className="space-y-4">
        <div className="code-block"><div className="flex items-center justify-between px-4 py-2 border-b border-white/8 bg-white/3"><span className="text-xs font-semibold uppercase tracking-wider text-white/30">Python</span><CopyButton text={`import requests, csv\n\nSCHEME_CODE = 151750\nOUTPUT_FILE = "nav_hdfc_defence.csv"\n\ndata = requests.get(\n    f"https://api.mfapi.in/mf/{SCHEME_CODE}",\n    timeout=30\n).json()\n\nwith open(OUTPUT_FILE, "w", newline="") as f:\n    w = csv.writer(f)\n    w.writerow(["date", "nav"])\n    for r in reversed(data["data"]):\n        w.writerow([r["date"], r["nav"]])\n\nprint(f"Saved {len(data['data'])} records to {OUTPUT_FILE}")`} /></div>
        <pre className="px-4 py-3 text-sm font-mono text-white/80 overflow-x-auto leading-relaxed">{`import requests, csv\n\nSCHEME_CODE = 151750                    # ← change this\nOUTPUT_FILE = "nav_hdfc_defence.csv"    # ← change this\n\ndata = requests.get(\n    f"https://api.mfapi.in/mf/{SCHEME_CODE}",\n    timeout=30\n).json()\n\nwith open(OUTPUT_FILE, "w", newline="") as f:\n    w = csv.writer(f)\n    w.writerow(["date", "nav"])\n    for r in reversed(data["data"]):\n        w.writerow([r["date"], r["nav"]])\n\nprint(f"Saved {len(data['data'])} records to {OUTPUT_FILE}")`}</pre></div>
        <div className="bg-amber-500/8 border border-amber-500/20 rounded-lg p-3 text-sm text-amber-300">mfapi.in can be slow. If it times out, just retry — it always succeeds within 1–2 attempts.</div>
      </div>
    )},
    { id: 3, title: 'Generate Config Snippet', subtitle: 'Fill in the form to get the exact CONFIG block', content: (
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[{ label: 'Fund Name', val: cfgName, set: setCfgName, ph: 'HDFC Flexi Cap Fund' }, { label: 'AMFI Scheme Code', val: cfgAmfi, set: setCfgAmfi, ph: '120503' }, { label: 'Benchmark', val: cfgBm, set: setCfgBm, ph: 'NIFTY 500 TRI' }, { label: 'AUM (₹ Cr)', val: cfgAum, set: setCfgAum, ph: '60000' }, { label: 'TER % (Direct)', val: cfgTer, set: setCfgTer, ph: '0.75' }, { label: 'NAV CSV Filename', val: cfgCsv, set: setCfgCsv, ph: 'nav_fund.csv' }].map(f => (
            <div key={f.label}><label className="block text-xs font-semibold uppercase tracking-wider text-white/40 mb-1.5">{f.label}</label><input type="text" value={f.val} onChange={e => f.set(e.target.value)} placeholder={f.ph} className="w-full bg-[#0f1117] border border-white/20 rounded-lg px-3 py-2 text-sm font-mono text-white placeholder-white/40 outline-none focus:border-blue-500/60 focus:bg-[#141720] transition-colors" /></div>
          ))}
        </div>
        <button onClick={generateConfig} className="gradient-btn px-5 py-2.5 rounded-lg text-sm flex items-center gap-2"><Zap size={14} /> Generate Config Snippet</button>
        {generatedConfig && (<div className="code-block"><div className="flex items-center justify-between px-4 py-2 border-b border-white/8 bg-white/3"><span className="text-xs font-semibold uppercase tracking-wider text-white/30">Python — CONFIG block</span><CopyButton text={generatedConfig} /></div><pre className="px-4 py-3 text-xs font-mono text-white/80 overflow-x-auto leading-relaxed">{generatedConfig}</pre></div>)}
      </div>
    )},
    { id: 4, title: 'Run Builder & Validate', subtitle: '28 automated checks run automatically', content: (
      <div className="space-y-4">
        <div className="code-block"><div className="flex items-center justify-between px-4 py-2 border-b border-white/8 bg-white/3"><span className="text-xs font-semibold uppercase tracking-wider text-white/30">Terminal</span><CopyButton text="python3 build_hdfc_defence_v4.py" /></div><pre className="px-4 py-3 text-sm font-mono text-white/80">python3 build_hdfc_defence_v4.py</pre></div>
        <div className="bg-emerald-500/8 border border-emerald-500/20 rounded-lg p-3 text-sm text-emerald-300">28/28 checks must pass. If any fail, the error message tells you exactly which check failed. Fix the config and re-run.</div>
      </div>
    )},
    { id: 5, title: 'Add Benchmark TRI for Alpha', subtitle: 'The one step that unlocks alpha and rolling beat metrics', content: (
      <ol className="space-y-3">
        {['Go to NSEIndia.com → Products → Indices → Historical Data. Select your index and download daily data as CSV.', 'Always use TRI (Total Return Index), not Price Return Index. TRI includes dividends — essential for fair comparison.', 'In the Analyze tab: load your fund, expand "Benchmark Overlay" and upload the CSV. Alpha, rolling beat %, tracking error, and information ratio are computed instantly.'].map((step, i) => (
          <li key={i} className="flex gap-3 text-sm text-white/60"><span className="w-6 h-6 rounded-md bg-blue-500/15 text-blue-400 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">{i + 1}</span><span>{step}</span></li>
        ))}
      </ol>
    )},
  ];

  return (
    <div className="space-y-4">
      <div className="glass-card p-5 mb-6">
        <SectionHeader icon={<BookOpen size={16} />} title="Workbook Builder SOP" subtitle="Standard Operating Procedure — run the 9-sheet Excel workbook for any fund" />
        <div className="flex flex-wrap gap-4 text-sm text-white/50">
          {['9-sheet Excel workbook', '28 automated validation checks', 'Zero hardcoded values', 'Works for any AMFI fund'].map(f => (
            <span key={f} className="flex items-center gap-1.5"><CheckCircle size={13} className="text-emerald-400" /> {f}</span>
          ))}
        </div>
      </div>
      {steps.map(step => (
        <div key={step.id} className="glass-card overflow-hidden">
          <button onClick={() => setOpenStep(openStep === step.id ? null : step.id)} className="w-full flex items-center gap-4 px-5 py-4 text-left hover:bg-white/5 transition-colors">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">{step.id}</div>
            <div className="flex-1 min-w-0"><div className="font-semibold text-white">{step.title}</div><div className="text-xs text-white/40">{step.subtitle}</div></div>
            {openStep === step.id ? <ChevronUp size={16} className="text-white/30 flex-shrink-0" /> : <ChevronDown size={16} className="text-white/30 flex-shrink-0" />}
          </button>
          {openStep === step.id && <div className="px-5 pb-5">{step.content}</div>}
        </div>
      ))}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function Home() {
  const [tab, setTab] = useState<TabType>('analyze');
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MFSearchResult[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [analysis, setAnalysis] = useState<AnalysisState | null>(null);
  const [benchmarkLoading, setBenchmarkLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [schemeCodeMode, setSchemeCodeMode] = useState(false);
  const [schemeCodeInput, setSchemeCodeInput] = useState('');
  const [schemeCodeError, setSchemeCodeError] = useState<string | null>(null);
  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const watchlist = useWatchlist();
  // Stable refs so handleSelectFund never needs watchlist in its dep array.
  // Must be declared at top-level (rules of hooks) immediately after useWatchlist.
  const isInWatchlistRef = useRef(watchlist.isInWatchlist);
  const updateMetricsRef = useRef(watchlist.updateMetrics);
  useEffect(() => { isInWatchlistRef.current = watchlist.isInWatchlist; }, [watchlist.isInWatchlist]);
  useEffect(() => { updateMetricsRef.current = watchlist.updateMetrics; }, [watchlist.updateMetrics]);
  // Pre-warm the fund index on mount so first search is instant
  useEffect(() => { prewarmFundIndex(); }, []);

  // Close search dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSearch = useCallback((q: string) => {
    setQuery(q);
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    if (!q.trim()) { setSearchResults([]); setSearchOpen(false); return; }
    searchTimeout.current = setTimeout(async () => {
      setSearching(true);
      try {
        const results = await searchFunds(q);
        setSearchResults(results);
        setSearchOpen(results.length > 0);
      }
      catch { setSearchResults([]); setSearchOpen(false); }
      finally { setSearching(false); }
    }, 400);
  }, []);

  const handleSchemeCodeLoad = useCallback(async () => {
    const raw = schemeCodeInput.trim();
    if (!raw) {
      setSchemeCodeError('Enter a numeric scheme code (e.g. 148490)');
      return;
    }
    setSchemeCodeError(null);
    setError(null);
    setAnalysis(null);
    setLoading(true);

    try {
      // Numeric scheme code only — no ISIN dependency
      const resolvedCode = parseInt(raw, 10);
      if (isNaN(resolvedCode) || resolvedCode <= 0) {
        setSchemeCodeError('Enter a valid numeric scheme code (e.g. 148490). Find codes at api.mfapi.in');
        setLoading(false);
        setLoadingMsg('');
        return;
      }

      setLoadingMsg(`Fetching scheme ${resolvedCode} from AMFI via mfapi.in...`);
      const { meta, navRecords } = await fetchFundData(resolvedCode);
      setLoadingMsg(`Computing metrics from ${navRecords.length} daily NAV records...`);
      await new Promise(r => setTimeout(r, 50));
      const metrics = computeMetrics(navRecords);
      setLoadingMsg('Computing scoring grid...');
      await new Promise(r => setTimeout(r, 50));
      const scoring = computeScoring(metrics);
      setAnalysis({ meta, navRecords, metrics, scoring, benchmark: null });
      setQuery(meta.schemeName);
      setSchemeCodeMode(false);
      toast.success(`Loaded ${navRecords.length} records for ${meta.schemeName}`);
      // Auto-load category benchmark silently
      const bmName1 = getBenchmarkSuggestion(meta.schemeCategory || meta.schemeType || '');
      setBenchmarkLoading(true);
      (async () => {
        try {
          let bm;
          if (hasBundledTRI(bmName1)) {
            bm = await loadBundledTRIBenchmark(bmName1, navRecords);
          } else {
            const proxy = BENCHMARK_PROXY_MAP[bmName1];
            if (proxy) {
              const rawData = await fetchBenchmarkProxy(proxy.schemeCode);
              const recs = rawData.map(d => {
                const parts = d.date.split('-');
                const iso = parts.length === 3 ? `${parts[2]}-${parts[1]}-${parts[0]}` : d.date;
                return { date: new Date(iso), value: d.nav };
              }).filter(r => !isNaN(r.date.getTime()));
              bm = computeBenchmarkMetrics(recs, proxy.label, navRecords);
            }
          }
          if (bm) setAnalysis(prev => prev ? { ...prev, benchmark: bm } : prev);
        } catch { /* silent — user can manually load if needed */ }
        finally { setBenchmarkLoading(false); }
      })();
    } catch (e: unknown) {
      setSchemeCodeError(`Failed: ${e instanceof Error ? e.message : 'Unknown error'}. Check the input and retry.`);
    } finally { setLoading(false); setLoadingMsg(''); }
  }, [schemeCodeInput]);

  const handleSelectFund = useCallback(async (code: number, name: string) => {
    setSearchResults([]); setSearchOpen(false); setQuery(name); setError(null); setAnalysis(null); setLoading(true);
    setLoadingMsg('Fetching NAV data from AMFI via mfapi.in...');
    try {
      const { meta, navRecords } = await fetchFundData(code);
      setLoadingMsg(`Computing metrics from ${navRecords.length} daily NAV records...`);
      await new Promise(r => setTimeout(r, 50));
      const metrics = computeMetrics(navRecords);
      setLoadingMsg('Computing scoring grid...');
      await new Promise(r => setTimeout(r, 50));
      const scoring = computeScoring(metrics);
      const newState: AnalysisState = { meta, navRecords, metrics, scoring, benchmark: null };
      setAnalysis(newState);
      // Auto-load category benchmark silently
      const bmName2 = getBenchmarkSuggestion(meta.schemeCategory || meta.schemeType || '');
      setBenchmarkLoading(true);
      (async () => {
        try {
          let bm;
          if (hasBundledTRI(bmName2)) {
            bm = await loadBundledTRIBenchmark(bmName2, navRecords);
          } else {
            const proxy = BENCHMARK_PROXY_MAP[bmName2];
            if (proxy) {
              const rawData = await fetchBenchmarkProxy(proxy.schemeCode);
              const recs = rawData.map(d => {
                const parts = d.date.split('-');
                const iso = parts.length === 3 ? `${parts[2]}-${parts[1]}-${parts[0]}` : d.date;
                return { date: new Date(iso), value: d.nav };
              }).filter(r => !isNaN(r.date.getTime()));
              bm = computeBenchmarkMetrics(recs, proxy.label, navRecords);
            }
          }
          if (bm) setAnalysis(prev => prev ? { ...prev, benchmark: bm } : prev);
        } catch { /* silent */ }
        finally { setBenchmarkLoading(false); }
      })();
      // Silently refresh metrics for this fund IF it is already in the watchlist.
      // Use ref so this callback never needs watchlist in its dep array.
      if (isInWatchlistRef.current(code)) {
        updateMetricsRef.current(code, {
          latestNav: metrics.latestNav,
          athNav: metrics.athNav,
          currentDD: metrics.currentDrawdownFromATH,
          cagrInception: metrics.cagrInception,
          sharpeRatio: metrics.sharpeRatio,
        });
      }
      toast.success(`Loaded ${navRecords.length} records for ${meta.schemeName}`);
    } catch (e: unknown) {
      setError(`Failed to load fund data: ${e instanceof Error ? e.message : 'Unknown error'}. mfapi.in may be temporarily slow — please retry.`);
      toast.error('Failed to load fund data');
    } finally { setLoading(false); setLoadingMsg(''); }
  }, []); // no watchlist dep — uses stable refs above

  const handleWatchlistToggle = useCallback(() => {
    if (!analysis) return;
    const { meta, metrics, scoring } = analysis;
    if (watchlist.isInWatchlist(meta.schemeCode)) {
      watchlist.removeEntry(meta.schemeCode);
      toast.info('Removed from watchlist');
    } else {
      watchlist.addEntry({
        schemeCode: meta.schemeCode,
        schemeName: meta.schemeName,
        fundHouse: meta.fundHouse,
        category: meta.schemeCategory || meta.schemeType,
        buyZoneDD: getCategoryBuyZone(meta.schemeCategory || meta.schemeType || ''),
        latestNav: metrics.latestNav,
        athNav: metrics.athNav,
        currentDD: metrics.currentDrawdownFromATH,
        cagrInception: metrics.cagrInception,
        sharpeRatio: metrics.sharpeRatio,
        compositeScore: scoring.totalScore,
        lastUpdated: new Date().toISOString(),
      });
      const autoTrigger = getCategoryBuyZone(meta.schemeCategory || meta.schemeType || '');
      toast.success(`Added to watchlist. Buy zone auto-set to ${autoTrigger}% DD (${meta.schemeCategory || 'category'} norm). Edit in Watchlist tab.`);
    }
  }, [analysis, watchlist]);



  const alertCount = watchlist.alerts.length;

  const tabs: { id: TabType; label: string; badge?: number }[] = [
    { id: 'analyze', label: 'Analyze' },
    { id: 'compare', label: 'Compare' },
    { id: 'watchlist', label: 'Watchlist', badge: alertCount > 0 ? alertCount : undefined },
    { id: 'sop', label: 'SOP Guide' },
    { id: 'glossary', label: 'Glossary' },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-white/8 bg-white/3 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center flex-shrink-0">
              <TrendingUp size={16} className="text-white" />
            </div>
            <div>
              <div className="font-bold text-white text-sm leading-tight">MF Analysis Platform</div>
              <div className="text-xs text-white/30 leading-tight hidden sm:block">Live NAV · Zero Speculation · Any Fund</div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={cn('relative px-3 py-1.5 rounded-lg text-sm font-medium transition-colors', tab === t.id ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 'text-white/40 hover:text-white/70')}>
                {t.label}
                {t.badge && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-white text-xs flex items-center justify-center font-bold">{t.badge}</span>
                )}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="container py-6">
        {/* ANALYZE TAB */}
        {tab === 'analyze' && (
          <div>
            {!analysis && !loading && (
              <div className="text-center mb-8 pt-4">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider mb-4">Live Data · Zero Speculation</div>
                <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 leading-tight">Mutual Fund<br /><span className="gradient-text">Deep Analysis</span></h1>
                <p className="text-white/40 text-sm max-w-md mx-auto">Search any Indian mutual fund. All metrics computed live from actual AMFI NAV data. Benchmark overlay, watchlist, comparison — all included.</p>
              </div>
            )}

            {/* Search */}
            <div className="relative max-w-2xl mx-auto mb-6" ref={searchContainerRef}>
              <div className="relative">
                <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
                <input type="text" value={query} onChange={e => handleSearch(e.target.value)}
                  onFocus={() => searchResults.length > 0 && setSearchOpen(true)}
                  placeholder="Search any fund — e.g. HDFC Defence, Parag Parikh, SBI Children..."
                  className="w-full bg-[#0f1117] border border-white/20 rounded-xl pl-11 pr-4 py-3.5 text-sm text-white placeholder-white/40 outline-none focus:border-blue-500/60 focus:bg-[#141720] transition-all" />
                {searching && <Loader2 size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 animate-spin" />}
              </div>
              {searchOpen && searchResults.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-white/20 rounded-xl overflow-hidden z-[100] max-h-72 overflow-y-auto shadow-2xl shadow-black/60">
                  {searchResults.map(r => (
                    <button key={r.schemeCode}
                      onMouseDown={e => { e.preventDefault(); handleSelectFund(r.schemeCode, r.schemeName); }}
                      className="w-full text-left px-4 py-3 hover:bg-white/10 transition-colors border-b border-white/8 last:border-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="text-sm text-white/80 font-medium leading-tight flex-1 min-w-0">{r.schemeName}</div>
                        {extractAMC(r.schemeName) && (
                          <span className="shrink-0 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-300 border border-blue-500/20 uppercase tracking-wide mt-0.5">
                            {extractAMC(r.schemeName)}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-white/25 mt-0.5 font-mono">Code: {r.schemeCode}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Scheme Code Toggle */}
            <div className="max-w-2xl mx-auto mb-4 text-center">
              <button
                onClick={() => { setSchemeCodeMode(v => !v); setSchemeCodeInput(''); setSchemeCodeError(null); }}
                className="inline-flex items-center gap-1.5 text-xs text-white/30 hover:text-white/60 transition-colors group"
              >
                <Hash size={12} className="group-hover:text-blue-400 transition-colors" />
                {schemeCodeMode ? 'Back to name search' : 'Know the scheme code? Enter it directly'}
              </button>
            </div>

            {/* Scheme Code Input Panel */}
            {schemeCodeMode && (
              <div className="max-w-2xl mx-auto mb-6">
                <div className="glass-card border border-blue-500/20 rounded-xl p-4">
                  <div className="text-xs font-semibold uppercase tracking-wider text-blue-400/70 mb-3 flex items-center gap-2">
                    <Hash size={12} />
                    Direct Scheme Code Entry
                  </div>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={schemeCodeInput}
                        onChange={e => { setSchemeCodeInput(e.target.value); setSchemeCodeError(null); }}
                        onKeyDown={e => e.key === 'Enter' && handleSchemeCodeLoad()}
                        placeholder="Numeric scheme code — e.g. 148490"
                        autoComplete="off"
                        spellCheck={false}
                        className="w-full bg-[#0f1117] border border-white/20 rounded-lg px-4 py-2.5 text-sm text-white placeholder-white/40 outline-none focus:border-blue-500/60 focus:bg-[#141720] transition-all font-mono"
                      />
                    </div>
                    <button
                      onClick={handleSchemeCodeLoad}
                      disabled={!schemeCodeInput.trim() || loading}
                      className="px-4 py-2.5 rounded-lg bg-blue-500/20 border border-blue-500/30 text-blue-400 text-sm font-medium hover:bg-blue-500/30 transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2 whitespace-nowrap"
                    >
                      {loading ? <Loader2 size={14} className="animate-spin" /> : <TrendingUp size={14} />}
                      Load Fund
                    </button>
                  </div>
                  {schemeCodeError && (
                    <div className="mt-2 text-xs text-red-400/80 flex items-center gap-1.5">
                      <AlertCircle size={12} />
                      {schemeCodeError}
                    </div>
                  )}
                  <div className="mt-3 text-xs text-white/25 leading-relaxed">
                    Enter the <span className="text-white/40">numeric scheme code</span> from your CAS statement or broker app.
                    To find a code: search at{' '}
                    <a href="https://api.mfapi.in/mf/search?q=SBI" target="_blank" rel="noopener noreferrer" className="text-blue-400/60 hover:text-blue-400 transition-colors">api.mfapi.in/mf/search?q=FUNDNAME</a>
                    {' '}— the <span className="text-white/40">schemeCode</span> field in the JSON result is what you need.
                  </div>
                </div>
              </div>
            )}

            {/* Popular Funds */}
            {!analysis && !loading && (
              <div className="max-w-2xl mx-auto mb-8">
                <div className="text-xs font-semibold uppercase tracking-wider text-white/30 mb-3 text-center">Quick Access</div>
                <div className="flex flex-wrap gap-2 justify-center">
                  {POPULAR_FUNDS.slice(0, 8).map(f => (
                    <button key={f.code} onClick={() => handleSelectFund(f.code, f.name)}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 border border-white/8 text-white/50 hover:bg-white/10 hover:text-white/80 hover:border-white/15 transition-all">
                      {(f.name ?? '').split('—')[0]?.trim() ?? f.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {loading && (
              <div className="text-center py-16">
                <Loader2 size={32} className="animate-spin text-blue-400 mx-auto mb-4" />
                <div className="text-white/60 text-sm">{loadingMsg}</div>
                <div className="text-white/30 text-xs mt-2">Fetching from AMFI via mfapi.in — may take 5–15 seconds</div>
              </div>
            )}

            {error && (
              <div className="max-w-2xl mx-auto">
                <div className="glass-card p-5 border border-red-500/20">
                  <div className="flex items-start gap-3">
                    <AlertTriangle size={18} className="text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-red-400 mb-1">Error</div>
                      <div className="text-sm text-white/60">{error}</div>
                      <button onClick={() => setError(null)} className="mt-3 text-xs text-blue-400 hover:underline flex items-center gap-1"><RefreshCw size={12} /> Try again</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {analysis && !loading && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <button onClick={() => { setAnalysis(null); setQuery(''); setError(null); }} className="text-xs text-white/40 hover:text-white/70 flex items-center gap-1.5 transition-colors">← Search another fund</button>
                  <button onClick={() => handleSelectFund(analysis.meta.schemeCode, analysis.meta.schemeName)} className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1.5 transition-colors"><RefreshCw size={12} /> Refresh data</button>
                </div>
                <AnalysisDashboard
                  state={analysis}
                  onBenchmarkLoaded={bm => setAnalysis(prev => prev ? { ...prev, benchmark: bm } : prev)}
                  onBenchmarkCleared={() => setAnalysis(prev => prev ? { ...prev, benchmark: null } : prev)}
                  watchlist={watchlist}
                  onWatchlistToggle={handleWatchlistToggle}
                  benchmarkLoading={benchmarkLoading}
                />
              </div>
            )}
          </div>
        )}

        {/* COMPARE TAB */}
        {tab === 'compare' && <CompareTab />}

        {/* WATCHLIST TAB */}
        {tab === 'watchlist' && (
          <WatchlistTab
            watchlist={watchlist}
            onReanalyze={(code, name) => {
              setTab('analyze');
              handleSelectFund(code, name);
            }}
          />
        )}

        {/* SOP TAB */}
        {tab === 'sop' && <SOPGuide />}

        {/* GLOSSARY TAB */}
        {tab === 'glossary' && (
          <div className="-mx-4 sm:-mx-6 lg:-mx-8">
            <GlossaryInline />
          </div>
        )}
      </div>

      <footer className="border-t border-white/8 mt-12 py-6">
        <div className="container text-center text-xs text-white/25 space-y-1">
          <div>Data source: AMFI via <a href="https://api.mfapi.in" target="_blank" rel="noopener noreferrer" className="text-blue-400/60 hover:text-blue-400 transition-colors">mfapi.in</a> — live, no caching</div>
          <div>All metrics computed in real-time from actual daily NAV data. No hardcoded values. No speculation.</div>
          <div>For research purposes only. Not investment advice.</div>
        </div>
      </footer>
    </div>
  );
}
